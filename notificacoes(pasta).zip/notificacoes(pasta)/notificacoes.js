
/* ==========================================
   ELEMENTOS DO HTML
========================================== */

// Botão do sino
const btnSino = document.getElementById("btnSino");

// Painel de notificações
const painel = document.getElementById("painelNotificacoes");

// Botão de fechar
const btnFechar = document.getElementById("btnFechar");

// Contador do sino
const contador = document.getElementById("contador");

// Lista de notificações
const lista = document.getElementById("listaNotificacoes");

// Mensagem de lista vazia
const mensagemVazia = document.getElementById("mensagemVazia");

// Botão para marcar todas como lidas
const btnMarcarLidas = document.getElementById("btnMarcarLidas");


/* ==========================================
   NOTIFICAÇÕES DE DEMONSTRAÇÃO
========================================== */

// Esses dados são apenas exemplos visuais.
// Depois, o Backend enviará os dados reais.

let notificacoes = [
    {
        id: 1,
        titulo: "Novo funcionário cadastrado",
        mensagem: "João Silva foi cadastrado com sucesso.",
        data: "Agora mesmo",
        tipo: "cadastro",
        lida: false
    },

    {
        id: 2,
        titulo: "Estoque baixo",
        mensagem: "A matéria-prima Papel A4 está em falta.",
        data: "Há 10 minutos",
        tipo: "estoque",
        lida: false
    },

    {
        id: 3,
        titulo: "Novo produto cadastrado",
        mensagem: "O produto Livro foi adicionado ao sistema.",
        data: "Há 30 minutos",
        tipo: "produto",
        lida: true
    }
];


/* ==========================================
   MÉTODOS DE NOTIFICAÇÃO - HEFESTO'S STOCK
   ========================================== */

// Adiciona uma nova notificação à lista
function adicionarNotificacao(titulo, mensagem, tipo) {

    const novaNotificacao = {
        id: Date.now(),
        titulo: titulo,
        mensagem: mensagem,
        data: "Agora mesmo",
        tipo: tipo,
        lida: false
    };

    // Adiciona a notificação no início da lista
    notificacoes.unshift(novaNotificacao);

    // Atualiza a lista visual e o contador
    renderizarNotificacoes();
    atualizarContador();
}


/* ==========================================
   MÉTODOS PARA NOVOS CADASTROS
   ========================================== */

// Funcionário cadastrado
function notificarNovoFuncionario(nome) {
    adicionarNotificacao(
        "Novo funcionário cadastrado",
        nome + " foi cadastrado no sistema.",
        "funcionario"
    );
}

// Cliente cadastrado
function notificarNovoCliente(nome) {
    adicionarNotificacao(
        "Novo cliente cadastrado",
        nome + " foi registrado no sistema.",
        "cliente"
    );
}

// Produto cadastrado
function notificarNovoProduto(nome) {
    adicionarNotificacao(
        "Novo produto cadastrado",
        nome + " foi adicionado ao estoque.",
        "produto"
    );
}

// Fornecedor cadastrado
function notificarNovoFornecedor(nome) {
    adicionarNotificacao(
        "Novo fornecedor cadastrado",
        nome + " foi registrado no sistema.",
        "fornecedor"
    );
}


/* ==========================================
   MÉTODOS PARA ALERTAS DE ESTOQUE
   ========================================== */

// Estoque baixo
function notificarEstoqueBaixo(nomeMaterial, quantidade) {
    adicionarNotificacao(
        "Alerta de estoque baixo",
        nomeMaterial + " possui apenas " + quantidade + " unidades disponíveis.",
        "estoque_baixo"
    );
}

// Estoque zerado
function notificarEstoqueZerado(nomeMaterial) {
    adicionarNotificacao(
        "Estoque esgotado",
        nomeMaterial + " está sem unidades disponíveis.",
        "estoque_zerado"
    );
}


/* ==========================================
   MÉTODOS PARA PEDIDOS E PRODUÇÃO
   ========================================== */

// Novo pedido
function notificarNovoPedido(numeroPedido) {
    adicionarNotificacao(
        "Novo pedido recebido",
        "O pedido #" + numeroPedido + " foi registrado.",
        "pedido"
    );
}

// Produção iniciada
function notificarProducaoIniciada(nomeProduto) {
    adicionarNotificacao(
        "Produção iniciada",
        "A produção de " + nomeProduto + " foi iniciada.",
        "producao"
    );
}

// Produção concluída
function notificarProducaoConcluida(nomeProduto) {
    adicionarNotificacao(
        "Produção concluída",
        "A produção de " + nomeProduto + " foi finalizada.",
        "sucesso"
    );
}



/* ==========================================
   ÍCONES DAS NOTIFICAÇÕES
========================================== */

function escolherIcone(tipo) {

    const icones = {
        funcionario: "bi-person-plus",
        cliente: "bi-person",
        produto: "bi-box-seam",
        fornecedor: "bi-truck",
        estoque_baixo: "bi-exclamation-triangle",
        estoque_zerado: "bi-box",
        pedido: "bi-cart-check",
        producao: "bi-gear",
        sucesso: "bi-check-circle"
    };

    return icones[tipo] || "bi-bell";
}

/* ==========================================
   ATUALIZAR CONTADOR
========================================== */

function atualizarContador() {

    // Conta apenas as notificações não lidas

    const quantidade = notificacoes.filter(
        notificacao => !notificacao.lida
    ).length;

    contador.textContent = quantidade;
}


/* ==========================================
   MOSTRAR NOTIFICAÇÕES
========================================== */

function mostrarNotificacoes() {

    // Limpa a lista antes de preencher
    lista.innerHTML = "";

    // Verifica se existem notificações
    if (notificacoes.length === 0) {

        mensagemVazia.hidden = false;
        btnMarcarLidas.hidden = true;

        atualizarContador();

        return;
    }

    // Se existem notificações, esconde a mensagem vazia
    mensagemVazia.hidden = true;
    btnMarcarLidas.hidden = false;

    // Percorre todas as notificações
    notificacoes.forEach(notificacao => {

        // Cria o card
        const card = document.createElement("div");

        // Define se o card está lido ou não
        card.className = notificacao.lida
            ? "card-notificacao lida"
            : "card-notificacao nao-lida";

        // Cria o conteúdo do card
        card.innerHTML = `
            <i class="bi ${escolherIcone(notificacao.tipo)}
               icone-notificacao"></i>

            <div>

                <h4 class="titulo-notificacao">
                    ${notificacao.titulo}
                </h4>

                <p class="texto-notificacao">
                    ${notificacao.mensagem}
                </p>

                <span class="data-notificacao">
                    ${notificacao.data}
                </span>

            </div>
        `;

        // Ao clicar, marca como lida
        card.addEventListener("click", function() {

            notificacao.lida = true;

            mostrarNotificacoes();

        });

        // Adiciona o card à lista
        lista.appendChild(card);

    });

    // Atualiza o contador do sino
    atualizarContador();
}


/* ==========================================
   ABRIR PAINEL
========================================== */

btnSino.addEventListener("click", function() {

    // Verifica se o painel está aberto
    const aberto = !painel.hidden;

    // Alterna a exibição do painel
    painel.hidden = aberto;

    // Atualiza o estado do botão
    btnSino.setAttribute("aria-expanded", !aberto);

});


/* ==========================================
   FECHAR PAINEL
========================================== */

btnFechar.addEventListener("click", function() {

    // Esconde o painel
    painel.hidden = true;

    // Atualiza o botão
    btnSino.setAttribute("aria-expanded", "false");

});


/* ==========================================
   MARCAR TODAS COMO LIDAS
========================================== */

btnMarcarLidas.addEventListener("click", function() {

    // Percorre todas as notificações
    notificacoes.forEach(notificacao => {

        // Marca como lida
        notificacao.lida = true;

    });

    // Atualiza os cards e o contador
    mostrarNotificacoes();

});


/* ==========================================
   FECHAR AO CLICAR FORA DO PAINEL
========================================== */

document.addEventListener("click", function(event) {

    // Verifica se o clique aconteceu fora do sino e do painel
    const clicouFora =
        !btnSino.contains(event.target) &&
        !painel.contains(event.target);

    if (clicouFora) {

        painel.hidden = true;

        btnSino.setAttribute("aria-expanded", "false");

    }

});


/* ==========================================
   FECHAR AO APERTAR ESC
========================================== */

document.addEventListener("keydown", function(event) {

    if (event.key === "Escape") {

        painel.hidden = true;

        btnSino.setAttribute("aria-expanded", "false");

    }

});


/* ==========================================
   INICIALIZAÇÃO
========================================== */

// Exibe os cards de demonstração quando a página carrega

mostrarNotificacoes();
