"""Compatibilidade para código legado: delega à conexão central."""
from core.database import Database


def connect_db():
    return Database.connect()
