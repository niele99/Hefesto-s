"""CRUD genérico para os modelos do Hefesto's Stock.

Os nomes de tabela/coluna vêm exclusivamente das classes do projeto,
 nunca de parâmetros recebidos diretamente do navegador.
"""
import re
from core.database import Database

_IDENTIFICADOR = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


class CrudBase:
    table = ""
    fields = []
    primary_key = "id"

    @classmethod
    def _validar_identificador(cls, nome):
        # Protege os pontos em que SQL não aceita parâmetros (%s), como nomes de tabela.
        if not isinstance(nome, str) or not _IDENTIFICADOR.fullmatch(nome):
            raise ValueError(f"Identificador SQL inválido: {nome!r}")
        return nome

    @classmethod
    def _validar_modelo(cls):
        cls._validar_identificador(cls.table)
        cls._validar_identificador(cls.primary_key)
        for campo in cls.fields:
            cls._validar_identificador(campo)

    @classmethod
    def find_all(cls, order_by=None):
        """Retorna todos os registros. A ordenação só aceita campos do próprio modelo."""
        cls._validar_modelo()
        coluna = order_by or cls.primary_key
        if coluna not in cls.fields and coluna != cls.primary_key:
            raise ValueError("Campo de ordenação não permitido.")
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            cursor.execute(
                f"SELECT * FROM `{cls.table}` ORDER BY `{coluna}` ASC"
            )
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def search(cls, columns, termo):
        """Busca textual em colunas explicitamente autorizadas pelo modelo."""
        cls._validar_modelo()
        if not columns or any(coluna not in cls.fields for coluna in columns):
            raise ValueError("Colunas de pesquisa não permitidas.")
        if not termo:
            return cls.find_all()
        condicoes = " OR ".join(f"`{coluna}` LIKE %s" for coluna in columns)
        busca = f"%{termo.strip()}%"
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            cursor.execute(
                f"SELECT * FROM `{cls.table}` WHERE {condicoes} ORDER BY `{cls.primary_key}` ASC",
                tuple(busca for _ in columns),
            )
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def find_by_id(cls, registro_id):
        cls._validar_modelo()
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            cursor.execute(
                f"SELECT * FROM `{cls.table}` WHERE `{cls.primary_key}` = %s",
                (registro_id,),
            )
            return cursor.fetchone()
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def count(cls):
        cls._validar_modelo()
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            cursor.execute(f"SELECT COUNT(*) AS total FROM `{cls.table}`")
            resultado = cursor.fetchone()
            return resultado["total"] if resultado else 0
        finally:
            cursor.close()
            conexao.close()

    def insert(self):
        """Insere somente os campos declarados pelo modelo; retorna o ID gerado."""
        self._validar_modelo()
        if not self.fields:
            raise ValueError(f"O modelo {type(self).__name__} não declarou campos para INSERT.")
        colunas = ", ".join(f"`{campo}`" for campo in self.fields)
        marcadores = ", ".join(["%s"] * len(self.fields))
        valores = tuple(getattr(self, campo, None) for campo in self.fields)
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            cursor.execute(
                f"INSERT INTO `{self.table}` ({colunas}) VALUES ({marcadores})",
                valores,
            )
            conexao.commit()
            return cursor.lastrowid
        except Exception:
            conexao.rollback()
            raise
        finally:
            cursor.close()
            conexao.close()

    def update(self, registro_id):
        """Atualiza os campos do modelo e retorna quantas linhas foram afetadas."""
        self._validar_modelo()
        if not self.fields:
            raise ValueError(f"O modelo {type(self).__name__} não declarou campos para UPDATE.")
        atribuicoes = ", ".join(f"`{campo}` = %s" for campo in self.fields)
        valores = tuple(getattr(self, campo, None) for campo in self.fields) + (registro_id,)
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            cursor.execute(
                f"UPDATE `{self.table}` SET {atribuicoes} WHERE `{self.primary_key}` = %s",
                valores,
            )
            conexao.commit()
            return cursor.rowcount
        except Exception:
            conexao.rollback()
            raise
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def delete(cls, registro_id):
        cls._validar_modelo()
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            cursor.execute(
                f"DELETE FROM `{cls.table}` WHERE `{cls.primary_key}` = %s",
                (registro_id,),
            )
            conexao.commit()
            return cursor.rowcount
        except Exception:
            conexao.rollback()
            raise
        finally:
            cursor.close()
            conexao.close()
