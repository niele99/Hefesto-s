-- Execute somente em uma cópia/backup do banco e confira os dados antes.
-- Esta migração é para uma instalação já existente do Hefesto.
USE hefesto;

-- A chave de estoque_final é própria e não é a FK de produção.
-- A FK de produção permanece na coluna producao_id.
ALTER TABLE estoque_final
    MODIFY COLUMN id INT UNSIGNED NOT NULL AUTO_INCREMENT;

-- Padroniza a data de realização do pedido de fornecedor sem DROP/ADD.
ALTER TABLE pedido_fornecedor
    MODIFY COLUMN d_realizado_pedido_fornecedor TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- O campo de imagem correto do funcionário é foto_funcionario (LONGTEXT),
-- conforme o CREATE TABLE original. Não crie foto_nome/foto_localizacao/foto_blob.

-- Antes de adicionar esta FK, verifique se não existem referências órfãs:
-- SELECT hc.* FROM historico_compra hc
-- LEFT JOIN entrega_fornecedor ef ON ef.id = hc.entrega_fornecedor_id
-- WHERE ef.id IS NULL;
-- Execute o ALTER abaixo somente quando a consulta acima retornar zero linhas.
ALTER TABLE historico_compra
    ADD CONSTRAINT fk_historico_compra_entrega_fornecedor1
    FOREIGN KEY (entrega_fornecedor_id) REFERENCES entrega_fornecedor (id);
