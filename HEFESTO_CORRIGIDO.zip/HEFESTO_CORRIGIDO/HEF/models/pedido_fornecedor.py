"""Modelo de pedido de fornecedor conforme as colunas do banco."""
from datetime import datetime
from crud.crudBase import CrudBase


class PedidoFornecedor(CrudBase):
    table = "pedido_fornecedor"
    fields = [
        "d_entrega_pedido_fornecedor", "d_realizado_pedido_fornecedor",
        "quantidade_pedido_fornecedor", "item_pedido_pedido_fornecedor",
        "fornecedor_id", "funcionario_id",
    ]

    def __init__(self, d_entrega_pedido_fornecedor=None, d_realizado_pedido_fornecedor=None,
                 quantidade_pedido_fornecedor=None, item_pedido_pedido_fornecedor=None,
                 fornecedor_id=None, funcionario_id=None, **legado):
        self.d_entrega_pedido_fornecedor = d_entrega_pedido_fornecedor or legado.get("d_entrega")
        self.d_realizado_pedido_fornecedor = d_realizado_pedido_fornecedor or legado.get("d_realizacao") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.quantidade_pedido_fornecedor = quantidade_pedido_fornecedor or legado.get("quantidade")
        self.item_pedido_pedido_fornecedor = item_pedido_pedido_fornecedor or legado.get("item")
        self.fornecedor_id = fornecedor_id
        self.funcionario_id = funcionario_id
