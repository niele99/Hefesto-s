"""Modelo de produção com todas as FKs NOT NULL declaradas no schema."""
from datetime import datetime
from crud.crudBase import CrudBase


class Producao(CrudBase):
    table = "producao"
    fields = [
        "etapa_producao", "status_producao", "acontecimento_producao",
        "funcionario_id", "cliente_id", "pedido_cliente_id",
    ]

    def __init__(self, etapa_producao=None, status_producao=0,
                 acontecimento_producao=None, funcionario_id=None,
                 cliente_id=None, pedido_cliente_id=None, **legado):
        self.etapa_producao = etapa_producao
        self.status_producao = status_producao
        self.acontecimento_producao = acontecimento_producao or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.funcionario_id = funcionario_id
        self.cliente_id = cliente_id
        self.pedido_cliente_id = pedido_cliente_id
