"""Item associado a um produto dentro de um pedido de cliente."""
from crud.crudBase import CrudBase


class Item_pedido(CrudBase):
    table = "item_pedido"
    fields = ["ativado_item_pedido", "especificacoes_item_pedido", "produto_id", "pedido_cliente_id"]

    def __init__(self, ativado_item_pedido=0, especificacoes_item_pedido=None,
                 produto_id=None, pedido_cliente_id=None, **legado):
        self.ativado_item_pedido = ativado_item_pedido
        self.especificacoes_item_pedido = especificacoes_item_pedido or legado.get("especificacoes")
        self.produto_id = produto_id
        self.pedido_cliente_id = pedido_cliente_id
