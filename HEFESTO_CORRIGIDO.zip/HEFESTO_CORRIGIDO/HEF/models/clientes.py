"""Modelo de clientes. A chave primária da tabela é `id` (conforme o SQL)."""
from crud.crudBase import CrudBase
from core.database import Database
from core.validator import Validar
import re


class Cliente(CrudBase):
    table = "cliente"
    fields = [
        "nome_cliente", "cnpj_cliente", "email_cliente",
        "tel_cliente", "cep_cliente", "ativado_cliente",
    ]

    def __init__(self, nome_cliente=None, cnpj_cliente=None, email_cliente=None,
                 tel_cliente=None, cep_cliente=None, ativado_cliente=0):
        self.nome_cliente = nome_cliente
        self.cnpj_cliente = cnpj_cliente
        self.email_cliente = email_cliente
        self.tel_cliente = tel_cliente
        self.cep_cliente = cep_cliente
        self.ativado_cliente = ativado_cliente

    def validate(self):
        """Valida os campos antes de gravar, retornando uma lista legível de erros."""
        erros = []
        for valor, campo in (
            (self.nome_cliente, "Nome"), (self.cnpj_cliente, "CNPJ"),
            (self.email_cliente, "E-mail"), (self.tel_cliente, "Telefone"),
            (self.cep_cliente, "CEP"),
        ):
            erro = Validar.required(valor, campo)
            if erro:
                erros.append(erro)
        if self.cnpj_cliente and Validar.validar_cnpj(self.cnpj_cliente):
            erros.append("CNPJ inválido.")
        if self.email_cliente and Validar.email(self.email_cliente):
            erros.append("E-mail inválido.")
        if len(re.sub(r"\D", "", str(self.tel_cliente or ""))) not in (10, 11):
            erros.append("Telefone deve conter 10 ou 11 dígitos.")
        if len(re.sub(r"\D", "", str(self.cep_cliente or ""))) != 8:
            erros.append("CEP deve conter 8 dígitos.")
        return erros

    @classmethod
    def find_all_cliente(cls, termo=None):
        """Lista clientes ou filtra por nome, CNPJ, e-mail e telefone."""
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT * FROM cliente"
            valores = ()
            if termo:
                sql += (" WHERE nome_cliente LIKE %s OR cnpj_cliente LIKE %s "
                        "OR email_cliente LIKE %s OR tel_cliente LIKE %s")
                busca = f"%{termo.strip()}%"
                valores = (busca, busca, busca, busca)
            sql += " ORDER BY id ASC"
            cursor.execute(sql, valores)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def related_cliente(cls, cliente_id):
        """Impede exclusão física quando há pedidos ligados ao cliente."""
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            cursor.execute(
                "SELECT COUNT(*) FROM pedido_cliente WHERE cliente_id = %s",
                (cliente_id,),
            )
            return cursor.fetchone()[0] > 0
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def safe_delete_cliente(cls, cliente_id):
        if not cls.find_by_id(cliente_id):
            raise ValueError("Cliente não encontrado.")
        if cls.related_cliente(cliente_id):
            raise ValueError("Este cliente possui pedidos vinculados e não pode ser excluído.")
        return cls.delete(cliente_id)

    @classmethod
    def update_cliente(cls, cliente_id, dados):
        """Atualização compatível com os formulários antigos."""
        cliente = cls(**{campo: dados.get(campo) for campo in cls.fields})
        return cliente.update(cliente_id)
