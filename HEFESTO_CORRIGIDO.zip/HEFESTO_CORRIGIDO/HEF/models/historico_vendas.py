"""Histórico de venda com FKs para pedido de cliente e estoque final."""
from crud.crudBase import CrudBase


class HistoricoVendas(CrudBase):
    table = "historico_vendas"
    fields = [
        "d_entrega_historico_vendas", "d_realizacao_historico_vendas",
        "quantidade_historico_vendas", "valor_total_historico_vendas",
        "valor_unt_historico_vendas", "prazo_final_historico_vendas",
        "d_termino_historico_vendas", "pedido_cliente_id", "estoque_final_id",
    ]

    def __init__(self, d_entrega_historico_vendas=None, d_realizacao_historico_vendas=None,
                 quantidade_historico_vendas=None, valor_total_historico_vendas=None,
                 valor_unt_historico_vendas=None, prazo_final_historico_vendas=None,
                 d_termino_historico_vendas=None, pedido_cliente_id=None, estoque_final_id=None):
        self.d_entrega_historico_vendas = d_entrega_historico_vendas
        self.d_realizacao_historico_vendas = d_realizacao_historico_vendas
        self.quantidade_historico_vendas = quantidade_historico_vendas
        self.valor_total_historico_vendas = valor_total_historico_vendas
        self.valor_unt_historico_vendas = valor_unt_historico_vendas
        self.prazo_final_historico_vendas = prazo_final_historico_vendas
        self.d_termino_historico_vendas = d_termino_historico_vendas
        self.pedido_cliente_id = pedido_cliente_id
        self.estoque_final_id = estoque_final_id
