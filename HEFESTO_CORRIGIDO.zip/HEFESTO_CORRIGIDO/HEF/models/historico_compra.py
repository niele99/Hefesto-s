"""Histórico de compra; cada registro referencia uma entrega de fornecedor."""
from crud.crudBase import CrudBase


class historico_compra(CrudBase):
    table = "historico_compra"
    fields = ["d_entrega_historico_compra", "d_realizacao_historico_compra", "entrega_fornecedor_id"]

    def __init__(self, d_entrega_historico_compra=None,
                 d_realizacao_historico_compra=None, entrega_fornecedor_id=None):
        self.d_entrega_historico_compra = d_entrega_historico_compra
        self.d_realizacao_historico_compra = d_realizacao_historico_compra
        self.entrega_fornecedor_id = entrega_fornecedor_id
