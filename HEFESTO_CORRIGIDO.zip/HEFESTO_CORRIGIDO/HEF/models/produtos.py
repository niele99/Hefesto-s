"""Modelo de produto alinhado às colunas reais da tabela produto."""
from crud.crudBase import CrudBase


class Produto(CrudBase):
    table = "produto"
    fields = ["nome_produto", "dimensoes_produto", "imagem_produto", "minimo_produto", "ativado_produto"]

    def __init__(self, nome_produto=None, dimensoes_produto=None, imagem_produto=None,
                 minimo_produto=0, ativado_produto=0, **legado):
        # Aceita temporariamente os nomes antigos usados por alguns módulos.
        self.nome_produto = nome_produto if nome_produto is not None else legado.get("nome")
        self.dimensoes_produto = dimensoes_produto if dimensoes_produto is not None else legado.get("dimensoes")
        self.imagem_produto = imagem_produto if imagem_produto is not None else legado.get("imagem")
        self.minimo_produto = minimo_produto if minimo_produto is not None else legado.get("minimo", 0)
        self.ativado_produto = ativado_produto if ativado_produto is not None else legado.get("ativado", 0)

    @classmethod
    def inserir_produto(cls, dados):
        return cls(**dados).insert()
