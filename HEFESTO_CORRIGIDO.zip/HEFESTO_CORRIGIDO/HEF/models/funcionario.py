"""Modelo de funcionário conforme o esquema SQL (foto_funcionario é LONGTEXT)."""
from crud.crudBase import CrudBase
from core.database import Database
from core.security import verificar_senha, gerar_hash_senha


class Funcionario(CrudBase):
    table = "funcionario"
    fields = [
        "nome_funcionario", "tel_funcionario", "email_funcionario", "cpf_funcionario",
        "classificacao_funcionario", "cep_funcionario", "foto_funcionario",
        "num_clt_funcionario", "senha_funcionario", "ativado_funcionario",
    ]

    def __init__(self, nome_funcionario=None, tel_funcionario=None, email_funcionario=None,
                 cpf_funcionario=None, classificacao_funcionario=None, cep_funcionario=None,
                 foto_funcionario=None, num_clt_funcionario=None, senha_funcionario=None,
                 ativado_funcionario=0, **legado):
        self.nome_funcionario = nome_funcionario
        self.tel_funcionario = tel_funcionario
        self.email_funcionario = email_funcionario
        self.cpf_funcionario = cpf_funcionario
        self.classificacao_funcionario = classificacao_funcionario
        self.cep_funcionario = cep_funcionario
        # Compatibilidade: campos foto_nome/foto_localizacao/foto_blob não existem no SQL.
        self.foto_funcionario = foto_funcionario or legado.get("foto_blob") or ""
        self.num_clt_funcionario = num_clt_funcionario
        self.senha_funcionario = senha_funcionario
        self.ativado_funcionario = ativado_funcionario

    @staticmethod
    def autenticar(email_funcionario, senha_funcionario):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            cursor.execute(
                "SELECT * FROM funcionario WHERE email_funcionario = %s AND ativado_funcionario = 0",
                (email_funcionario,),
            )
            usuario = cursor.fetchone()
            if not usuario or not verificar_senha(senha_funcionario, usuario.get("senha_funcionario")):
                return None
            return usuario
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def inserir(cls, dados):
        # A senha é transformada em hash exatamente uma vez, antes do INSERT.
        dados = dict(dados)
        senha = dados.get("senha_funcionario")
        if not senha:
            raise ValueError("A senha do funcionário é obrigatória.")
        dados["senha_funcionario"] = gerar_hash_senha(senha)
        return cls(**dados).insert()

    @classmethod
    def listar_com_imagem(cls):
        return cls.find_all()

    @classmethod
    def buscar_por_id_com_imagem(cls, registro_id):
        return cls.find_by_id(registro_id)

    @classmethod
    def related_funcionario(cls, funcionario_id):
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            cursor.execute("SELECT COUNT(*) FROM producao WHERE funcionario_id = %s", (funcionario_id,))
            return cursor.fetchone()[0] > 0
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def safe_delete(cls, funcionario_id):
        if not cls.find_by_id(funcionario_id):
            raise ValueError("Funcionário não encontrado.")
        if cls.related_funcionario(funcionario_id):
            raise ValueError("Funcionário possui registros de produção vinculados.")
        return cls.delete(funcionario_id)
