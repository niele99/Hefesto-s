"""Relação de composição: quais matérias-primas entram em cada produto."""
from crud.crudBase import CrudBase


class Oque_vai(CrudBase):
    table = "oque_vai"
    fields = ["materia_prima_id", "produto_id", "quant_materia_prima"]

    def __init__(self, materia_prima_id=None, produto_id=None, quant_materia_prima=None):
        self.materia_prima_id = materia_prima_id
        self.produto_id = produto_id
        self.quant_materia_prima = quant_materia_prima
