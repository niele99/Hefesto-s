"""Modelo de pedido de cliente conforme tabela pedido_cliente."""
from crud.crudBase import CrudBase


class PedidoCliente(CrudBase):
    table = "pedido_cliente"
    fields = [
        "d_realizacao_pedido_cliente", "quantidade_pedido_cliente",
        "valor_unt_pedido_cliente", "valor_total_pedido_cliente",
        "prazo_final_pedido_cliente", "op_pedido_cliente",
        "funcionario_id", "cliente_id",
    ]

    def __init__(self, d_realizacao_pedido_cliente=None, quantidade_pedido_cliente=None,
                 valor_unt_pedido_cliente=None, valor_total_pedido_cliente=None,
                 prazo_final_pedido_cliente=None, op_pedido_cliente=0,
                 funcionario_id=None, cliente_id=None, **legado):
        self.d_realizacao_pedido_cliente = d_realizacao_pedido_cliente or legado.get("d_realizacao")
        self.quantidade_pedido_cliente = quantidade_pedido_cliente if quantidade_pedido_cliente is not None else legado.get("quantidade")
        self.valor_unt_pedido_cliente = valor_unt_pedido_cliente if valor_unt_pedido_cliente is not None else legado.get("valor_unt")
        self.valor_total_pedido_cliente = valor_total_pedido_cliente if valor_total_pedido_cliente is not None else legado.get("valor_total")
        self.prazo_final_pedido_cliente = prazo_final_pedido_cliente or legado.get("prazo_final")
        self.op_pedido_cliente = op_pedido_cliente
        self.funcionario_id = funcionario_id
        self.cliente_id = cliente_id
