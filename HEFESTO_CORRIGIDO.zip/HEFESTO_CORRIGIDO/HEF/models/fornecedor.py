"""Modelo de fornecedor, alinhado à tabela `fornecedor` do banco."""
from crud.crudBase import CrudBase


class Fornecedor(CrudBase):
    table = "fornecedor"
    fields = [
        "nome_fornecedor", "cnpj_fornecedor", "email_fornecedor",
        "tel_fornecedor", "cep_fornecedor", "materia_prima_fornecedor",
        "ativado_fornecedor",
    ]

    def __init__(self, nome_fornecedor=None, cnpj_fornecedor=None,
                 email_fornecedor=None, tel_fornecedor=None, cep_fornecedor=None,
                 materia_prima_fornecedor=None, ativado_fornecedor=0):
        self.nome_fornecedor = nome_fornecedor
        self.cnpj_fornecedor = cnpj_fornecedor
        self.email_fornecedor = email_fornecedor
        self.tel_fornecedor = tel_fornecedor
        self.cep_fornecedor = cep_fornecedor
        self.materia_prima_fornecedor = materia_prima_fornecedor
        self.ativado_fornecedor = ativado_fornecedor

    @classmethod
    def related_fornecedor(cls, fornecedor_id):
        """Verifica vínculo pela FK correta, não pelo ID da própria tabela."""
        from core.database import Database
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            cursor.execute(
                "SELECT COUNT(*) FROM pedido_fornecedor WHERE fornecedor_id = %s",
                (fornecedor_id,),
            )
            return cursor.fetchone()[0] > 0
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def safe_delete(cls, fornecedor_id):
        if not cls.find_by_id(fornecedor_id):
            raise ValueError("Fornecedor não encontrado.")
        if cls.related_fornecedor(fornecedor_id):
            raise ValueError("Fornecedor possui pedidos vinculados e não pode ser excluído.")
        return cls.delete(fornecedor_id)
