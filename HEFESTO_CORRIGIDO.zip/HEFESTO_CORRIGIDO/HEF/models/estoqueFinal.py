"""Modelo do estoque final, separado de Fornecedor e ligado à produção."""
from crud.crudBase import CrudBase


class EstoqueFinal(CrudBase):
    table = "estoque_final"
    fields = [
        "barracao_rua_estoque_final", "barracao_andar_estoque_final",
        "barracao_num_estoque_final", "producao_id",
    ]

    def __init__(self, barracao_rua_estoque_final=None,
                 barracao_andar_estoque_final=None,
                 barracao_num_estoque_final=None, producao_id=None):
        self.barracao_rua_estoque_final = barracao_rua_estoque_final
        self.barracao_andar_estoque_final = barracao_andar_estoque_final
        self.barracao_num_estoque_final = barracao_num_estoque_final
        self.producao_id = producao_id
