"""Operações específicas de autenticação; a autenticação principal está em Funcionario."""
from core.database import Database
from core.security import gerar_hash_senha


class Login:
    @staticmethod
    def update_senha(email, senha):
        if not email or not senha:
            raise ValueError("E-mail e nova senha são obrigatórios.")
        senha_hash = gerar_hash_senha(senha)
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            cursor.execute(
                "UPDATE funcionario SET senha_funcionario = %s WHERE email_funcionario = %s",
                (senha_hash, email),
            )
            conexao.commit()
            return cursor.rowcount
        except Exception:
            conexao.rollback()
            raise
        finally:
            cursor.close()
            conexao.close()
