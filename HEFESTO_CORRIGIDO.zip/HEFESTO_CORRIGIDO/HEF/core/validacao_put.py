"""Compatibilidade com funções antigas e consultas externas de validação.

As funções de atualização de listas foram mantidas apenas para não quebrar
imports antigos. As rotas novas devem atualizar os modelos/BD, não listas.
"""
import urllib.parse
import requests


def _atualizar_lista(indice, dados, lista):
    if not isinstance(lista, list) or not 0 <= indice < len(lista):
        raise IndexError("Registro não encontrado na lista legada.")
    lista[indice].update(dados)


def atualizar_prod(i, d, l): _atualizar_lista(i, d, l)
def atualizar_cliente(i, d, l): _atualizar_lista(i, d, l)
def atualizar_fornecedor(i, d, l): _atualizar_lista(i, d, l)
def atualizar_itens(i, d, l): _atualizar_lista(i, d, l)
def atualizar_producao(i, d, l): _atualizar_lista(i, d, l)
def atualizar_materiais(i, d, l): _atualizar_lista(i, d, l)
def atualizar_pagamentos(i, d, l): _atualizar_lista(i, d, l)
def atualizar_funcionarios(i, d, l): _atualizar_lista(i, d, l)
def atualizar_pedidocliente(i, d, l): _atualizar_lista(i, d, l)
def atualizar_pedido_fornecedor(i, d, l): _atualizar_lista(i, d, l)
def atualizar_oque_vai(i, d, l): _atualizar_lista(i, d, l)
def atualizar_item_pedido(i, d, l): _atualizar_lista(i, d, l)


def _consulta_api(url, token):
    try:
        resposta = requests.get(url, params={"token": token}, timeout=10)
        resposta.raise_for_status()
        return resposta.json()
    except requests.RequestException:
        return None


def extcep(cep, token):
    cep = urllib.parse.quote(str(cep or "").strip())
    return _consulta_api(f"https://api.invertexto.com/v1/cep/{cep}", token)


def extemail(email, token):
    email = urllib.parse.quote(str(email or "").strip())
    return _consulta_api(f"https://api.invertexto.com/v1/email-validator/{email}", token)


def extcnpj(cnpj, token):
    cnpj = urllib.parse.quote(str(cnpj or "").strip())
    return _consulta_api(f"https://api.invertexto.com/v1/validator/{cnpj}", token)
