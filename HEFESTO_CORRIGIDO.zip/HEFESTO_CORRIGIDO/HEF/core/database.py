"""Único ponto de criação de conexões MySQL do sistema."""
import mysql.connector
from mysql.connector import Error
from config import DB_CONFIG


class Database:
    @staticmethod
    def connect():
        try:
            return mysql.connector.connect(**DB_CONFIG)
        except Error as erro:
            # Mantém a causa original para o log/depuração sem mascarar o erro.
            raise RuntimeError(f"Não foi possível conectar ao MySQL: {erro}") from erro


def connect():
    """Compatibilidade temporária com módulos antigos que importam connect()."""
    return Database.connect()
