"""Camada de compatibilidade para validações antigas do projeto."""
from core.validator import Validar


def validar(dados):
    """Valida se o payload recebido contém ao menos um campo."""
    if not isinstance(dados, dict) or not dados:
        return {"valido": False, "mensagem": "Nenhum dado foi informado."}
    return {"valido": True, "mensagem": "Dados recebidos."}


def non_negative(value, field_name):
    return Validar.non_negative(value, field_name)


def validar_cnpj(cnpj_cliente):
    erro = Validar.validar_cnpj(cnpj_cliente)
    return erro or None
