"""Compatibilidade para imports antigos; não cria configuração paralela."""
from core.database import Database


def connect_db():
    return Database.connect()
