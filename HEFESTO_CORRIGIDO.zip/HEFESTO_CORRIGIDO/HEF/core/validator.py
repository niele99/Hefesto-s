"""Validações reutilizáveis; nenhuma função depende de variáveis globais ocultas."""
import re


class Validar:
    @staticmethod
    def required(valor, campo="Campo"):
        return None if valor is not None and str(valor).strip() else f"{campo} é obrigatório."

    @staticmethod
    def non_negative(valor, campo="Valor"):
        try:
            if float(valor) < 0:
                return f"{campo} não pode ser negativo."
        except (TypeError, ValueError):
            return f"{campo} deve ser numérico."
        return None

    @staticmethod
    def email(valor):
        if not valor or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", str(valor)):
            return "E-mail inválido."
        return None

    @staticmethod
    def somente_digitos(valor, tamanho=None, campo="Campo"):
        digitos = re.sub(r"\D", "", str(valor or ""))
        if not digitos.isdigit() or (tamanho is not None and len(digitos) != tamanho):
            return f"{campo} deve conter {tamanho} dígitos." if tamanho else f"{campo} deve conter apenas números."
        return None

    @staticmethod
    def validar_cnpj(valor):
        digitos = re.sub(r"\D", "", str(valor or ""))
        if len(digitos) != 14 or digitos == digitos[0] * 14:
            return "CNPJ inválido."
        numeros = [int(x) for x in digitos]
        for tamanho, pesos in ((12, (5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2)),
                               (13, (6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2))):
            soma = sum(numeros[i] * pesos[i] for i in range(tamanho))
            resto = soma % 11
            esperado = 0 if resto < 2 else 11 - resto
            if numeros[tamanho] != esperado:
                return "CNPJ inválido."
        return None

    @staticmethod
    def val_especial(valor):
        return bool(re.search(r"[!@#$%¨&*()_+=?/:;<>]", str(valor or "")))

    @staticmethod
    def validar_numero(valor):
        try:
            float(valor)
            return True
        except (TypeError, ValueError):
            return False

    @staticmethod
    def validar_quantidade(valor):
        try:
            return int(valor) > 0
        except (TypeError, ValueError):
            return False
