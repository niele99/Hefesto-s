"""Validações locais de CPF e nome, sem depender de API externa."""
import re


def validar_nome(nome):
    nome = str(nome or "").strip()
    if len(nome) < 3:
        return {"valida": False, "mensagem": "O nome deve ter pelo menos 3 caracteres."}
    if any(caractere.isdigit() for caractere in nome):
        return {"valida": False, "mensagem": "O nome não deve possuir números."}
    return {"valida": True, "mensagem": "Nome válido."}


def validar_cpf(cpf):
    digitos = re.sub(r"\D", "", str(cpf or ""))
    if len(digitos) != 11 or digitos == digitos[0] * 11:
        return {"valida": False, "mensagem": "CPF inválido."}
    numeros = [int(x) for x in digitos]
    soma = sum(numeros[i] * (10 - i) for i in range(9))
    d1 = (soma * 10) % 11
    d1 = 0 if d1 == 10 else d1
    soma = sum(numeros[i] * (11 - i) for i in range(10))
    d2 = (soma * 10) % 11
    d2 = 0 if d2 == 10 else d2
    valido = numeros[9] == d1 and numeros[10] == d2
    return {"valida": valido, "mensagem": "CPF válido." if valido else "CPF inválido."}
