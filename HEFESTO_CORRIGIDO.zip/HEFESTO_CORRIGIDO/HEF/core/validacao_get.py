"""Validação simples de identificadores de consulta."""


class val:
    @staticmethod
    def valid(value, field, registro_id):
        try:
            if int(registro_id) <= 0:
                return "O ID deve ser um inteiro positivo."
        except (TypeError, ValueError):
            return "O ID informado não é válido."
        if not field or not value:
            return "Campo ou valor não informado."
        return None
