#================================IMPORTAÇÕES====================================
import requests
import base64
import re
import os
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify

#=================================CLASSES==========================================
from core.validacao_put import atualizar_prod,atualizar_cliente,atualizar_fornecedor,atualizar_pedido_fornecedor,atualizar_itens,atualizar_producao,atualizar_materiais,atualizar_pagamentos,atualizar_pedidocliente,atualizar_funcionarios,atualizar_item_pedido,atualizar_oque_vai ,extcep,extemail,extcnpj
from core.validacao_post import validar_cpf, validar_nome
from core.validator import Validar
from core.security import gerar_hash_senha, login_obrigatorio
from config import SECRET_KEY

from models.clientes import Cliente
from models.fornecedor import Fornecedor
from models.pedido_fornecedor import PedidoFornecedor
from models.pedido_cliente import PedidoCliente
from models.funcionario import Funcionario
from models.produtos import Produto
from models.login import Login 
from models.materia_prima import Materia_prima
from models.producao import Producao
from models.item_pedido import Item_pedido
from models.oque_vai import Oque_vai
from models.estoqueFinal import EstoqueFinal
from models.historico_compra import historico_compra
from models.historico_vendas import HistoricoVendas


app= Flask(__name__)

app.secret_key = SECRET_KEY  # Segredo configurado por variável de ambiente.


@app.before_request
def exigir_login_nas_telas_internas():
    # Evita esquecer o decorador em alguma rota nova. Login e arquivos estáticos ficam públicos.
    if request.endpoint not in {"login", "static", "index", "pag_nao_encontrada"} and "id" not in session:
        return redirect(url_for("login"))

token = __import__("os").getenv("API_TOKEN", "")  # Nunca versionar tokens reais.

def to_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default

def to_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default




@app.route("/")
def index():
    if "id" in session:
        return redirect(url_for("dashboard"))

    return redirect(url_for("login"))


'''===================== LOGIN =========================='''



@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        # Pega os valores enviados pelos atributos 'name' do formulário HTML
        email = request.form.get("email_funcionario")
        senha = request.form.get("senha_funcionario")
        
        # Chama a autenticação da sua classe Funcionario
        usuario = Funcionario.autenticar(email, senha)
        
        if usuario:
            # Salva na sessão (caso 'usuario' seja objeto, use usuario.id / usuario.nome_funcionario)
            session["id"] = usuario.id if hasattr(usuario, "id") else usuario["id"]
            session["nome_funcionario"] = usuario.nome_funcionario if hasattr(usuario, "nome_funcionario") else usuario["nome_funcionario"]
            
            flash("Login realizado com sucesso!", "success")
            # Redireciona o navegador para a rota /dashboard
            return redirect(url_for("dashboard"))

        # Caso login falhe:
        flash("E-mail ou senha inválidos.", "danger")

    return render_template("login.html")



    


'''==================================== DASHBOARD =========================================='''

@app.route("/inicio")
@app.route("/dashboard")
@login_obrigatorio
def dashboard():
    estoque_baixo = Materia_prima().count_itens()
    vendas_total = PedidoCliente().count()
    producao_total = Producao().count()
    pedidos_total = PedidoFornecedor().count()

    return render_template(
        "dashboard.html",
        estoque_baixo=estoque_baixo,
        vendas_total=vendas_total,
        producao_total=producao_total,
        pedidos_total=pedidos_total
    )

'''================================= MODELOS =================================================='''

@app.route("/modelos")
def modelos():
    return render_template("modelo.html")

'''=================================== ENTRADA================================================='''
@app.route("/entrada")
def entrada():
    return render_template("entrada.html")


'''================================== TRATAMENTO DE ERRO - 404====================================='''
@app.errorhandler(404)
def pag_nao_encontrada(error):
    return render_template("404.html"),404


'''===================================== HISTÓRICO DE COMPRA ========================================='''
@app.route("/compras", methods=["GET"])
def rend_hist_compra():
    return render_template("historico_compra.html", compras=historico_compra.find_all())


'''==================================== HISTÓRICO DE VENDAS============================================'''
@app.route ("/vendas", methods=["GET"])
def rend_hist_vendas():
    return render_template("historico_vendas.html", vendas=HistoricoVendas.find_all())
'''================================== PERFIL USUARIO ==============================================='''
@app.route("/perfil", methods = ["GET"])
def rend_perfil():
    return render_template("perfil_usuario.html")


'''---------PRODUTO--------'''


def get_produto_form():
    # O formulário envia a imagem como arquivo; o banco atual armazena LONGTEXT.
    arquivo = request.files.get("imagem_produto")
    imagem = ""
    if arquivo and arquivo.filename:
        conteudo = arquivo.read()
        imagem = f"data:{arquivo.mimetype};base64," + base64.b64encode(conteudo).decode("ascii")

    return {
        "nome_produto": request.form.get("nomeProduto", "").strip().upper(),
        "dimensoes_produto": request.form.get("dimensoesProduto", "").strip(),
        "imagem_produto": imagem,
        "minimo_produto": to_int(request.form.get("estoqueMinimo", 0)),
        "ativado_produto": 0,
    }

@app.route("/produto", methods=["GET"])
def produto():
    return render_template("cad_produto.html")



'''========================RASTREIO==========================='''
@app.route("/rastreio", methods=["GET"])
def rend_rastreio():
    return render_template("rastreio.html")

# GET/DELETE consultam a tabela produto pelo ID real, não por índice de lista.
@app.route("/produto/<int:indice>", methods=["GET"])
def buscar_produto(indice):
    registro = Produto.find_by_id(indice)
    return (jsonify(registro), 200) if registro else (jsonify({"erro": "Produto não encontrado."}), 404)


@app.route("/produto/<int:indice>", methods=["POST", "DELETE"])
def deletar_produto(indice):
    try:
        removidos = Produto.delete(indice)
        return (jsonify({"mensagem": "Produto removido com sucesso!"}), 200) if removidos else (jsonify({"erro": "Produto não encontrado."}), 404)
    except Exception:
        app.logger.exception("Falha ao excluir produto %s", indice)
        return jsonify({"erro": "Produto possui vínculos ou não pôde ser excluído."}), 409

'''Post Produto'''
@app.route("/produto", methods=["POST"])
def produto_incluir():
    dados = get_produto_form()
    produto = Produto(**dados)
    try:
        if not dados["imagem_produto"]:
            raise ValueError("Selecione uma imagem para o produto.")
        produto.insert()
        flash("Produto cadastrado com sucesso.", "success")
        return redirect(url_for("produto"))
    except Exception as e:
        flash(f"Erro ao cadastrar : {e}", "erro")
        return render_template("cad_produto.html")

@app.route("/produto/<int:indice>", methods=["PUT"])
def atualizar_cadliv(indice):
    dados = request.get_json(silent=True) or {}
    if set(dados) - set(Produto.fields) or not dados:
        return jsonify({"erro": "Dados ausentes ou campos inválidos."}), 400
    atual = Produto.find_by_id(indice)
    if not atual:
        return jsonify({"erro": "Produto não encontrado."}), 404
    atual.update(dados)
    try:
        Produto(**{campo: atual.get(campo) for campo in Produto.fields}).update(indice)
        return jsonify({"mensagem": "Produto atualizado com sucesso."})
    except Exception:
        app.logger.exception("Falha ao atualizar produto %s", indice)
        return jsonify({"erro": "Não foi possível atualizar o produto."}), 500


"""---------CLIENTES-----------"""


@app.route("/cliente")
def cliente():
    return render_template("cad_cliente.html")


def get_cliente_form():
    # Os nomes abaixo correspondem aos atributos reais da tabela cliente.
    return {
        "nome_cliente": request.form.get("nome_cliente", "").strip().upper(),
        # Armazenamos somente dígitos porque o schema reserva 14 caracteres para CNPJ.
        "cnpj_cliente": re.sub(r"\D", "", request.form.get("cnpj_cliente", "")),
        "email_cliente": request.form.get("email_cliente", "").strip().lower(),
        "tel_cliente": re.sub(r"\D", "", request.form.get("tel_cliente", "")),
        "cep_cliente": re.sub(r"\D", "", request.form.get("cep_cliente", "")),
        # Checkbox marcado = inativo (1); desmarcado = ativo (0).
        "ativado_cliente": 1 if request.form.get("ativado_cliente") == "1" else 0,
    }


@app.route("/cliente/pesquisa", methods=["GET"])
def procurar_cliente():
    termo = request.args.get("q", "").strip()
    clientes = Cliente.find_all_cliente(termo or None)
    return render_template("consulta_cliente.html", cliente=clientes, termo=termo)


@app.route("/consulta/cliente", methods=["GET"])
def consulta_cliente():
    clientes = Cliente.find_all_cliente()
    return render_template("consulta_cliente.html", cliente=clientes, termo="")


@app.route("/consulta/funcionario", methods=["GET"])
def consulta_funcionario():
    termo = request.args.get("q", "").strip()
    registros = Funcionario.search(["nome_funcionario", "email_funcionario", "classificacao_funcionario"], termo) if termo else Funcionario.find_all()
    return render_template("consulta_funcionario.html", funcionarios=registros, termo=termo)


@app.route("/consulta/fornecedor", methods=["GET"])
def consulta_fornecedor():
    termo = request.args.get("q", "").strip()
    registros = Fornecedor.search(["nome_fornecedor", "cnpj_fornecedor", "materia_prima_fornecedor"], termo) if termo else Fornecedor.find_all()
    return render_template("consulta_fornecedor.html", fornecedores=registros, termo=termo)


@app.route("/consulta/produtos", methods=["GET"])
def consulta_produtos():
    termo = request.args.get("q", "").strip()
    registros = Produto.search(["nome_produto", "dimensoes_produto"], termo) if termo else Produto.find_all()
    return render_template("consulta_produtos.html", produtos=registros, termo=termo)


@app.route("/cliente/pesquisa/<int:indice>", methods=["POST", "DELETE"])
def deletar_cliente(indice):
    try:
        Cliente.safe_delete_cliente(indice)
        flash("Cliente excluído com sucesso.", "success")
    except ValueError as erro:
        flash(str(erro), "warning")
    except Exception as erro:
        app.logger.exception("Falha ao excluir cliente %s", indice)
        flash("Não foi possível excluir o cliente. Verifique os vínculos e o log.", "danger")
    return redirect(url_for("consulta_cliente"))


@app.route("/cadastro/cliente", methods=["POST"])
def cliente_incluir():
    dados = get_cliente_form()
    try:
        novo_cliente = Cliente(**dados)
        erros = novo_cliente.validate()
        if erros:
            for erro in erros:
                flash(erro, "warning")
            return render_template("cad_cliente.html"), 400
        # O CrudBase obtém o ID AUTO_INCREMENT; não se passa um ID manual.
        novo_cliente.insert()
        flash("Cliente cadastrado com sucesso.", "success")
        return redirect(url_for("cliente"))
    except Exception as erro:
        app.logger.exception("Falha ao cadastrar cliente")
        flash(f"Erro ao cadastrar cliente: {erro}", "danger")
        return render_template("cad_cliente.html"), 400


@app.route("/cliente/<int:indice>/editar", methods=["GET", "POST"])
def editar_cliente(indice):
    registro = Cliente.find_by_id(indice)
    if not registro:
        flash("Cliente não encontrado.", "warning")
        return redirect(url_for("consulta_cliente"))

    if request.method == "POST":
        dados = get_cliente_form()
        try:
            cliente_atualizado = Cliente(**dados)
            erros = cliente_atualizado.validate()
            if erros:
                for erro in erros:
                    flash(erro, "warning")
                registro.update(dados)
                return render_template("cad_cliente.html", cliente_edicao=registro), 400
            cliente_atualizado.update(indice)
            flash("Cliente atualizado com sucesso.", "success")
            return redirect(url_for("consulta_cliente"))
        except Exception as erro:
            app.logger.exception("Falha ao atualizar cliente %s", indice)
            flash(f"Erro ao atualizar cliente: {erro}", "danger")
            registro.update(dados)

    return render_template("cad_cliente.html", cliente_edicao=registro)


@app.route("/cliente/<int:indice>", methods=["PUT"])
def atualizar_cadcli(indice):
    # Endpoint JSON para integrações; formulários HTML usam POST /editar.
    dados = request.get_json(silent=True) or {}
    permitidos = set(Cliente.fields)
    if not dados or set(dados) - permitidos:
        return jsonify({"erro": "Dados ausentes ou campos não permitidos."}), 400
    atual = Cliente.find_by_id(indice)
    if not atual:
        return jsonify({"erro": "Cliente não encontrado."}), 404
    atual.update(dados)
    try:
        Cliente(**{campo: atual.get(campo) for campo in Cliente.fields}).update(indice)
        return jsonify({"mensagem": "Cliente atualizado com sucesso."})
    except Exception as erro:
        app.logger.exception("Falha ao atualizar cliente %s", indice)
        return jsonify({"erro": "Falha ao atualizar cliente."}), 500

"""-----------FORNECEDORES-------------"""


def get_fornecedor_form():
    print("request",request.form) 
    return {
        "nome_fornecedor": request.form.get("nome_fornecedor", "").strip() .upper(),
        "cnpj_fornecedor": request.form.get("cnpj_fornecedor","").strip(),
        "email_fornecedor": request.form.get("email_fornecedor","").strip(),
        "tel_fornecedor": request.form.get("tel_fornecedor","").strip(),
        "cep_fornecedor": request.form.get("cep_fornecedor","").strip(),
        # No sistema, 0 representa ativo e 1 inativo (mesma convenção do funcionário).
        "ativado_fornecedor": 0 if request.form.get("ativado_fornecedor") == "1" else 1,
        "materia_prima_fornecedor":request.form.get("materia_prima_fornecedor", "").strip()
    }



'''Get fornecedores'''
@app.route("/fornecedor/<int:indice>", methods=["GET"])
def list_fornecedor(indice):
    registro = Fornecedor.find_by_id(indice)
    return (jsonify(registro), 200) if registro else (jsonify({"erro": "Fornecedor não encontrado."}), 404)

'''Delete Fornecedores'''
@app.route("/fornecedor/<int:indice>", methods=["POST", "DELETE"])
def del_fornecedore(indice):
    try:
        removidos = Fornecedor.safe_delete(indice)
        return (jsonify({"mensagem": "Fornecedor removido com sucesso!"}), 200) if removidos else (jsonify({"erro": "Fornecedor não encontrado."}), 404)
    except ValueError as erro:
        return jsonify({"erro": str(erro)}), 409

'''Post Fornecedores'''
@app.route("/fornecedor", methods=["GET"])
def fornecedor():
    return render_template("cad_fornecedor.html")

@app.route("/cadastro/fornecedor", methods=["POST"])
def cad_fornecedor():
    dados = get_fornecedor_form()
    fornecedor = Fornecedor(**dados)
    try:
        fornecedor.insert()
        flash("Fornecedor cadastrado com sucesso.", "success")
        return redirect(url_for("fornecedor"))
    except Exception as e:
        flash(f"Erro ao cadastrar fornecedor: {e}", "danger")
    return render_template("cad_fornecedor.html")

@app.route("/fornecedor/<int:indice>", methods=["PUT"])
def atualizar_forne(indice):
    dados = request.get_json(silent=True) or {}
    if not dados or set(dados) - set(Fornecedor.fields):
        return jsonify({"erro": "Dados ausentes ou campos inválidos."}), 400
    atual = Fornecedor.find_by_id(indice)
    if not atual:
        return jsonify({"erro": "Fornecedor não encontrado."}), 404
    atual.update(dados)
    try:
        Fornecedor(**{campo: atual.get(campo) for campo in Fornecedor.fields}).update(indice)
        return jsonify({"mensagem": "Fornecedor atualizado com sucesso."})
    except Exception:
        app.logger.exception("Falha ao atualizar fornecedor %s", indice)
        return jsonify({"erro": "Não foi possível atualizar o fornecedor."}), 500

"""----------------MATERIA PRIMA--------------------"""

@app.route("/materiais", methods=["GET"])
def materiais():
    return render_template("cad_materiais.html")

@app.route("/materia-prima", methods=["GET"])
def materia_prima():
    return render_template("cad_materiais.html")


def get_materiais_form():
    # Os campos refletem exatamente a tabela materia_prima do SQL enviado.
    return {
        "nome_materia_prima": request.form.get("nome_materia_prima", "").strip().upper(),
        "d_validade_materia_prima": request.form.get("d_validade_materia_prima") or None,
        "estoque_materia_prima": to_int(request.form.get("estoque_materia_prima", 0)),
        "min_estoque_materia_prima": to_int(request.form.get("min_estoque_materia_prima", 0)),
        "d_ult_reposicao_materia_prima": request.form.get("d_ult_reposicao_materia_prima") or None,
        "descricao_materia_prima": request.form.get("descricao_materia_prima", "").strip(),
        "barracao_rua_materia_primacol": request.form.get("barracao_rua_materia_primacol", "").strip(),
        "barracao_andar_materia_prima": request.form.get("barracao_andar_materia_prima", "").strip(),
        "barracao_num_materia_prima": request.form.get("barracao_num_materia_prima", "").strip(),
        # Checkbox marcado = ativo (0); desmarcado = inativo (1).
        "ativado_materia_prima": 0 if request.form.get("ativado_materia_prima") == "1" else 1,
        "pedido_fornecedor_id": to_int(request.form.get("pedido_fornecedor_id", 0)),
    }

'''Get Materiais'''
@app.route("/materiais/<int:indice>", methods=["GET"])
def list_material(indice):
    registro = Materia_prima.find_by_id(indice)
    return (jsonify(registro), 200) if registro else (jsonify({"erro": "Material não encontrado."}), 404)

'''Delete Materiais'''
@app.route("/materiais/<int:indice>", methods = ["DELETE"])
def deletar_materiais(indice):
    try:
        removidos = Materia_prima.delete(indice)
        return (jsonify({"mensagem": "Material removido com sucesso!"}), 200) if removidos else (jsonify({"erro": "Material não encontrado."}), 404)
    except Exception:
        app.logger.exception("Falha ao excluir matéria-prima %s", indice)
        return jsonify({"erro": "Material possui vínculos ou não pôde ser excluído."}), 409

'''Post Materiais'''
@app.route("/materiais", methods=["POST"])
def material_incluir():
    dados = get_materiais_form()
    mp = Materia_prima(**dados)
    try:
        if not dados["pedido_fornecedor_id"]:
            raise ValueError("Selecione um pedido de fornecedor válido.")
        mp.insert()
        flash("Material cadastrado com sucesso.", "success")
        return redirect(url_for("materiais"))
    except Exception as e:
        flash(f"Erro ao cadastrar: {e}", "danger")
    return render_template("cad_materiais.html")

@app.route("/materiais/<int:indice>", methods=["PUT"])
def atualizar_materi(indice):
    dados = request.get_json(silent=True) or {}
    if not dados or set(dados) - set(Materia_prima.fields):
        return jsonify({"erro": "Dados ausentes ou campos inválidos."}), 400
    atual = Materia_prima.find_by_id(indice)
    if not atual:
        return jsonify({"erro": "Matéria-prima não encontrada."}), 404
    atual.update(dados)
    try:
        Materia_prima(**{campo: atual.get(campo) for campo in Materia_prima.fields}).update(indice)
        return jsonify({"mensagem": "Matéria-prima atualizada com sucesso."})
    except Exception:
        app.logger.exception("Falha ao atualizar matéria-prima %s", indice)
        return jsonify({"erro": "Não foi possível atualizar a matéria-prima."}), 500

"""----------------PEDIDO CLIENTE--------------------"""


def get_ped_cliente_form():
    print("request",request.form) 
    return {
        "d_realizacao_pedido_cliente": request.form.get("d_realizacao_pedido_cliente", "").strip() .upper(),
        "quantidade_pedido_cliente": request.form.get("quantidade_pedido_cliente","").strip(),
        "valor_unt_pedido_cliente": request.form.get("valor_unt_pedido_cliente","").strip(),
        "valor_total_pedido_cliente": request.form.get("valor_total_pedido_cliente","").strip(),
        "prazo_final_pedido_cliente": request.form.get("prazo_final_pedido_cliente","").strip(),
        "op_pedido_cliente":  request.form.get("op_pedido_cliente", "0").strip(),
        "funcionario_id": session.get("id"),
        "cliente_id": to_int(request.form.get("cliente_id", 0))
    }

'''Get PEDIDO CLIENTE'''

@app.route("/pedido_cliente", methods=["GET"])
def pedido_clientes():
    return render_template("pedido_cliente.html", pedidos=PedidoCliente.find_all())

'''Delete PEDIDO CLIENTE'''
@app.route("/pedido_cliente/<int:indice>", methods=["POST", "DELETE"])
def deletar_ped_cliente(indice):
    try:
        removidos = PedidoCliente.delete(indice)
        return (jsonify({"mensagem": "Pedido de cliente removido."}), 200) if removidos else (jsonify({"erro": "Pedido não encontrado."}), 404)
    except Exception:
        app.logger.exception("Falha ao excluir pedido de cliente %s", indice)
        return jsonify({"erro": "O pedido possui vínculos ou não pôde ser excluído."}), 409

'''Post PEDIDO CLIENTE'''
@app.route("/pedido_cliente", methods=["POST"])
def pedido_ped_cliente():
    dados = get_ped_cliente_form()
    try:
        ped_cli = PedidoCliente(**dados)
        ped_cli.insert()
        flash("Pedido cadastrado com sucesso.", "success")
        return redirect(url_for("pedido_clientes"))
    except Exception as e:
        flash(f"Erro ao cadastrar pedido: {e}", "danger")
    return render_template("pedido_cliente.html")

'''Put PEDIDO CLIENTE'''
@app.route("/pedido_cliente/<int:indice>", methods=["PUT"])
def atualizar_ped_cliente(indice):
    dados = request.get_json(silent=True) or {}
    if not dados or set(dados) - set(PedidoCliente.fields):
        return jsonify({"erro": "Dados ausentes ou campos inválidos."}), 400
    atual = PedidoCliente.find_by_id(indice)
    if not atual:
        return jsonify({"erro": "Pedido não encontrado."}), 404
    atual.update(dados)
    try:
        PedidoCliente(**{campo: atual.get(campo) for campo in PedidoCliente.fields}).update(indice)
        return jsonify({"mensagem": "Pedido atualizado com sucesso."})
    except Exception:
        app.logger.exception("Falha ao atualizar pedido de cliente %s", indice)
        return jsonify({"erro": "Não foi possível atualizar o pedido."}), 500         
'''Mensagem PEDIDO NÃO ENCONTRADO'''

"""----------------PRODUÇÃO--------------------"""
@app.route("/producao", methods=["GET"])
def producao():
    return render_template("producao.html", producoes=Producao.find_all())


def get_producao_form():
    print("request",request.form) 
    return {
        "etapa_producao": request.form.get("etapa_producao", "").strip() .upper(),
        "status_producao": request.form.get("status_producao","").strip(),
        "valor_unt_pedido_cliente": request.form.get("valor_unt_pedido_cliente","").strip(),
        "valor_total_pedido_cliente": request.form.get("valor_total_pedido_cliente","").strip(),
        "prazo_final_pedido_cliente": request.form.get("prazo_final_pedido_cliente","").strip(),
        "op_pedido_cliente":  request.form.get("op_pedido_cliente","").strip(),
    }

'''Get PRODUÇÃO'''
@app.route("/producao/<int:indice>", methods=["GET"])
def buscar_producao(indice):
    registro = Producao.find_by_id(indice)
    return (jsonify(registro), 200) if registro else (jsonify({"erro": "Produção não encontrada."}), 404)

'''Delete PRODUÇÃO'''
@app.route("/producao/<int:indice>", methods=["POST", "DELETE"])
def deletar_producao(indice):
    try:
        removidos = Producao.delete(indice)
        return (jsonify({"mensagem": "Registro de produção removido."}), 200) if removidos else (jsonify({"erro": "Produção não encontrada."}), 404)
    except Exception:
        app.logger.exception("Falha ao excluir produção %s", indice)
        return jsonify({"erro": "Produção possui vínculos ou não pôde ser excluída."}), 409

'''Post PRODUÇÃO'''
@app.route("/producao", methods=["POST"])
def producao_incluir():
    dados = request.get_json(silent=True) or request.form.to_dict()
    obrigatorios = set(Producao.fields)
    if not obrigatorios.issubset(dados):
        return jsonify({"erro": "Informe etapa, status e os IDs de funcionário, cliente e pedido."}), 400
    try:
        dados["funcionario_id"] = to_int(dados.get("funcionario_id"))
        dados["cliente_id"] = to_int(dados.get("cliente_id"))
        dados["pedido_cliente_id"] = to_int(dados.get("pedido_cliente_id"))
        Producao(**dados).insert()
        return jsonify({"mensagem": "Produção cadastrada com sucesso."}), 201
    except Exception:
        app.logger.exception("Falha ao cadastrar produção")
        return jsonify({"erro": "Não foi possível cadastrar a produção. Confira os IDs relacionados."}), 400

'''Put PRODUÇÃO'''
@app.route("/producao/<int:indice>", methods=["PUT"])
def atualizar_prod(indice):
    dados = request.get_json(silent=True) or {}
    if not dados or set(dados) - set(Producao.fields):
        return jsonify({"erro": "Dados ausentes ou campos inválidos."}), 400
    atual = Producao.find_by_id(indice)
    if not atual:
        return jsonify({"erro": "Produção não encontrada."}), 404
    atual.update(dados)
    try:
        Producao(**{campo: atual.get(campo) for campo in Producao.fields}).update(indice)
        return jsonify({"mensagem": "Produção atualizada com sucesso."})
    except Exception:
        app.logger.exception("Falha ao atualizar produção %s", indice)
        return jsonify({"erro": "Não foi possível atualizar a produção."}), 500

"""----------------PEDIDO FORNECEDOR--------------------"""

def get_ped_fornecedor_form():
    return {
        "d_entrega_pedido_fornecedor": request.form.get("d_entrega_pedido_fornecedor", "").strip(),
        # A coluna possui DEFAULT CURRENT_TIMESTAMP; o modelo define um fallback local.
        "d_realizado_pedido_fornecedor": request.form.get("d_realizado_pedido_fornecedor") or None,
        "quantidade_pedido_fornecedor": to_int(request.form.get("quantidade_pedido_fornecedor", 0)),
        "item_pedido_pedido_fornecedor": request.form.get("item_pedido_pedido_fornecedor", "").strip(),
        "fornecedor_id": to_int(request.form.get("fornecedor_id", 0)),
        "funcionario_id": session.get("id"),
    }

'''Get PEDIDO FORNECEDOR'''

@app.route("/pedido_fornecedor", methods=["GET"])
def pedido_fornecedor():
    return render_template("pedido_fornecedor.html", pedidos=PedidoFornecedor.find_all())

'''Delete PEDIDO FORNECEDOR'''
@app.route("/pedido_fornecedor/<int:indice>", methods=["POST", "DELETE"])
def del_ped_fornecedores(indice):
    try:
        removidos = PedidoFornecedor.delete(indice)
        return (jsonify({"mensagem": "Pedido de fornecedor excluído."}), 200) if removidos else (jsonify({"erro": "Pedido não encontrado."}), 404)
    except Exception:
        app.logger.exception("Falha ao excluir pedido de fornecedor %s", indice)
        return jsonify({"erro": "Pedido possui matérias-primas vinculadas ou não pôde ser excluído."}), 409

'''Post PEDIDO FORNECEDOR'''
@app.route("/p_fornecedor", methods=["POST"])
def cad_ped_fornecedor():
    dados = get_ped_fornecedor_form()
    try:
        if not dados["fornecedor_id"] or not dados["funcionario_id"]:
            raise ValueError("Selecione um fornecedor e entre com um funcionário autenticado.")
        ped_forn = PedidoFornecedor(**dados)
        ped_forn.insert()
        flash("Pedido cadastrado com sucesso.", "success")
        return redirect(url_for("pedido_fornecedor"))
    except Exception as e:
        flash(f"Erro ao cadastrar pedido: {e}", "danger")
    return render_template("pedido_fornecedor.html")

'''Put PEDIDO FORNECEDOR'''
@app.route("/pedido_fornecedor/<int:indice>", methods=["PUT"])
def atualizar_ped_fornecedor(indice):
    dados = request.get_json()
    if validar_put(dados) !=None:
        atualizar_pedido_fornecedor(indice, dados, ped_fornecedor)
        return jsonify({"mensagem": "Livro atualizado com sucesso!"})
    return jsonify ({"erro": "Livro não encontrado"}), 404

print(pedido_fornecedor)

"""----------------FUNCIONÁRIOS--------------------"""


def get_funcionario_form():
    # Nomes alinhados às colunas obrigatórias da tabela funcionario.
    return {
        "nome_funcionario": request.form.get("nome_funcionario", "").strip().upper(),
        "tel_funcionario": request.form.get("tel_funcionario", request.form.get("telefone_funcionario", "")).strip(),
        "email_funcionario": request.form.get("email_funcionario", "").strip().lower(),
        "cpf_funcionario": request.form.get("cpf_funcionario", "").strip(),
        "classificacao_funcionario": request.form.get("classificacao_funcionario", request.form.get("cargo_funcionario", "")).strip(),
        "cep_funcionario": request.form.get("cep_funcionario", "").strip(),
        "foto_funcionario": request.form.get("foto_funcionario", "").strip(),
        "num_clt_funcionario": request.form.get("num_clt_funcionario", "").strip(),
        "senha_funcionario": request.form.get("senha_funcionario", ""),
        "ativado_funcionario": 0,
    }
#>>>>>>>>>>pra renderizar a tela<<<<<<<<<<<
@app.route("/funcionario" , methods=["GET"])
def funcionario():
    return render_template("cad_funcionario.html", )

@app.route("/funcionario/<int:indice>", methods=["GET"])
def buscar_funcionario(indice):
    registro = Funcionario.find_by_id(indice)
    return (jsonify(registro), 200) if registro else (jsonify({"erro": "Funcionário não encontrado."}), 404)


@app.route("/funcionario/<int:indice>", methods=["POST", "DELETE"])
def deletar_funcionarios(indice):
    try:
        removidos = Funcionario.safe_delete(indice)
        return (jsonify({"mensagem": "Funcionário removido com sucesso."}), 200) if removidos else (jsonify({"erro": "Funcionário não encontrado."}), 404)
    except ValueError as erro:
        return jsonify({"erro": str(erro)}), 409

'''Post Funcionários'''
@app.route("/funcionario", methods=["POST"])
def funcionario_incluir():
    dados = get_funcionario_form()
    try:
        Funcionario.inserir(dados)
        flash("Novo funcionário cadastrado com sucesso.", "success")
        return redirect(url_for("funcionario"))
    except Exception as e:
        flash(f"Erro ao cadastrar : {e}", "danger")
    return render_template("cad_funcionario.html")


@app.route("/funcionario/<int:indice>", methods=["PUT"])
def atualizar_func(indice):
    dados = request.get_json(silent=True) or {}
    if not dados or set(dados) - set(Funcionario.fields):
        return jsonify({"erro": "Dados ausentes ou campos inválidos."}), 400
    atual = Funcionario.find_by_id(indice)
    if not atual:
        return jsonify({"erro": "Funcionário não encontrado."}), 404
    atual.update(dados)
    if dados.get("senha_funcionario"):
        atual["senha_funcionario"] = gerar_hash_senha(dados["senha_funcionario"])
    try:
        Funcionario(**{campo: atual.get(campo) for campo in Funcionario.fields}).update(indice)
        return jsonify({"mensagem": "Funcionário atualizado com sucesso."})
    except Exception:
        app.logger.exception("Falha ao atualizar funcionário %s", indice)
        return jsonify({"erro": "Não foi possível atualizar o funcionário."}), 500

# Itens de pedido: operações persistidas no MySQL.
@app.route("/itempedido", methods=["GET"])
def ites_pedido_get():
    return jsonify(Item_pedido.find_all())


@app.route("/itempedido/<int:indice>", methods=["GET"])
def itens_pedido(indice):
    registro = Item_pedido.find_by_id(indice)
    return (jsonify(registro), 200) if registro else (jsonify({"erro": "Item não encontrado."}), 404)


@app.route("/itempedido/<int:indice>", methods=["POST", "DELETE"])
def deletar_item_pedido(indice):
    try:
        removidos = Item_pedido.delete(indice)
        return (jsonify({"mensagem": "Item removido."}), 200) if removidos else (jsonify({"erro": "Item não encontrado."}), 404)
    except Exception:
        app.logger.exception("Falha ao excluir item de pedido %s", indice)
        return jsonify({"erro": "Item possui vínculos ou não pôde ser excluído."}), 409


@app.route("/itempedido", methods=["POST"])
def Item_incluir():
    dados = request.get_json(silent=True) or request.form.to_dict()
    try:
        dados["produto_id"] = to_int(dados.get("produto_id"))
        dados["pedido_cliente_id"] = to_int(dados.get("pedido_cliente_id"))
        Item_pedido(**dados).insert()
        return jsonify({"mensagem": "Item vinculado ao pedido com sucesso."}), 201
    except Exception:
        app.logger.exception("Falha ao inserir item de pedido")
        return jsonify({"erro": "Informe um produto e um pedido de cliente existentes."}), 400


@app.route("/item_pedido/<int:indice>", methods=["PUT"])
def atualizar_tabela_itempedido(indice):
    dados = request.get_json(silent=True) or {}
    if not dados or set(dados) - set(Item_pedido.fields):
        return jsonify({"erro": "Dados ausentes ou campos inválidos."}), 400
    atual = Item_pedido.find_by_id(indice)
    if not atual:
        return jsonify({"erro": "Item não encontrado."}), 404
    atual.update(dados)
    try:
        Item_pedido(**{campo: atual.get(campo) for campo in Item_pedido.fields}).update(indice)
        return jsonify({"mensagem": "Item atualizado."})
    except Exception:
        app.logger.exception("Falha ao atualizar item %s", indice)
        return jsonify({"erro": "Não foi possível atualizar o item."}), 500


# Composição de produto (matéria-prima utilizada).
@app.route("/oque_vai", methods=["GET"])
def oque_vai():
    return jsonify(Oque_vai.find_all())


@app.route("/oqvai/<int:indice>", methods=["GET"])
def o_q_vai(indice):
    registro = Oque_vai.find_by_id(indice)
    return (jsonify(registro), 200) if registro else (jsonify({"erro": "Composição não encontrada."}), 404)


@app.route("/oque_vai/<int:indice>", methods=["POST", "DELETE"])
def deletar_oque_vai(indice):
    try:
        removidos = Oque_vai.delete(indice)
        return (jsonify({"mensagem": "Composição removida."}), 200) if removidos else (jsonify({"erro": "Composição não encontrada."}), 404)
    except Exception:
        app.logger.exception("Falha ao excluir composição %s", indice)
        return jsonify({"erro": "Composição possui vínculos ou não pôde ser excluída."}), 409


@app.route("/oque_vai", methods=["POST"])
def oque_vai_incluir():
    dados = request.get_json(silent=True) or request.form.to_dict()
    try:
        dados["materia_prima_id"] = to_int(dados.get("materia_prima_id"))
        dados["produto_id"] = to_int(dados.get("produto_id"))
        Oque_vai(**dados).insert()
        return jsonify({"mensagem": "Matéria-prima vinculada ao produto."}), 201
    except Exception:
        app.logger.exception("Falha ao inserir composição de produto")
        return jsonify({"erro": "Informe uma matéria-prima e um produto existentes."}), 400


@app.route("/oque_vai/<int:indice>", methods=["PUT"])
def atualizar_tabela_oquevai(indice):
    dados = request.get_json(silent=True) or {}
    if not dados or set(dados) - set(Oque_vai.fields):
        return jsonify({"erro": "Dados ausentes ou campos inválidos."}), 400
    atual = Oque_vai.find_by_id(indice)
    if not atual:
        return jsonify({"erro": "Composição não encontrada."}), 404
    atual.update(dados)
    try:
        Oque_vai(**{campo: atual.get(campo) for campo in Oque_vai.fields}).update(indice)
        return jsonify({"mensagem": "Composição atualizada."})
    except Exception:
        app.logger.exception("Falha ao atualizar composição %s", indice)
        return jsonify({"erro": "Não foi possível atualizar a composição."}), 500

# Não existe tabela pagamento no schema recebido; não fingimos que a operação foi salva.
@app.route("/pagamento", methods=["GET", "POST"])
@app.route("/pagamento/<int:indice>", methods=["GET", "PUT", "DELETE"])
def pagamento_indisponivel(indice=None):
    return jsonify({
        "erro": "Módulo de pagamentos ainda não implementado no banco.",
        "motivo": "O schema hefesto não possui tabela pagamento. Defina os campos e vínculos antes de persistir."
    }), 501


# Estoque final: o ID do registro é próprio; a FK de produção é producao_id.
@app.route("/estoque/final", methods=["GET"])
def final_estoque():
    return jsonify(EstoqueFinal.find_all())


@app.route("/estoque/final/<int:indice>", methods=["DELETE", "POST"])
def deletar_estoque_final(indice):
    try:
        removidos = EstoqueFinal.delete(indice)
        return (jsonify({"mensagem": "Item removido do estoque final."}), 200) if removidos else (jsonify({"erro": "Item não encontrado."}), 404)
    except Exception:
        app.logger.exception("Falha ao excluir estoque final %s", indice)
        return jsonify({"erro": "Registro possui vínculos ou não pôde ser excluído."}), 409


@app.route("/estoque/final", methods=["POST"])
def estoque_final():
    dados = request.get_json(silent=True) or request.form.to_dict()
    try:
        dados["producao_id"] = to_int(dados.get("producao_id"))
        EstoqueFinal(**dados).insert()
        return jsonify({"mensagem": "Item adicionado ao estoque final."}), 201
    except Exception:
        app.logger.exception("Falha ao inserir estoque final")
        return jsonify({"erro": "Informe uma produção existente e a localização do barracão."}), 400


@app.route("/estoque/final/<int:indice>", methods=["PUT"])
def atualizar_estqfim(indice):
    dados = request.get_json(silent=True) or {}
    if not dados or set(dados) - set(EstoqueFinal.fields):
        return jsonify({"erro": "Dados ausentes ou campos inválidos."}), 400
    atual = EstoqueFinal.find_by_id(indice)
    if not atual:
        return jsonify({"erro": "Registro não encontrado."}), 404
    atual.update(dados)
    try:
        EstoqueFinal(**{campo: atual.get(campo) for campo in EstoqueFinal.fields}).update(indice)
        return jsonify({"mensagem": "Estoque final atualizado."})
    except Exception:
        app.logger.exception("Falha ao atualizar estoque final %s", indice)
        return jsonify({"erro": "Não foi possível atualizar o estoque final."}), 500


# Histórico de compra: a tabela exige referência a uma entrega de fornecedor.
@app.route("/histcompra", methods=["GET"])
def hist_compra():
    return jsonify(historico_compra.find_all())


@app.route("/histcompra/<int:indice>", methods=["GET"])
def compras(indice):
    registro = historico_compra.find_by_id(indice)
    return (jsonify(registro), 200) if registro else (jsonify({"erro": "Histórico de compra não encontrado."}), 404)


@app.route("/histcompra", methods=["POST"])
def hitorico_comprar():
    dados = request.get_json(silent=True) or request.form.to_dict()
    try:
        historico_compra(**dados).insert()
        return jsonify({"mensagem": "Histórico de compra registrado."}), 201
    except Exception:
        app.logger.exception("Falha ao registrar histórico de compra")
        return jsonify({"erro": "Informe datas válidas e uma entrega de fornecedor existente."}), 400


@app.route("/histcompra/<int:indice>", methods=["PUT"])
def att_hist(indice):
    dados = request.get_json(silent=True) or {}
    if not dados or set(dados) - set(historico_compra.fields):
        return jsonify({"erro": "Dados ausentes ou campos inválidos."}), 400
    atual = historico_compra.find_by_id(indice)
    if not atual:
        return jsonify({"erro": "Histórico de compra não encontrado."}), 404
    atual.update(dados)
    try:
        historico_compra(**{campo: atual.get(campo) for campo in historico_compra.fields}).update(indice)
        return jsonify({"mensagem": "Histórico de compra atualizado."})
    except Exception:
        app.logger.exception("Falha ao atualizar histórico de compra %s", indice)
        return jsonify({"erro": "Não foi possível atualizar o histórico."}), 500


@app.route("/histcompra/<int:indice>", methods=["DELETE"])
def del_compra(indice):
    removidos = historico_compra.delete(indice)
    return (jsonify({"mensagem": "Histórico de compra excluído."}), 200) if removidos else (jsonify({"erro": "Histórico não encontrado."}), 404)


# Histórico de vendas: vincula um pedido de cliente e um item do estoque final.
@app.route("/histvenda", methods=["GET"])
def hist_venda():
    return jsonify(HistoricoVendas.find_all())


@app.route("/histvenda/<int:indice>", methods=["GET"])
def ver_venda(indice):
    registro = HistoricoVendas.find_by_id(indice)
    return (jsonify(registro), 200) if registro else (jsonify({"erro": "Histórico de venda não encontrado."}), 404)


@app.route("/histvenda", methods=["POST"])
def ins_venda():
    dados = request.get_json(silent=True) or request.form.to_dict()
    try:
        HistoricoVendas(**dados).insert()
        return jsonify({"mensagem": "Histórico de venda registrado."}), 201
    except Exception:
        app.logger.exception("Falha ao registrar histórico de venda")
        return jsonify({"erro": "Confira as datas, valores e IDs de pedido/estoque informados."}), 400


@app.route("/histvenda/<int:indice>", methods=["PUT"])
def att_venda(indice):
    dados = request.get_json(silent=True) or {}
    if not dados or set(dados) - set(HistoricoVendas.fields):
        return jsonify({"erro": "Dados ausentes ou campos inválidos."}), 400
    atual = HistoricoVendas.find_by_id(indice)
    if not atual:
        return jsonify({"erro": "Histórico de venda não encontrado."}), 404
    atual.update(dados)
    try:
        HistoricoVendas(**{campo: atual.get(campo) for campo in HistoricoVendas.fields}).update(indice)
        return jsonify({"mensagem": "Histórico de venda atualizado."})
    except Exception:
        app.logger.exception("Falha ao atualizar histórico de venda %s", indice)
        return jsonify({"erro": "Não foi possível atualizar o histórico."}), 500


@app.route("/histvenda/<int:indice>", methods=["DELETE"])
def del_venda(indice):
    removidos = HistoricoVendas.delete(indice)
    return (jsonify({"mensagem": "Histórico de venda excluído."}), 200) if removidos else (jsonify({"erro": "Histórico não encontrado."}), 404)


# Não há tabela entrada no schema recebido; não retornar sucesso fictício.
@app.route("/entrada/<int:indice>", methods=["GET", "PUT", "DELETE"])
@app.route("/entrada", methods=["POST"])
def entrada_indisponivel(indice=None):
    return jsonify({
        "erro": "Módulo de entradas ainda não está implementado no banco.",
        "motivo": "O schema hefesto não possui tabela entrada. As entradas de fornecedor devem ser modeladas a partir de entrega_fornecedor."
    }), 501


'''========================== ENVIOS ===================================='''

#GET ENVIOS 

@app.route("/envios", methods=["GET"])
def rend_envio():
    return render_template("envios.html")


'''============================ ENVIOS DO DIA========================================'''
@app.route("/envio/envioDiario", methods= ["GET"])
def rend_envd():
   return render_template("envios_do_dia.html")


'''============================== MOVIMENTAÇÕES  ====================================='''

@app.route("/movimentacao", methods = ["GET"])
def rend_movimentacao():
        return render_template("movimentacoes.html")


'''============================= LOGOUT ========================================'''


@app.route("/logout")
def logout():
    session.clear()
    flash("Você saiu do sistema.", "info")
    return redirect(url_for("login"))


'''===================REDEFINIR SENHA==================='''
@app.route("/senha")
def nova_senha():
        return render_template ("redef.html")

if __name__ == "__main__":
    # Debug só deve ser ativado explicitamente no ambiente de desenvolvimento.
    app.run(debug=os.getenv("FLASK_DEBUG", "0") == "1")