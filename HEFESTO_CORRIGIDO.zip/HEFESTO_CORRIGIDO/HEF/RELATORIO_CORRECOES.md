# Hefesto's Stock — correções aplicadas e plano de substituição

## Escopo desta entrega

Esta revisão corrige a fundação de persistência, autenticação e os fluxos de cadastro/listagem mais evidentes. Ela **não declara o sistema inteiro pronto para produção**: a inspeção encontrou telas sem campos de formulário e módulos de negócio incompletos (pagamentos, entradas, itens, composição de produto, produção e históricos). Esses fluxos dependem de decisões de negócio e de campos que não estão presentes nas telas/modelos atuais. Não criei tabelas nem inventei regras para eles.

A identidade visual, Flask, Jinja, Bootstrap e o banco MySQL foram mantidos.

---

## Prioridade 0 — antes de executar o sistema

### 0.1 Configuração e credenciais

**Arquivos:** `config.py`, `.env.example`, `.gitignore`, `core/database.py`.

- Removida a senha MySQL fixa de `config.py`.
- Criada leitura de variáveis de ambiente e suporte opcional a `.env`.
- Criada uma chave de sessão de desenvolvimento com aviso no código; em produção, configure `FLASK_SECRET_KEY`.
- Centralizada a conexão MySQL em `Database.connect()`.
- O arquivo `.gitignore` impede versionar `.env`, ambientes virtuais e bytecode.
- `conectar.py` e `core/conexao.py` agora são wrappers de compatibilidade para `Database.connect()` e não mantêm credenciais/conexões paralelas.

**Como configurar:** copie `.env.example` para `.env` e informe os dados reais do seu MySQL. Não compartilhe o `.env`.

```env
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=sua_senha_real
DB_NAME=hefesto
FLASK_SECRET_KEY=uma_chave_aleatoria_longa
```

### 0.2 Dependências

**Arquivo:** `requirements.txt`.

- Corrigida a codificação para UTF-8.
- Removido `mysql-connector==2.2.9`, que conflita com o conector usado pelo código.
- Mantido somente `mysql-connector-python`, que fornece `mysql.connector`.
- Adicionado `python-dotenv` para carregar `.env`.

Instalação:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
```

### 0.3 CRUD genérico seguro

**Arquivo:** `crud/crudBase.py`.

- `find_all()` agora valida a coluna de ordenação contra os campos permitidos pelo modelo; antes o nome da coluna era interpolado livremente no SQL.
- `find_by_id()`, `count()`, `insert()`, `update()` e `delete()` usam a chave primária declarada e parâmetros `%s` para valores.
- `insert()` não recebe ID artificial; o banco gera o `AUTO_INCREMENT`.
- `insert()`, `update()` e `delete()` fazem `commit()` e `rollback()` corretamente.
- Removidos `print()` de SQL e valores pessoais.
- Incluídos comentários sobre identificadores SQL e transações.

**Substituição:** sobrescreva integralmente o antigo `crud/crudBase.py` pelo arquivo desta entrega.

---

## Prioridade 1 — cadastros e autenticação essenciais

### 1.1 Cliente — CRUD corrigido

**Arquivos:** `models/clientes.py`, `app.py`, `templates/consulta_cliente.html`, `templates/cad_cliente.html`.

Problemas resolvidos:
- A PK correta da tabela é `id`, não `cliente_id`.
- `find_all_cliente()` não exige mais um argumento obrigatório inexistente.
- A busca agora usa `cursor.execute(sql, valores)`, não `executemany()` com uma tupla incorreta.
- A consulta filtra nome, CNPJ, e-mail e telefone e ordena por `id`.
- A exclusão consulta a FK real `pedido_cliente.cliente_id`; antes consultava a própria tabela cliente.
- A rota de exclusão usa o `indice` recebido na URL, não uma variável global `id`.
- A atualização usa o ID da URL e persiste um objeto completo.
- O HTML usa a variável do loop `registro` e os nomes reais das colunas (`nome_cliente`, `cnpj_cliente`, etc.).
- O formulário de consulta agora envia o parâmetro `q`.
- Os botões Editar e Excluir apontam para rotas válidas. Exclusão via formulário usa POST, método aceito pelo HTML nativo.
- O formulário de cadastro também serve para edição, preenchendo os valores existentes.
- O checkbox de inativo envia `1` quando marcado e `0` quando desmarcado.

**Rotas entregues:**
- `GET /consulta/cliente`
- `GET /cliente/pesquisa?q=termo`
- `POST /cadastro/cliente`
- `GET /cliente/<id>/editar`
- `POST /cliente/<id>/editar`
- `POST /cliente/pesquisa/<id>`
- `PUT /cliente/<id>` para clientes JSON/API

**Substituição:** sobrescreva os arquivos citados. Não mantenha a versão antiga de `models/clientes.py`.

### 1.2 Fornecedor

**Arquivos:** `models/fornecedor.py`, `app.py`, `templates/consulta_fornecedor.html`.

- Reescrito o modelo, pois vários métodos estavam fora da classe por indentação incorreta.
- Corrigido o vínculo de exclusão para `pedido_fornecedor.fornecedor_id`.
- Listagem, busca textual, busca por ID e exclusão usam o banco.
- A tela de consulta deixou de exibir fornecedores fictícios e passou a iterar os registros reais.
- O botão Excluir agora envia POST para uma rota funcional e respeita os vínculos.
- Cadastro continua usando os campos reais da tabela `fornecedor`.

### 1.3 Produto

**Arquivos:** `models/produtos.py`, `app.py`, `templates/cad_produto.html`, `templates/consulta_produtos.html`.

- Corrigido o construtor: antes recebia `nome/dimensoes/imagem/minimo`, mas a rota enviava `nome_produto/dimensoes_produto/...`.
- Corrigida a consulta que usava `SELECT * IN produto`.
- O arquivo de imagem agora é enviado com `multipart/form-data`, convertido em Data URI e salvo no campo `imagem_produto` (`LONGTEXT`).
- O campo “Código” foi removido do formulário porque a tabela enviada não possui `codigo_produto`; manter esse campo dava a falsa impressão de que o código seria persistido.
- GET, DELETE, listagem e busca usam o ID real/MySQL, não uma posição em lista Python.
- A tela de consulta deixou de exibir produtos fictícios e passou a iterar registros do banco.

### 1.4 Funcionário e senha

**Arquivos:** `models/funcionario.py`, `app.py`, `templates/cad_funcionario.html`, `templates/consulta_funcionario.html`, `core/security.py`.

- O SQL define uma única coluna `foto_funcionario`; o modelo antigo tentava gravar `foto_nome`, `foto_localizacao` e `foto_blob`, que não existem na tabela. O modelo foi alinhado ao SQL.
- Corrigidos os nomes de telefone e cargo no HTML.
- Incluídos CEP e número CLT no formulário, pois são `NOT NULL` no banco.
- A senha é criptografada uma única vez no método `Funcionario.inserir()`; antes a rota fazia hash e o modelo poderia fazer hash novamente.
- A autenticação compara a senha com o hash bcrypt sem recriptografar a senha digitada.
- A consulta retorna um dicionário; a rota de login já trata esse formato.
- Adicionada proteção global às rotas internas: sem sessão, o usuário é redirecionado para `/login`.
- A consulta de funcionários agora exibe registros do MySQL e oferece busca e exclusão segura, em vez de dados de demonstração.

**Atenção:** contas antigas com senha em texto puro não passam na verificação bcrypt. Redefina essas senhas pelo fluxo de recuperação/cadastro administrativo; não recomendo aceitar texto puro como fallback.

### 1.5 Pedidos, produção, itens e composição

**Arquivos:** `models/pedido_cliente.py`, `models/pedido_fornecedor.py`, `models/producao.py`, `models/item_pedido.py`, `models/oque_vai.py`, `app.py`.

- Corrigido `PedidoCliente.table`, que apontava para `cliente` em vez de `pedido_cliente`.
- Os modelos de pedido e produção agora incluem as FKs obrigatórias que o schema exige.
- Pedido de fornecedor foi alinhado aos nomes reais (`d_entrega_pedido_fornecedor`, `quantidade_pedido_fornecedor`, etc.) e às FKs de fornecedor/funcionário.
- Produção exige funcionário, cliente e pedido de cliente; os endpoints deixam de responder “sucesso” apenas por validar um JSON e tentam persistir de verdade.
- `item_pedido` e `oque_vai` foram reescritos com todas as colunas/FKs e seus endpoints principais passaram a usar MySQL.
- Os endpoints de consulta e exclusão de pedido e produção foram retirados das listas em memória.

**Atenção:** as telas de pedido/produção entregues não apresentam campos `name` suficientes para todos esses vínculos. Os endpoints JSON estão prontos para receber os campos; a interface ainda precisa de seletores de cliente, fornecedor, produto e pedido.

### 1.6 Estoque final e históricos

**Arquivos:** `models/estoqueFinal.py`, `models/historico_compra.py`, `models/historico_vendas.py`, `models/entrega_fornecedor.py`, `app.py`.

- Corrigido o modelo de estoque final, que estava nomeado como `Fornecedor` e não representava as FKs da tabela.
- `estoque_final` passou a usar CRUD real no MySQL.
- Histórico de compra agora inclui `entrega_fornecedor_id` obrigatório.
- Histórico de venda agora inclui `pedido_cliente_id` e `estoque_final_id` obrigatórios.
- GET/POST/PUT/DELETE dos históricos usam o banco, não listas Python.
- Rotas de entrada e pagamento retornam HTTP 501 explicando que as tabelas não existem no SQL; isso evita confirmar uma gravação que nunca aconteceu.

### 1.7 Matéria-prima

**Arquivos:** `app.py`, `models/materia_prima.py`.

- Corrigido o helper que por engano devolvia os campos de fornecedor.
- O formulário agora é convertido para os campos da tabela `materia_prima`.
- GET e DELETE usam o banco em vez de listas inexistentes.
- O contador do dashboard agora conta materiais em que `estoque_materia_prima <= min_estoque_materia_prima`.
- Mantive o nome `barracao_rua_materia_primacol`, apesar de estranho, porque esse é o nome real no SQL enviado. Renomeá-lo exige migração coordenada do banco e do código.

**Atenção:** `pedido_fornecedor_id` é obrigatório e precisa apontar para um pedido existente. Datas também são `NOT NULL` no schema. O formulário precisa fornecer esses dados válidos.

---

## Prioridade 2 — integridade do banco

**Arquivos:** `hefestostock_database.sql` e `MIGRACAO_BANCO.sql`.

- O SQL de criação não executa mais `DROP COLUMN` seguido de `ADD COLUMN` em `pedido_fornecedor` a cada execução. A coluna `d_realizado_pedido_fornecedor` já nasce `TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP`.
- `estoque_final.id` foi definido como `AUTO_INCREMENT` na criação. A FK para produção continua na coluna `producao_id`.
- Adicionada a FK de `historico_compra.entrega_fornecedor_id` para `entrega_fornecedor.id`, que estava sem restrição no schema.
- Criada migração separada para bancos já existentes. Faça backup antes de executá-la.

**Importante:** o arquivo de criação é para banco novo. Para uma base já populada, não rode o arquivo inteiro por cima dos dados: revise e execute `MIGRACAO_BANCO.sql` em uma cópia primeiro.

---

## Prioridade 3 — validações

**Arquivos:** `core/validator.py`, `core/validacao_post.py`, `core/validacao_put.py`.

- Removidas referências a variáveis inexistentes como `insert`, `valor`, `qtd`, `texto`, `ipa` e `erro`.
- Corrigida a chamada de regex para receber texto, não o tamanho do texto.
- Criada validação local de CPF com cálculo dos dígitos verificadores.
- Criada validação de CNPJ com cálculo dos dígitos verificadores; cliente também valida nome, e-mail, telefone e CEP antes do INSERT/UPDATE.
- CNPJ, telefone e CEP do cliente são normalizados para somente dígitos antes de gravar, respeitando os tamanhos definidos no schema.
- Corrigidos os nomes das exceções `requests.RequestException` e adicionados timeouts às chamadas externas.
- Mantidas as funções antigas de atualização de listas apenas por compatibilidade temporária; novas rotas não devem usá-las.

---

## O que ainda precisa de uma segunda etapa antes de afirmar que TODO o sistema funciona

1. **Pedido de cliente:** a tabela exige `funcionario_id` e `cliente_id`; a tela enviada não possui campos `name` correspondentes. O backend já prepara esses vínculos, mas o formulário precisa permitir selecionar um cliente e enviar os dados obrigatórios.
2. **Pedido de fornecedor:** a tabela exige `fornecedor_id` e `funcionario_id`; a tela atual não apresenta campos de formulário identificáveis. O modelo foi alinhado ao schema, mas a tela precisa ser construída/conectada.
3. **Produção:** a tabela exige `funcionario_id`, `cliente_id` e `pedido_cliente_id`, além de etapa, status e data/hora. A tela atual não fornece esse conjunto.
4. **Interface de item de pedido e `oque_vai`:** os modelos e endpoints foram alinhados ao schema, mas as telas precisam de seletores e validação de produto, pedido e matéria-prima.
5. **Pagamento e entrada:** existem rotas/telas, mas não existem tabelas `pagamento` ou `entrada` no SQL fornecido. É necessário definir campos, vínculos, valores e regras antes de criar schema.
6. **Históricos:** as rotas e modelos agora persistem no banco; falta decidir se os registros devem ser gerados automaticamente ao concluir uma compra/venda ou se haverá cadastro manual na interface.
7. **Templates legados não utilizados:** `formulario_pedido.html`, `pedidos.html`, `formulario_produto.html` e `produtos.html` contêm `url_for()` para endpoints que não existem. Eles não são renderizados pelas rotas ativas identificadas; antes de reativá-los, seus endpoints devem ser criados ou os links corrigidos. As telas de consulta de cliente, fornecedor, funcionário e produto agora usam dados reais.
8. **Telas de pedido/produção:** as rotas persistem dados, mas as telas de pedido/produção ainda precisam enviar as FKs obrigatórias por seletores reais.
9. **Segurança complementar:** adicionar proteção CSRF, política de sessão segura, limite/tamanho para upload de imagem e autorização por perfil/cargo.
10. **Testes integrados:** é necessário executar contra o MySQL real com backup e dados de teste. A máquina de revisão não possui Flask instalado nem acesso ao seu MySQL, portanto foi possível validar sintaxe Python, mas não confirmar consultas reais ou login em banco.

---

## Teste de validação realizado nesta entrega

- `python -m compileall -q app.py config.py conectar.py core crud models`: compilação sintática concluída sem erros.
- Não foi possível importar/executar o Flask nesta máquina de revisão porque Flask não está instalado neste ambiente (`ModuleNotFoundError: No module named 'flask'`). Instale as dependências pelo `requirements.txt` antes de executar.
- Não foi executada migração nem escrita no banco do usuário.

## Ordem recomendada para testar no seu computador

1. Configurar `.env`, ativar `.venv` e instalar `requirements.txt`.
2. Fazer backup do banco `hefesto`.
3. Aplicar a migração SQL na cópia e conferir os dados.
4. Iniciar o Flask e testar login/logout.
5. Cadastrar, listar, pesquisar, editar e excluir um cliente sem pedidos vinculados.
6. Repetir CRUD para fornecedor, produto e matéria-prima.
7. Testar exclusão bloqueada quando houver FK.
8. Só então iniciar a etapa de pedidos, produção, estoque final, entradas e históricos.
