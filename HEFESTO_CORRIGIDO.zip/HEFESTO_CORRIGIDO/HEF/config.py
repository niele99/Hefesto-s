"""Configuração central. Defina as variáveis de ambiente no computador/servidor."""
import os

# Carrega variáveis de um arquivo .env local, se python-dotenv estiver instalado.
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

DB_CONFIG = {
    "host":"localhost",
    "user": "root",
    # Não mantenha a senha real versionada no Git.
    "password":  "123456",
    "database":  "hefesto",
    "port":  "3306",
    "charset": "utf8mb4",
    'auth_plugin': 'mysql_native_password'
}

SECRET_KEY = os.getenv("FLASK_SECRET_KEY")
if not SECRET_KEY:
    # Valor de desenvolvimento apenas; configure FLASK_SECRET_KEY em produção.
    SECRET_KEY = "dev-only-change-this-key"
