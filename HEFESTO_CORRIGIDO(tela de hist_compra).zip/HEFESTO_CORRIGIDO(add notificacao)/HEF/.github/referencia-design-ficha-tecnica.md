# REFERÊNCIA VISUAL — FICHA TÉCNICA

Este arquivo contém o CSS original da tela Ficha Técnica.

Utilize-o exclusivamente como referência visual para reproduzir:
- Cores;
- Tipografia;
- Espaçamentos;
- Bordas;
- Sombras;
- Inputs;
- Botões;
- Tabelas;
- Responsividade.

Não copie diretamente os seletores CSS.

## CSS ORIGINAL

```css
/* =================FICHA TECNICA=================================================================================================== */

/* ---------------- fundo ---------------- */

body.pagina-ficha-tecnica {
    margin: 0;
    padding: 20px 20px 60px;
    background: linear-gradient(
        135deg,
        #f5e4e2 0%,
        #fdfaf7 100%
    );
    font-family: Arial, Helvetica, sans-serif;
    color: #2b2b2b;
}

/* ---------------- container pricipal ---------------- */
.pagina-ficha-tecnica .container-pai_ficha-tec {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    min-height: 100vh;
    width: 100%;
    max-width: 1280px;
    margin: 0 auto;
    padding: 0;
    box-sizing: border-box;
    gap: 0;
    background: transparent;
    border: none;
    box-shadow: none;
}

/* ---------------- nav seleção de telas ---------------- */
.pagina-ficha-tecnica .menu-selecao-tela {
    position: sticky;
    top: 20px;
    z-index: 20;
    width: min(100%, 760px);
    margin: 0 auto 35px;
    padding: 7px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 5px;
    background: #ffffff;
    border-radius: 50px;
    border: 1px solid rgba(139, 0, 0, 0.08);
    box-shadow: 0 7px 20px rgba(65, 40, 35, 0.12);
}

/* itens da nav*/
.pagina-ficha-tecnica .menu-selecao-tela .menu-item {
    flex: 1;
    min-height: 52px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    border-radius: 40px;
    text-decoration: none;
    color: #8b0000;
    font-size: 14px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.03em;
    transition: all 0.2s ease;
    background: transparent;
}

/* ícones do menu */
.pagina-ficha-tecnica .menu-item i {
    font-size: 22px;
    line-height: 1;
}

/* hover do menu */
.pagina-ficha-tecnica .menu-item:hover {
    background: #f6e5e3;
    color: #8b0000;
    text-decoration: none;
}

/* item ativo */
.pagina-ficha-tecnica .menu-item.ativo {
    background: #8b0000;
    color: #ffffff;
    box-shadow: inset 0 0 0 1px rgba(255,255,255,0.08);
}

.pagina-ficha-tecnica .menu-item.ativo:hover {
    background: #8b0000;
    color: #ffffff;
}

/* ---------------- container do conteúdo ---------------- */
.pagina-ficha-tecnica .container_ficha-tec {
    width: 100%;
    max-width: 1180px;
    margin: 0 auto;
    padding: 30px 28px;
    box-sizing: border-box;
    background: rgba(255, 255, 255, 0.95);
    border: 1px solid rgba(139, 0, 0, 0.08);
    border-radius: 24px;
    box-shadow: 0 10px 30px rgba(80, 40, 35, 0.08);
}

/* ---------------- cabeçalho ---------------- */
.pagina-ficha-tecnica .header_ficha-tec {
    width: 100%;
    margin-bottom: 28px;
}

.pagina-ficha-tecnica .titulo_ficha-tec {
    margin: 0;
    color: #8b0000;
    font-size: clamp(2rem, 3vw, 3rem);
    font-weight: 800;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    line-height: 1.1;
}

.pagina-ficha-tecnica .subtitulo_ficha-tec {
    margin: 10px 0 0;
    color: #6c4c4d;
    font-size: 1.1rem;
    line-height: 1.5;
}

/* ========================= Divisão dos dois cards ================================================================================= */
.pagina-ficha-tecnica .conteudo_ficha-tec {
    display: grid;
    grid-template-columns: 1fr 1fr;
    align-items: stretch;
    gap: 30px;
    width: 100%;
}

/* ---------------- cards ---------------- */
.pagina-ficha-tecnica .card_ficha-tec {
    min-width: 0;
    padding: 28px;
    box-sizing: border-box;
    background: #ffffff;
    border: 1px solid rgba(139, 0, 0, 0.08);
    border-radius: 20px;
    box-shadow: 0 6px 20px rgba(80, 40, 35, 0.07);
}

/* ---------------- títulos ---------------- */
.pagina-ficha-tecnica .container_ficha-tec h2,
.pagina-ficha-tecnica .container_ficha-tec h3 {
    color: #8b0000;
    font-weight: 700;
    margin-top: 0;
    margin-bottom: 25px;
}

.pagina-ficha-tecnica .card-titulo_ficha-tec {
    font-size: 1.2rem;
}

/* ---------------- labels ---------------- */
.pagina-ficha-tecnica .container_ficha-tec label {
    display: block;
    margin-bottom: 8px;
    color: #573b3b;
    font-size: 0.95rem;
    font-weight: 700;
}

/* ---------------- campos ---------------- */
.pagina-ficha-tecnica .campo_ficha-tec {
    margin-bottom: 24px;
}

/* ---------------- INPUTS E SELECTS ---------------- */
.pagina-ficha-tecnica .container_ficha-tec input:not([type="checkbox"]):not([type="radio"]),
.pagina-ficha-tecnica .container_ficha-tec select {
    width: 100%;
    max-width: 100%;
    display: block;
    min-height: 48px;
    padding: 10px 15px;
    margin-bottom: 0;
    box-sizing: border-box;
    background-color: #fffdfd;
    border: 1px solid #e3c9c9;
    border-radius: 10px;
    color: #2b2b2b;
    font-family: Arial, Helvetica, sans-serif;
    font-size: 1rem;
    outline: none;
    box-shadow: none;
    transition: all 0.2s ease;
}

/* placeholder */
.pagina-ficha-tecnica .container_ficha-tec input::placeholder {
    color: #a99695;
}

/* foco dos focos */
.pagina-ficha-tecnica .container_ficha-tec input:focus,
.pagina-ficha-tecnica .container_ficha-tec select:focus {
    border-color: #a51f22;
    background-color: #ffffff;
    box-shadow: 0 0 0 3px rgba(139, 0, 0, 0.10);
}

/* cursor dos selects */
.pagina-ficha-tecnica .container_ficha-tec select {
    cursor: pointer;
}

/* ---------------- botão adicionar ---------------- */
.pagina-ficha-tecnica .container_ficha-tec button,
.pagina-ficha-tecnica .container_ficha-tec input[type="submit"] {
    display: block;
    min-height: 44px;
    padding: 10px 22px;
    margin: 22px auto;
    border: 1px solid #8b0000;
    border-radius: 30px;
    background: linear-gradient(
        135deg,
        #8b0000,
        #b32626
    );
    color: #ffffff;
    font-size: 0.95rem;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.2s ease;
}


/* hover do botão */
.pagina-ficha-tecnica .container_ficha-tec button:hover,
.pagina-ficha-tecnica .container_ficha-tec input[type="submit"]:hover {
    background: #a51f22;
    box-shadow: 0 6px 15px rgba(139, 0, 0, 0.18);
    transform: translateY(-1px);
}

/* ---------------- tabelas ---------------- */
.pagina-ficha-tecnica .container_ficha-tec table {
    width: 100%;
    margin-top: 15px;
    border-collapse: separate;
    border-spacing: 0;
    overflow: hidden;
    border: 1px solid rgba(139, 0, 0, 0.08);
    border-radius: 14px;
    background: #ffffff;
}

/* cabeçalho da tabela */
.pagina-ficha-tecnica .container_ficha-tec table thead th {
    padding: 16px 14px;
    background: linear-gradient(
        180deg,
        #f8efef,
        #f4e9e9
    );
    color: #8b0000;
    font-size: 0.82rem;
    font-weight: 800;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    text-align: left;
    border-bottom: 1px solid rgba(139, 0, 0, 0.08);
}

/* células da tabela */
.pagina-ficha-tecnica .container_ficha-tec table tbody td {
    padding: 16px 14px;
    color: #2f2f2f;
    font-size: 0.95rem;
    background: #ffffff;
    border-bottom: 1px solid rgba(139, 0, 0, 0.08);
}

/* linhas alternadas */
.pagina-ficha-tecnica .container_ficha-tec table tbody tr:nth-child(odd) td {
    background: #fffaf9;
}

/* última linha */
.pagina-ficha-tecnica .container_ficha-tec table tbody tr:last-child td {
    border-bottom: none;
}

/* ---------------- divisórias ---------------- */
.pagina-ficha-tecnica .container_ficha-tec hr {
    border: none;
    border-top: 1px solid #f0c8c8;
    margin: 25px 0;
}


/* ============= Botão Salvar ========================== */
.area-botao-salvar_ficha-tec {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    margin-top: 25px;
}

.botao-salvar_ficha-tec {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 9px;
    min-width: 180px;
    padding: 12px 30px;
    background-color: #8b0000;
    color: #ffffff;
    border: none;
    border-radius: 10px;
    font-size: 15px;
    font-weight: 600;
    transition: 0.2s ease;
}

.botao-salvar_ficha-tec:hover {
    background-color: #a51f22;
    color: #ffffff;
    transform: translateY(-2px);
}

.botao-salvar_ficha-tec:active {
    transform: scale(0.98);
}

.botao-salvar_ficha-tec i {
    font-size: 17px;
}


/* ==========================================================
   RESPONSIVIDADE
========================================================== */

@media (max-width: 600px) {

    body.pagina-ficha-tecnica {

        padding: 12px 10px 30px;

    }

    .pagina-ficha-tecnica .menu-selecao-tela {

        border-radius: 20px;

        flex-wrap: wrap;

    }

    .pagina-ficha-tecnica .menu-item {

        min-width: 100%;

        min-height: 45px;

    }

    .pagina-ficha-tecnica .container_ficha-tec {

        padding: 22px 15px;

        border-radius: 18px;

    }

    .pagina-ficha-tecnica .titulo_ficha-tec {

        font-size: 1.8rem;

    }

    .pagina-ficha-tecnica .card_ficha-tec {

        padding: 20px 15px;

        border-radius: 16px;

    }

    .pagina-ficha-tecnica .container_ficha-tec table {

        display: block;

        overflow-x: auto;

        white-space: nowrap;

    }

}



/* ==========================================
   MODAL - FICHA TÉCNICA
========================================== */

.modal-ficha {
    border: none;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 10px 35px rgba(70, 0, 0, 0.20);
}


/* CABEÇALHO */

.modal-ficha-header {
    background: linear-gradient(135deg, #8b0000, #a51f22);
    color: white;
    padding: 22px 26px;
    border-bottom: none;
}

.modal-ficha-header .modal-title {
    font-size: 22px;
    font-weight: 700;
}

.modal-subtitulo {
    margin: 5px 0 0;
    font-size: 14px;
    color: #f5dddd;
}

.modal-ficha-header .btn-close {
    filter: brightness(0) invert(1);
    opacity: 0.9;
}


/* CORPO DO MODAL */

.modal-ficha .modal-body {
    padding: 25px;
}


/* INFORMAÇÕES DO MODELO */

.modal-info-modelo {
    display: flex;
    justify-content: space-between;
    align-items: center;

    background: #f8eeee;

    border-radius: 10px;

    padding: 13px 16px;

    margin-bottom: 25px;
}

.modal-info-modelo span {
    color: #6b5555;
    font-size: 14px;
}

.modal-info-modelo strong {
    color: #8b0000;
    font-size: 16px;
}


/* TÍTULO DA TABELA */

.modal-tabela-titulo {
    color: #8b0000;
    font-weight: 700;
    margin-bottom: 15px;
}


/* TABELA */

.modal-tabela {
    margin-bottom: 0;
    vertical-align: middle;
}

.modal-tabela thead th {
    background: #8b0000;
    color: white;

    font-size: 13px;

    padding: 13px;

    white-space: nowrap;
}

.modal-tabela tbody td {
    padding: 13px;

    color: #443838;

    font-size: 14px;

    background-color: transparent !important;
}


/* LINHAS ALTERNADAS */

.modal-tabela tbody tr:nth-child(odd) {
    background-color: #fffaf9 !important;
}

.modal-tabela tbody tr:nth-child(even) {
    background-color: #ffffff !important;
}


/* RODAPÉ */

.modal-botao-fechar {
    background: #8b0000;

    color: white;

    border-radius: 9px;

    padding: 9px 24px;

    font-weight: 600;
}

.modal-botao-fechar:hover {
    background: #a51f22;
    color: white;
}


/* BOTÃO VER FICHA */

.consulta-ficha-botao_consulta_modelo {
    border: none;

    background: #8b0000;

    color: white;

    padding: 8px 16px;

    border-radius: 8px;

    font-size: 13px;

    font-weight: 600;

    cursor: pointer;

    transition: 0.2s;
}

.consulta-ficha-botao_consulta_modelo:hover {
    background: #a51f22;

    transform: translateY(-1px);
}

```