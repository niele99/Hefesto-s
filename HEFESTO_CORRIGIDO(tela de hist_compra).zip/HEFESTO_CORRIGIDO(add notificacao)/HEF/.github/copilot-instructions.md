# REGRAS OBRIGATÓRIAS DE DESENVOLVIMENTO — PROJETO HEF

Você está trabalhando no projeto HEF (Sistema de Gerenciamento de Estoque de uma Gráfica). Sua função é auxiliar no desenvolvimento de funcionalidades, interfaces, correções e melhorias, respeitando rigorosamente a estrutura original do projeto.

**ATENÇÃO: A prioridade é preservar o funcionamento do sistema. Nenhuma alteração deve comprometer funcionalidades já existentes.**

## 1. PROTEÇÃO DA LÓGICA DO SISTEMA

- NÃO altere funções Python, rotas Flask, consultas SQL, integrações com banco de dados ou regras de negócio quando a solicitação envolver exclusivamente alterações visuais.
- NÃO modifique nomes de variáveis, funções, classes utilizadas pela lógica, endpoints ou parâmetros existentes sem necessidade explícita.
- NÃO remova funcionalidades, validações, eventos JavaScript ou integrações já implementadas.
- NÃO substitua códigos funcionais por implementações simplificadas sem minha autorização.
- Preserve todos os formulários, métodos HTTP, identificadores, atributos e estruturas necessários ao funcionamento da aplicação.
- Caso uma alteração visual exija alguma modificação estrutural no HTML, preserve todos os elementos responsáveis pela funcionalidade.

## 2. PROTEÇÃO DOS ARQUIVOS CSS

- Antes de alterar qualquer CSS, identifique quais classes e identificadores pertencem exclusivamente à tela solicitada.
- NÃO altere estilos globais que possam afetar outras telas.
- NÃO modifique seletores como `body`, `*`, `:root`, `html`, `header`, `main` ou outros seletores compartilhados sem autorização explícita.
- NÃO altere estilos de outras telas dentro de arquivos CSS compartilhados.
- Utilize classes específicas para cada tela, preferencialmente com um prefixo identificador.
- Caso seja necessário alterar o `style.css`, modifique SOMENTE os blocos de CSS relacionados à tela solicitada.
- Não sobrescreva estilos existentes de outras páginas.
- Preserve as configurações responsivas e os componentes compartilhados.

## 3. PRESERVAÇÃO DO HTML E JAVASCRIPT

- Preserve a estrutura HTML original sempre que possível.
- Não remova IDs, nomes de campos, atributos `name`, `value`, `action`, `method` ou atributos `data-*` utilizados pelo sistema.
- Não altere funções JavaScript, listeners, eventos ou scripts responsáveis pelo funcionamento da tela sem necessidade.
- Não modifique caminhos de arquivos, imports, links ou referências de templates sem autorização.

## 4. PADRONIZAÇÃO VISUAL

Quando solicitado a reproduzir o design de outra tela:

- Utilize a tela de referência apenas como modelo visual.
- Reproduza cores, tipografia, tamanhos, espaçamentos, bordas, sombras, botões, tabelas, inputs e organização dos elementos.
- Não copie funcionalidades ou lógica da tela de referência.
- Não altere a tela de referência.
- Preserve a identidade visual original do projeto HEF.

## 5. PROCEDIMENTO OBRIGATÓRIO ANTES DE ALTERAR CÓDIGOS

Antes de realizar qualquer alteração:

1. Analise os arquivos envolvidos na tarefa.
2. Identifique as dependências e possíveis impactos em outras telas.
3. Determine exatamente quais arquivos e trechos precisam ser modificados.
4. Preserve todo código que não esteja diretamente relacionado à solicitação.
5. Se houver risco de afetar outras funcionalidades ou telas, informe antes de prosseguir.

## 6. PROCEDIMENTO OBRIGATÓRIO APÓS AS ALTERAÇÕES

Após concluir:

1. Informe quais arquivos foram modificados.
2. Descreva resumidamente o que foi alterado em cada arquivo.
3. Confirme que outras telas e estilos compartilhados não foram modificados.
4. Informe se alguma lógica ou funcionalidade precisou ser alterada e explique o motivo.
5. Não declare que algo foi testado se não realizou efetivamente o teste.

## 7. REGRA FINAL

**ALTERE SOMENTE O QUE FOI SOLICITADO.**

Não faça melhorias adicionais, refatorações, reorganizações, otimizações ou alterações estéticas em outras partes do projeto por iniciativa própria.

Se não tiver certeza de que uma alteração é segura, NÃO a execute. Explique o possível impacto e solicite minha autorização.

A integridade e a estabilidade do projeto HEF são mais importantes do que qualquer melhoria visual ou funcional.