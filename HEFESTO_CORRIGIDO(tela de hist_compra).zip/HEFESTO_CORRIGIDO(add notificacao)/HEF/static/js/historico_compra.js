document.addEventListener("DOMContentLoaded", () => {
    const modalElement = document.getElementById("modalEditarHistoricoCompra");
    const form = document.getElementById("formEditarHistoricoCompra");
    const idInput = document.getElementById("historicoCompraId");
    const entregaInput = document.getElementById("d_entrega_historico_compra");
    const realizacaoInput = document.getElementById("d_realizacao_historico_compra");
    const entregaFornecedorInput = document.getElementById("entrega_fornecedor_id");
    const erroElement = document.getElementById("erroEditarHistoricoCompra");
    const salvarButton = document.getElementById("btnSalvarHistoricoCompra");
    const erroExcluirElement = document.getElementById("erroExcluirHistoricoCompra");

    if (!modalElement || !form || !idInput || !entregaInput || !realizacaoInput || !entregaFornecedorInput || !salvarButton) {
        return;
    }

    const modal = window.bootstrap
        ? window.bootstrap.Modal.getOrCreateInstance(modalElement)
        : null;

    const ocultarErro = () => {
        if (erroElement) {
            erroElement.textContent = "";
            erroElement.classList.add("d-none");
        }
    };

    const mostrarErro = (mensagem) => {
        if (erroElement) {
            erroElement.textContent = mensagem;
            erroElement.classList.remove("d-none");
        }
    };

    const converterDataEntrega = (valor) => {
        if (!valor) return "";

        const texto = String(valor).trim();
        const pad = (numero) => String(numero).padStart(2, "0");

        if (/^\d{4}-\d{2}-\d{2}[ T]/.test(texto)) {
            return texto.replace(" ", "T").slice(0, 16);
        }

        const data = new Date(texto);
        if (Number.isNaN(data.getTime())) return "";

        return `${data.getFullYear()}-${pad(data.getMonth() + 1)}-${pad(data.getDate())}T${pad(data.getHours())}:${pad(data.getMinutes())}`;
    };

    const converterDataRealizacao = (valor) => {
        if (!valor) return "";

        const texto = String(valor).trim();
        if (/^\d{4}-\d{2}-\d{2}/.test(texto)) {
            return texto.slice(0, 10);
        }

        const data = new Date(texto);
        if (Number.isNaN(data.getTime())) return "";

        const pad = (numero) => String(numero).padStart(2, "0");
        return `${data.getFullYear()}-${pad(data.getMonth() + 1)}-${pad(data.getDate())}`;
    };

    document.querySelectorAll("[data-historico-compra-id]").forEach((botao) => {
        botao.addEventListener("click", async () => {
            const indice = botao.dataset.historicoCompraId;
            ocultarErro();

            botao.disabled = true;

            try {
                const resposta = await fetch(`/histcompra/${indice}`, {
                    headers: { "Accept": "application/json" }
                });
                const dados = await resposta.json().catch(() => ({}));

                if (!resposta.ok) {
                    throw new Error(dados.erro || "Não foi possível carregar os dados da compra.");
                }

                idInput.value = String(indice);
                entregaInput.value = converterDataEntrega(dados.d_entrega_historico_compra);
                realizacaoInput.value = converterDataRealizacao(dados.d_realizacao_historico_compra);
                entregaFornecedorInput.value = dados.entrega_fornecedor_id ?? "";

                if (modal) {
                    modal.show();
                } else {
                    modalElement.classList.add("show");
                    modalElement.style.display = "block";
                    modalElement.removeAttribute("aria-hidden");
                }
            } catch (erro) {
                mostrarErro(erro.message || "Não foi possível carregar os dados da compra.");
                if (modal) modal.show();
                else {
                    modalElement.classList.add("show");
                    modalElement.style.display = "block";
                    modalElement.removeAttribute("aria-hidden");
                }
            } finally {
                botao.disabled = false;
            }
        });
    });

    const ocultarErroExcluir = () => {
        if (erroExcluirElement) {
            erroExcluirElement.textContent = "";
            erroExcluirElement.classList.add("d-none");
        }
    };

    const mostrarErroExcluir = (mensagem) => {
        if (erroExcluirElement) {
            erroExcluirElement.textContent = mensagem;
            erroExcluirElement.classList.remove("d-none");
            erroExcluirElement.scrollIntoView({ behavior: "smooth", block: "nearest" });
        }
    };

    document.querySelectorAll("[data-historico-compra-excluir-id]").forEach((botao) => {
        botao.addEventListener("click", async () => {
            const indice = botao.dataset.historicoCompraExcluirId;

            const confirmado = window.confirm(
                "Esta exclusão é permanente. Deseja excluir este registro do histórico de compra?"
            );

            if (!confirmado) return;

            ocultarErroExcluir();

            const conteudoOriginal = botao.innerHTML;
            botao.disabled = true;
            botao.setAttribute("aria-busy", "true");
            botao.innerHTML = '<i class="bi bi-hourglass-split"></i><span>Excluindo...</span>';

            try {
                const resposta = await fetch(`/histcompra/${indice}`, {
                    method: "DELETE",
                    headers: { "Accept": "application/json" }
                });

                const resultado = await resposta.json().catch(() => ({}));

                if (!resposta.ok) {
                    if (resposta.status === 404) {
                        throw new Error(resultado.erro || "Este registro do histórico não foi encontrado.");
                    }

                    throw new Error(resultado.erro || "Não foi possível excluir o registro do histórico.");
                }

                window.location.reload();
            } catch (erro) {
                mostrarErroExcluir(erro.message || "Não foi possível excluir o registro do histórico.");
                botao.disabled = false;
                botao.removeAttribute("aria-busy");
                botao.innerHTML = conteudoOriginal;
            }
        });
    });

    form.addEventListener("submit", async (evento) => {
        evento.preventDefault();
        ocultarErro();

        const indice = idInput.value;
        if (!indice) {
            mostrarErro("Não foi possível identificar o registro da compra.");
            return;
        }

        if (!entregaInput.value || !realizacaoInput.value || !entregaFornecedorInput.value) {
            mostrarErro("Preencha a data de entrega, a data de realização e o identificador da entrega.");
            return;
        }

        const dados = {
            d_entrega_historico_compra: entregaInput.value,
            d_realizacao_historico_compra: realizacaoInput.value,
            entrega_fornecedor_id: Number(entregaFornecedorInput.value)
        };

        salvarButton.disabled = true;
        salvarButton.textContent = "Salvando...";

        try {
            const resposta = await fetch(`/histcompra/${indice}`, {
                method: "PUT",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(dados)
            });

            const resultado = await resposta.json().catch(() => ({}));

            if (!resposta.ok) {
                throw new Error(resultado.erro || "Não foi possível salvar as alterações.");
            }

            if (modal) modal.hide();
            window.location.reload();
        } catch (erro) {
            mostrarErro(erro.message || "Não foi possível salvar as alterações.");
        } finally {
            salvarButton.disabled = false;
            salvarButton.textContent = "Salvar alterações";
        }
    });
});
