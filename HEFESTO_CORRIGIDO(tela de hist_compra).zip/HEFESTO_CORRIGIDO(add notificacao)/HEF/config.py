import os
from dotenv import load_dotenv

# Carrega as variáveis do arquivo .env
load_dotenv()

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD"),
    "database": os.getenv("DB_NAME", "hefesto"),
    "port": int(os.getenv("DB_PORT", "3306")),
    "charset": "utf8mb4",
    "auth_plugin": "mysql_native_password"
}

SECRET_KEY = os.getenv("FLASK_SECRET_KEY")

if not SECRET_KEY:
    raise RuntimeError("FLASK_SECRET_KEY não foi configurada no arquivo .env")