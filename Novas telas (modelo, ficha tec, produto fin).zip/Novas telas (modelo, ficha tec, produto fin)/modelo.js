
/* =====================================================
   MODAL DE VISUALIZAÇÃO DA FICHA TÉCNICA
===================================================== */

// Elemento principal do modal
const modalFicha = document.getElementById("modalFichaTecnica");

// Elementos internos
const nomeModelo = document.getElementById("nomeModeloModal");
const codigoModelo = document.getElementById("codigoModeloModal");
const corpoTabela = document.getElementById("corpoTabelaFicha");


// =====================================================
// ABERTURA DO MODAL
// =====================================================

modalFicha.addEventListener("show.bs.modal", async function (event) {

    // Identifica o botão clicado
    const botao = event.relatedTarget;

    // Captura o ID do modelo
    const modeloId = botao.getAttribute("data-modelo-id");

    // Limpa informações anteriores
    nomeModelo.textContent = "Carregando modelo...";
    codigoModelo.textContent = modeloId || "-";

    exibirMensagem("Carregando ficha técnica...");


    try {

        /* =================================================
           INTEGRAÇÃO COM O BACK-END

           O responsável pelo Flask deverá:

           1. Criar uma rota para consultar a ficha técnica.
           2. Receber o ID do modelo.
           3. Consultar o MySQL.
           4. Retornar os dados em JSON.

           EXEMPLO DE ROTA ESPERADA:

           /api/modelos/ID/ficha-tecnica

           A LINHA FETCH ABAIXO DEVERÁ SER DESCOMENTADA
           E AJUSTADA CONFORME A ROTA DEFINITIVA.
        ================================================= */

        /*
        const resposta = await fetch(
            `/api/modelos/${encodeURIComponent(modeloId)}/ficha-tecnica`
        );

        if (!resposta.ok) {
            throw new Error("Erro ao consultar ficha técnica.");
        }

        const dados = await resposta.json();

        preencherFicha(dados);
        */

        // Enquanto a integração não estiver pronta:
        exibirMensagem("Aguardando integração com o banco de dados.");

    }

    catch (erro) {

        console.error("Erro ao carregar ficha técnica:", erro);

        nomeModelo.textContent = "Ficha Técnica";

        exibirMensagem("Não foi possível carregar a ficha técnica.");

    }

});


// =====================================================
// PREENCHIMENTO DA FICHA TÉCNICA
// =====================================================

function preencherFicha(dados) {

    /*
       FORMATO ESPERADO DO JSON:

       {
           modelo: {
               id: ...,
               nome: ...
           },

           materiais: [
               {
                   codigo: ...,
                   nome: ...,
                   quantidade: ...
               }
           ]
       }

       O responsável pelo back-end deverá retornar
       os dados seguindo essa estrutura ou adaptar
       os nomes dos campos abaixo.
    */


    // Preenche informações do modelo
    nomeModelo.textContent = dados.modelo.nome;

    codigoModelo.textContent = dados.modelo.id;


    // Limpa a tabela
    corpoTabela.innerHTML = "";


    // Verifica se existem matérias-primas
    if (!dados.materiais || dados.materiais.length === 0) {

        exibirMensagem("Nenhuma matéria-prima cadastrada.");

        return;

    }


    // Percorre os materiais recebidos do banco
    dados.materiais.forEach(function (material) {

        const linha = document.createElement("tr");


        // Código
        const colunaCodigo = document.createElement("td");

        colunaCodigo.textContent = material.codigo;


        // Nome
        const colunaNome = document.createElement("td");

        colunaNome.textContent = material.nome;


        // Quantidade
        const colunaQuantidade = document.createElement("td");

        colunaQuantidade.textContent = material.quantidade;


        // Adiciona as colunas à linha
        linha.appendChild(colunaCodigo);

        linha.appendChild(colunaNome);

        linha.appendChild(colunaQuantidade);


        // Adiciona a linha à tabela
        corpoTabela.appendChild(linha);

    });

}


// =====================================================
// EXIBIÇÃO DE MENSAGENS
// =====================================================

function exibirMensagem(mensagem) {

    corpoTabela.innerHTML = "";

    const linha = document.createElement("tr");

    const coluna = document.createElement("td");

    coluna.colSpan = 3;

    coluna.classList.add("text-center");

    coluna.textContent = mensagem;

    linha.appendChild(coluna);

    corpoTabela.appendChild(linha);

}


// =====================================================
// TRATAMENTO DE ERROS
// =====================================================

modalFicha.addEventListener("hidden.bs.modal", function () {

    // Limpa os dados ao fechar o modal
    nomeModelo.textContent = "Selecione um modelo";

    codigoModelo.textContent = "-";

    corpoTabela.innerHTML = `
        <tr>
            <td colspan="3" class="text-center">
                Selecione um modelo para visualizar
                sua ficha técnica.
            </td>
        </tr>
    `;

});
