from crud.crudBase import CrudBase
from core.database import Database

class Materia_prima(CrudBase):
    table = "materia_prima"
    fields = ["nome_materia_prima", "d_validade_materia_prima","estoque_materia_prima","min_estoque_materia_prima","d_ult_reposicao_materia_prima","descricao_materia_prima","barracao_rua_materia_prima","barracao_andar_materia_prima","barracao_num_materia_prima","ativado_materia_prima","pedido_fornecedor_id"]

    def __init__(self, nome=None, d_validade=None, estoque=None, min_estoque=None,d_ult_reposicao=None,descricao=None,barracao_rua=None,barracao_andar=None,barracao_num=None,ativado=None): #pedido_fornecedor_id=None ):
        self.nome = nome
        self.d_validade = d_validade
        self.estoque = estoque
        self.min_estoque = min_estoque
        self.d_ult_reposicao = d_ult_reposicao
        self.descricao = descricao
        self.barracao_rua = barracao_rua
        self.barracao_andar = barracao_andar
        self.barracao_num = barracao_num
        self.ativado = ativado_cliente
        # --------------------
        # self.pedido_fornecedor_id = pedido_fornecedor_id

    # -------------------------
    # INSERT
    # -------------------------
    @classmethod
    def inserir(self):
        conexao = Database.connect()
        cursor = conexao.cursor()

        try:
            sql = """
                INSERT INTO cliente (nome_materia_prima, d_validade_materia_prima,estoque_materia_prima,min_estoque_materia_prima,d_ult_reposicao_materia_prima,descricao_materia_prima,barracao_rua_materia_prima,barracao_andar_materia_prima,barracao_num_materia_prima,ativado_materia_prima,pedido_fornecedor_id)
                VALUES (%s, %s, %s, %s, %s,%s,%s, %s, %s, %s,%s)
            """

            cursor.execute(sql, (
                self.nome, 
                self.d_validade, 
                self.estoque, 
                self.min_estoque, 
                self.d_ult_reposicao, 
                self.descricao, 
                self.barracao_rua,
                self.barracao_andar,
                self.barracao_num, 
                self.ativado,
            ))

            conexao.commit()
            return cursor.lastrowid

        finally:
            cursor.close()
            conexao.close()

    # -------------------------
    # UPDATE
    # -------------------------
    @classmethod
    def update_cliente(cls, id, dados):
        conexao = Database.connect()
        cursor = conexao.cursor()

        try:
            sql = """
                UPDATE cliente
                SET nome_materia_prima = %s, d_validade_materia_prima = %s,estoque_materia_prima = %s,min_estoque_materia_prima = %s,d_ult_reposicao_materia_prima = %s,descricao_materia_prima = %s,barracao_rua_materia_prima = %s,barracao_andar_materia_prima = %s,barracao_num_materia_prima = %s,ativado_materia_prima = %s,pedido_fornecedor_id =%s
                WHERE id=%s
            """

            cursor.execute(sql, (
                dados.get("nome"),
                dados.get("d_validade"),
                dados.get("estoque"),
                dados.get("min_estoque"),
                dados.get("d_ult_reposicao"),
                dados.get("descricao"),
                dados.get("barracao_rua"),
                dados.get("barracao_andar"),
                dados.get("barracao_num"),
                dados.get("ativado"),
                dados.get("pedido_fornecedor"),
                id
            ))

            conexao.commit()
            return cursor.rowcount

        finally:
            cursor.close()
            conexao.close()

    # -------------------------
    # DELETE SEGURO
    # -------------------------
    @classmethod
    def related_cliente(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor()

        try:
            sql = "SELECT COUNT(*) FROM materia_prima WHERE cliente_id = %s"
            cursor.execute(sql, (id,))
            total = cursor.fetchone()[0]

            return total > 0

        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def safe_delete(cls, id):
        materia_prima = cls.find_by_id(id)

        if not materia_prima:
            raise ValueError("Matéria-prima não encontrada.")

        if cls.related_materia_prima(id):
            raise ValueError("Matéria-prima possui pedidos vinculados.")

        cls.delete(id)
        
    #Selecionar todos as matérias- primas

    @classmethod
    def find_all(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = """
            SELECT * IN materia_prima
            """
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

#Seleção por id
@classmethod
def find_all_by_id(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = """
            SELECT * IN materia_prima WHERE id= %s
            """
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()