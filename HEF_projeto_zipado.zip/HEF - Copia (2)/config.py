DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "123456", #senha obrigatoria
    "database": "hefesto",
    'auth_plugin': 'mysql_native_password'
}