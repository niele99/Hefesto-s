import React from 'react';

import { NavigationContainer } from '@react-navigation/native';

import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import { Ionicons } from '@expo/vector-icons';

import LoginScreen from './screens/LoginScreen';

import HomeScreen from './screens/HomeScreen';

import ProductsScreen from './screens/ProductsScreen';

import EntryScreen from './screens/EntryScreen';

import ExitScreen from './screens/ExitScreen';

import HistoryScreen from './screens/HistoryScreen';

import SettingsScreen from './screens/SettingsScreen';


const Stack = createNativeStackNavigator();

const Tab = createBottomTabNavigator();


function TabNavigator() {

  return (

    <Tab.Navigator

      screenOptions={({ route }) => ({

        headerShown: false,

        tabBarShowLabel: true,

        tabBarStyle: {
          backgroundColor: '#651818',
          borderTopWidth: 0,
          height: 78,
          paddingTop: 6,
          paddingBottom: 7,
          elevation: 10,
        },

        tabBarActiveTintColor: '#E8C9A0',

        tabBarInactiveTintColor: '#CDB9B2',

        tabBarLabelStyle: {
          fontSize: 9,
          fontWeight: '600',
          marginTop: 2,
        },

        tabBarIcon: ({ focused }) => {

          let iconName;

          if (route.name === 'Home') {

            iconName = focused
              ? 'home'
              : 'home-outline';

          }

          else if (route.name === 'Produtos') {

            iconName = focused
              ? 'cube'
              : 'cube-outline';

          }

          else if (route.name === 'Entrada') {

            iconName = focused
              ? 'arrow-down-circle'
              : 'arrow-down-circle-outline';

          }

          else if (route.name === 'Saída') {

            iconName = focused
              ? 'checkmark-circle'
              : 'checkmark-circle-outline';

          }

          else if (route.name === 'Histórico') {

            iconName = focused
              ? 'location'
              : 'location-outline';

          }

          else if (route.name === 'Ajustes') {

            iconName = focused
              ? 'settings'
              : 'settings-outline';

          }

          return (

            <Ionicons
              name={iconName}
              size={25}
              color={
                focused
                  ? '#E8C9A0'
                  : '#CDB9B2'
              }
            />

          );

        },

      })}

    >

      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          tabBarLabel: 'Início',
        }}
      />

      <Tab.Screen
        name="Produtos"
        component={ProductsScreen}
        options={{
          tabBarLabel: 'Envios do Dia',
        }}
      />

      <Tab.Screen
        name="Entrada"
        component={EntryScreen}
        options={{
          tabBarLabel: 'Entrada',
        }}
      />

      <Tab.Screen
        name="Saída"
        component={ExitScreen}
        options={{
          tabBarLabel: 'Verificação',
        }}
      />

      <Tab.Screen
        name="Histórico"
        component={HistoryScreen}
        options={{
          tabBarLabel: 'Rastreio',
        }}
      />

      <Tab.Screen
        name="Ajustes"
        component={SettingsScreen}
        options={{
          tabBarLabel: 'Configurações',
        }}
      />

    </Tab.Navigator>

  );

}


export default function App() {

  return (

    <NavigationContainer>

      <Stack.Navigator
        screenOptions={{
          headerShown: false,
        }}
      >

        <Stack.Screen
          name="Login"
          component={LoginScreen}
        />

        <Stack.Screen
          name="App"
          component={TabNavigator}
        />

      </Stack.Navigator>

    </NavigationContainer>

  );

}