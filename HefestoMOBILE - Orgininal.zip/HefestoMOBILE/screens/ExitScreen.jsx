import React, { useState } from 'react';

import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

export default function HistoryScreen({ navigation }) {

  const [items, setItems] = useState([
    {
      id: 1,
      name: 'Livros Didáticos',
      code: '00123',
      quantity: 10,
      sent: true,
    },
    {
      id: 2,
      name: 'Romances',
      code: '00456',
      quantity: 5,
      sent: true,
    },
    {
      id: 3,
      name: 'Técnicos',
      code: '00789',
      quantity: 8,
      sent: true,
    },
    {
      id: 4,
      name: 'Infantis',
      code: '01011',
      quantity: 12,
      sent: false,
    },
    {
      id: 5,
      name: 'Cadernos',
      code: '01234',
      quantity: 6,
      sent: false,
    },
  ]);

  const [observation, setObservation] = useState('');

  const toggleItem = (id) => {

    setItems((currentItems) =>
      currentItems.map((item) =>
        item.id === id
          ? {
              ...item,
              sent: !item.sent,
            }
          : item
      )
    );

  };

  const sentCount = items.filter(
    (item) => item.sent
  ).length;

  const pendingCount = items.length - sentCount;

  return (
    <ScrollView
      style={styles.container}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={styles.contentContainer}
    >

      {/* =========================
          CABEÇALHO
      ========================= */}

      <View style={styles.header}>

        <View style={styles.headerText}>

          <Text style={styles.title}>
            Verificação de Envios
          </Text>

          <Text style={styles.subtitle}>
            Confira os itens e confirme o envio
          </Text>

        </View>

        <View style={styles.headerTruck}>

          <Ionicons
            name="car-outline"
            size={38}
            color="#A52A2A"
          />

        </View>

      </View>


      {/* =========================
          PEDIDO
      ========================= */}

      <View style={styles.orderCard}>

        <View style={styles.orderMain}>

          <View style={styles.orderIcon}>

            <Ionicons
              name="clipboard-outline"
              size={30}
              color="#FFFFFF"
            />

          </View>

          <View>

            <Text style={styles.orderLabel}>
              Nº DO PEDIDO
            </Text>

            <Text style={styles.orderNumber}>
              0001
            </Text>

          </View>

        </View>


        <View style={styles.orderDetails}>

          <View style={styles.detailRow}>

            <Ionicons
              name="cube-outline"
              size={23}
              color="#842119"
            />

            <View>

              <Text style={styles.detailLabel}>
                CLIENTE
              </Text>

              <Text style={styles.detailValue}>
                Biblioteca Municipal
              </Text>

            </View>

          </View>


          <View style={styles.detailRow}>

            <Ionicons
              name="location-outline"
              size={23}
              color="#842119"
            />

            <View>

              <Text style={styles.detailLabel}>
                DESTINO
              </Text>

              <Text style={styles.detailValue}>
                Rua das Flores, 123 - Centro
              </Text>

            </View>

          </View>

        </View>

      </View>


      {/* =========================
          TÍTULO DOS ITENS
      ========================= */}

      <View style={styles.itemsTitleRow}>

        <Text style={styles.sectionTitle}>
          Itens do Pedido
        </Text>

        <View style={styles.progressBadge}>

          <Text style={styles.progressText}>
            {sentCount} de {items.length} enviados
          </Text>

        </View>

      </View>


      {/* =========================
          LISTA DE ITENS
      ========================= */}

      <View style={styles.itemsCard}>

        {/* CABEÇALHO */}

        <View style={styles.itemsHeader}>

          <Text style={styles.headerProduct}>
            PRODUTO
          </Text>

          <Text style={styles.headerQuantity}>
            QUANTIDADE
          </Text>

          <Text style={styles.headerStatus}>
            STATUS
          </Text>

        </View>


        {items.map((item) => (

          <TouchableOpacity
            key={item.id}
            style={[
              styles.itemRow,
              item.sent
                ? styles.itemRowSent
                : styles.itemRowPending,
            ]}
            onPress={() => toggleItem(item.id)}
            activeOpacity={0.85}
          >

            {/* CHECKBOX */}

            <View
              style={[
                styles.checkbox,
                item.sent &&
                  styles.checkboxChecked,
              ]}
            >

              {item.sent && (

                <Ionicons
                  name="checkmark"
                  size={18}
                  color="#FFFFFF"
                />

              )}

            </View>


            {/* ÍCONE LIVRO */}

            <View style={styles.bookIcon}>

              <Ionicons
                name="book-outline"
                size={24}
                color="#842119"
              />

            </View>


            {/* PRODUTO */}

            <View style={styles.productInfo}>

              <Text style={styles.productName}>
                {item.name}
              </Text>

              <Text style={styles.productCode}>
                Cód. {item.code}
              </Text>

            </View>


            {/* QUANTIDADE */}

            <Text style={styles.quantity}>
              {item.quantity}
            </Text>


            {/* STATUS */}

            <View
              style={[
                styles.statusBadge,
                item.sent
                  ? styles.statusSent
                  : styles.statusPending,
              ]}
            >

              <Ionicons
                name={
                  item.sent
                    ? 'checkmark-circle'
                    : 'time-outline'
                }
                size={17}
                color={
                  item.sent
                    ? '#356044'
                    : '#B9770E'
                }
              />

              <Text
                style={[
                  styles.statusText,
                  item.sent
                    ? styles.statusTextSent
                    : styles.statusTextPending,
                ]}
              >
                {item.sent
                  ? 'Enviado'
                  : 'Pendente'}
              </Text>

            </View>

          </TouchableOpacity>

        ))}

      </View>


      {/* =========================
          RESUMO
      ========================= */}

      <View style={styles.summaryCard}>

        {/* ENVIADOS */}

        <View style={styles.summaryItem}>

          <View style={styles.summaryIconGreen}>

            <Ionicons
              name="checkmark"
              size={25}
              color="#FFFFFF"
            />

          </View>

          <Text style={styles.summaryNumber}>
            {sentCount}
          </Text>

          <Text style={styles.summaryLabel}>
            Itens enviados
          </Text>

        </View>


        {/* PENDENTES */}

        <View style={styles.summaryDivider} />

        <View style={styles.summaryItem}>

          <View style={styles.summaryIconGold}>

            <Ionicons
              name="time-outline"
              size={25}
              color="#FFFFFF"
            />

          </View>

          <Text style={styles.summaryNumber}>
            {pendingCount}
          </Text>

          <Text style={styles.summaryLabel}>
            Itens pendentes
          </Text>

        </View>


        {/* TOTAL */}

        <View style={styles.summaryDivider} />

        <View style={styles.summaryItem}>

          <View style={styles.summaryIconRed}>

            <Ionicons
              name="cube-outline"
              size={25}
              color="#FFFFFF"
            />

          </View>

          <Text style={styles.summaryNumber}>
            {items.length}
          </Text>

          <Text style={styles.summaryLabel}>
            Total de itens
          </Text>

        </View>

      </View>


      {/* =========================
          OBSERVAÇÕES
      ========================= */}

      <View style={styles.observationCard}>

        <View style={styles.observationHeader}>

          <Ionicons
            name="chatbubble-outline"
            size={24}
            color="#FFFFFF"
          />

          <Text style={styles.observationTitle}>
            Observações
          </Text>

        </View>

        <TextInput
          style={styles.observationInput}
          placeholder="Adicione alguma observação (opcional)..."
          placeholderTextColor="#DCCBC5"
          value={observation}
          onChangeText={setObservation}
          multiline
        />

      </View>


      {/* =========================
          CONFIRMAR
      ========================= */}

      <TouchableOpacity
        style={styles.confirmButton}
        onPress={() => navigation.navigate('Home')}
        activeOpacity={0.85}
      >

        <Ionicons
          name="checkmark-circle"
          size={25}
          color="#FFFFFF"
        />

        <Text style={styles.confirmText}>
          Confirmar Envio
        </Text>

      </TouchableOpacity>


      <View style={{ height: 30 }} />

    </ScrollView>
  );
}


const styles = StyleSheet.create({

  /* =========================
      TELA
  ========================= */

  container: {
    flex: 1,
    backgroundColor: '#4A1313',
  },

  contentContainer: {
    paddingHorizontal: 20,
    paddingTop: 45,
  },


  /* =========================
      CABEÇALHO
  ========================= */

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 25,
  },

  headerText: {
    flex: 1,
  },

  title: {
    color: '#FFFFFF',
    fontSize: 29,
    fontWeight: 'bold',
  },

  subtitle: {
    color: '#E8D9D2',
    fontSize: 14,
    marginTop: 6,
  },

  headerTruck: {
    width: 58,
    height: 58,
    justifyContent: 'center',
    alignItems: 'center',
  },


  /* =========================
      PEDIDO
  ========================= */

  orderCard: {
    backgroundColor: '#F8F1ED',
    borderRadius: 23,
    padding: 20,
    borderWidth: 1,
    borderColor: '#E8D8D1',
    marginBottom: 28,
  },

  orderMain: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },

  orderIcon: {
    width: 58,
    height: 58,
    backgroundColor: '#A52A2A',
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },

  orderLabel: {
    color: '#806F68',
    fontSize: 12,
    fontWeight: 'bold',
  },

  orderNumber: {
    color: '#842119',
    fontSize: 36,
    fontWeight: 'bold',
    marginTop: 2,
  },

  orderDetails: {
    gap: 16,
  },

  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },

  detailLabel: {
    color: '#806F68',
    fontSize: 10,
    fontWeight: 'bold',
  },

  detailValue: {
    color: '#4A201A',
    fontSize: 14,
    marginTop: 2,
  },


  /* =========================
      ITENS
  ========================= */

  itemsTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 15,
  },

  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 22,
    fontWeight: 'bold',
  },

  progressBadge: {
    backgroundColor: '#C88A18',
    paddingVertical: 9,
    paddingHorizontal: 13,
    borderRadius: 18,
  },

  progressText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: 'bold',
  },

  itemsCard: {
    backgroundColor: '#F8F1ED',
    borderRadius: 23,
    padding: 12,
    borderWidth: 1,
    borderColor: '#E8D8D1',
  },

  itemsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 8,
    marginBottom: 4,
  },

  headerProduct: {
    flex: 1,
    color: '#806F68',
    fontSize: 10,
    fontWeight: 'bold',
  },

  headerQuantity: {
    width: 55,
    textAlign: 'center',
    color: '#806F68',
    fontSize: 10,
    fontWeight: 'bold',
  },

  headerStatus: {
    width: 85,
    textAlign: 'center',
    color: '#806F68',
    fontSize: 10,
    fontWeight: 'bold',
  },


  /* =========================
      ITEM
  ========================= */

  itemRow: {
    minHeight: 76,
    borderRadius: 16,
    paddingHorizontal: 8,
    marginBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
  },

  itemRowSent: {
    backgroundColor: '#EDF1E9',
  },

  itemRowPending: {
    backgroundColor: '#F5E8E2',
  },

  checkbox: {
    width: 28,
    height: 28,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: '#806F68',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },

  checkboxChecked: {
    backgroundColor: '#356044',
    borderColor: '#356044',
  },

  bookIcon: {
    width: 42,
    height: 42,
    backgroundColor: '#F1DAD4',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },

  productInfo: {
    flex: 1,
  },

  productName: {
    color: '#4A201A',
    fontSize: 13,
    fontWeight: 'bold',
  },

  productCode: {
    color: '#806F68',
    fontSize: 11,
    marginTop: 3,
  },

  quantity: {
    width: 55,
    textAlign: 'center',
    color: '#4A201A',
    fontSize: 15,
    fontWeight: 'bold',
  },

  statusBadge: {
    width: 85,
    minHeight: 34,
    borderRadius: 17,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    gap: 5,
  },

  statusSent: {
    backgroundColor: '#DCE9D6',
  },

  statusPending: {
    backgroundColor: '#F6DDA8',
  },

  statusText: {
    fontSize: 11,
    fontWeight: 'bold',
  },

  statusTextSent: {
    color: '#356044',
  },

  statusTextPending: {
    color: '#A86E11',
  },


  /* =========================
      RESUMO
  ========================= */

  summaryCard: {
    backgroundColor: '#F8F1ED',
    borderRadius: 23,
    padding: 18,
    marginTop: 22,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    borderWidth: 1,
    borderColor: '#E8D8D1',
  },

  summaryItem: {
    flex: 1,
    alignItems: 'center',
  },

  summaryDivider: {
    width: 1,
    height: 72,
    backgroundColor: '#DDC9C0',
  },

  summaryIconGreen: {
    width: 42,
    height: 42,
    backgroundColor: '#356044',
    borderRadius: 21,
    justifyContent: 'center',
    alignItems: 'center',
  },

  summaryIconGold: {
    width: 42,
    height: 42,
    backgroundColor: '#C88A18',
    borderRadius: 21,
    justifyContent: 'center',
    alignItems: 'center',
  },

  summaryIconRed: {
    width: 42,
    height: 42,
    backgroundColor: '#A52A2A',
    borderRadius: 21,
    justifyContent: 'center',
    alignItems: 'center',
  },

  summaryNumber: {
    color: '#4A201A',
    fontSize: 25,
    fontWeight: 'bold',
    marginTop: 6,
  },

  summaryLabel: {
    color: '#806F68',
    fontSize: 10,
    marginTop: 2,
    textAlign: 'center',
  },


  /* =========================
      OBSERVAÇÕES
  ========================= */

  observationCard: {
    backgroundColor: '#651818',
    borderRadius: 20,
    padding: 16,
    marginTop: 20,
    borderWidth: 1,
    borderColor: '#7B2424',
  },

  observationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 10,
  },

  observationTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },

  observationInput: {
    height: 55,
    backgroundColor: '#7A4141',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    color: '#FFFFFF',
    fontSize: 13,
    textAlignVertical: 'top',
  },


  /* =========================
      CONFIRMAR
  ========================= */

  confirmButton: {
    height: 64,
    backgroundColor: '#356044',
    borderRadius: 20,
    marginTop: 20,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },

  confirmText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },

});