import React, { useEffect, useState } from 'react';

import {
  Modal,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';

import {
  CameraView,
  Camera,
} from 'expo-camera';

export default function QRcodeScaner({
  visible,
  onClose,
  onReadCode,
}) {

  const [hasPermission, setHasPermission] = useState(null);
  const [scanned, setScanned] = useState(false);
  const [permissionError, setPermissionError] = useState(false);


  useEffect(() => {

    if (!visible) {
      return;
    }

    setScanned(false);
    setPermissionError(false);

    const requestPermission = async () => {

      try {

        const result =
          await Camera.requestCameraPermissionsAsync();

        console.log(
          'Permissão da câmera:',
          result.status
        );

        setHasPermission(
          result.status === 'granted'
        );

      } catch (error) {

        console.log(
          'Erro ao pedir permissão da câmera:',
          error
        );

        setPermissionError(true);
        setHasPermission(false);

      }

    };

    requestPermission();

  }, [visible]);


  const handleBarcodeScanned = ({ data }) => {

    if (scanned) {
      return;
    }

    setScanned(true);

    console.log('QR Code lido:', data);

    onReadCode(data);

  };


  if (!visible) {
    return null;
  }


  return (

    <Modal
      visible={visible}
      animationType="slide"
      transparent={false}
    >

      <View style={styles.container}>

        {permissionError ? (

          <View style={styles.permissionContainer}>

            <Text style={styles.title}>
              Erro ao acessar a câmera
            </Text>

            <Text style={styles.permissionText}>
              Não foi possível solicitar a permissão da câmera.
            </Text>

            <TouchableOpacity
              style={styles.closeButton}
              onPress={onClose}
            >

              <Text style={styles.closeText}>
                Fechar
              </Text>

            </TouchableOpacity>

          </View>

        ) : hasPermission === false ? (

          <View style={styles.permissionContainer}>

            <Text style={styles.title}>
              Acesso à câmera
            </Text>

            <Text style={styles.permissionText}>
              O aplicativo precisa de acesso à câmera para ler o QR Code.
            </Text>

            <TouchableOpacity
              style={styles.closeButton}
              onPress={onClose}
            >

              <Text style={styles.closeText}>
                Fechar
              </Text>

            </TouchableOpacity>

          </View>

        ) : hasPermission === null ? (

          <View style={styles.permissionContainer}>

            <Text style={styles.permissionText}>
              Solicitando acesso à câmera...
            </Text>

          </View>

        ) : (

          <>

            <CameraView
              style={StyleSheet.absoluteFillObject}
              facing="back"
              onBarcodeScanned={
                scanned
                  ? undefined
                  : handleBarcodeScanned
              }
              barcodeScannerSettings={{
                barcodeTypes: ['qr'],
              }}
            />


            <View style={styles.overlay}>

              <View style={styles.qrFrame} />

              <Text style={styles.scannerText}>
                Aponte a câmera para o QR Code
              </Text>

            </View>


            <TouchableOpacity
              style={styles.closeButton}
              onPress={onClose}
            >

              <Text style={styles.closeText}>
                Fechar Câmera
              </Text>

            </TouchableOpacity>

          </>

        )}

      </View>

    </Modal>

  );
}


const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: '#000000',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },

  permissionContainer: {
    flex: 1,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 30,
  },

  title: {
    color: '#FFFFFF',
    fontSize: 21,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 15,
  },

  permissionText: {
    color: '#FFFFFF',
    fontSize: 17,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 25,
  },

  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 120,
    justifyContent: 'center',
    alignItems: 'center',
  },

  qrFrame: {
    width: 250,
    height: 250,
    borderWidth: 3,
    borderColor: '#F3E5DF',
    borderRadius: 20,
  },

  scannerText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 25,
    textAlign: 'center',
  },

  closeButton: {
    backgroundColor: '#842119',
    paddingVertical: 16,
    paddingHorizontal: 30,
    borderRadius: 16,
    marginBottom: 35,
  },

  closeText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },

});