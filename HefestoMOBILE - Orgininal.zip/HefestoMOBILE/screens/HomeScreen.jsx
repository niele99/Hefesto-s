import React, { useState, useCallback } from 'react';

import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';

import api from '../src/services/api';

export default function HomeScreen({ navigation }) {

  const [dashboardData, setDashboardData] = useState({
    totalProducts: 0,
    lowStockCount: 0,
    recentActivities: [],
  });

  const loadDashboard = async () => {
    try {

      const response = await api.get('/dashboard');

      setDashboardData({
        totalProducts: response.data.totalProducts ?? 0,
        lowStockCount: response.data.lowStockCount ?? 0,
        recentActivities: response.data.recentActivities || [],
      });

    } catch (error) {

      console.log('Erro ao carregar Dashboard:', error);

    }
  };

  useFocusEffect(
    useCallback(() => {
      loadDashboard();
    }, [])
  );

  return (

    <ScrollView
      style={styles.container}
      showsVerticalScrollIndicator={false}
    >

      {/* =========================
          CABEÇALHO
      ========================= */}

      <View style={styles.header}>

        <View>

          <Text style={styles.welcome}>
            Bem-vindo!
          </Text>

          <Text style={styles.userName}>
            Hefesto's Stock
          </Text>

          <Text style={styles.headerSubtitle}>
            Gestão inteligente de estoque de livros
          </Text>

        </View>

        {/* SINO */}

        <TouchableOpacity style={styles.notification}>

          <Ionicons
            name="notifications-outline"
            size={25}
            color="#FFFFFF"
          />

        </TouchableOpacity>

      </View>


      {/* =========================
          1º CARD — LIVROS EM ESTOQUE
      ========================= */}

      <View style={styles.mainCard}>

        <View style={styles.mainCardContent}>

          {/* IMAGEM DOS LIVROS */}

          <Image
            source={require('../assets/Livros2.png')}
            style={styles.mainBookImage}
            resizeMode="contain"
          />

          {/* INFORMAÇÕES */}

          <View style={styles.mainCardInfo}>

            <Text style={styles.mainCardTitle}>
              Livros em Estoque
            </Text>

            <Text style={styles.mainNumber}>
              {dashboardData.totalProducts}
            </Text>

            <View style={styles.updateContainer}>

              <Ionicons
                name="time-outline"
                size={17}
                color="#A52A2A"
              />

              <Text style={styles.updateText}>
                Atualizado com o banco de dados
              </Text>

            </View>

          </View>

        </View>

      </View>


      {/* =========================
          2º E 3º CARDS
      ========================= */}

      <View style={styles.cardsContainer}>

        {/* =========================
            2º CARD — UNIDADES TOTAIS
        ========================= */}

        <View style={[styles.smallCard, styles.smallCardYellow]}>

          <View style={styles.smallCardInfo}>

            {/* ÍCONE */}

            <View style={styles.smallIconGold}>

              <Ionicons
                name="library-outline"
                size={25}
                color="#FFFFFF"
              />

            </View>

            <Text style={styles.cardNumber}>
              {dashboardData.totalProducts}
            </Text>

            <Text style={styles.cardLabel}>
              Lotes Totais
            </Text>

            <Text style={styles.cardDescription}>
              Quantidade registrada
            </Text>

          </View>


          {/* IMAGEM AMARELO */}

          <Image
            source={require('../assets/amarelo.png')}
            style={styles.smallCardImage}
            resizeMode="contain"
          />

        </View>


        {/* =========================
            3º CARD — ESTOQUE BAIXO
        ========================= */}

        <View style={[styles.smallCard, styles.smallCardRed]}>

          <View style={styles.smallCardInfo}>

            {/* ÍCONE */}

            <View style={styles.smallIconRed}>

              <Ionicons
                name="warning-outline"
                size={25}
                color="#FFFFFF"
              />

            </View>

            <Text style={styles.cardNumber}>
              {dashboardData.lowStockCount}
            </Text>

            <Text style={styles.cardLabel}>
              Estoque Baixo
            </Text>

            <Text style={styles.cardDescription}>
              Itens abaixo do mínimo
            </Text>

          </View>


          {/* IMAGEM ESTANTE */}

          <Image
            source={require('../assets/estante.png')}
            style={styles.smallCardImage}
            resizeMode="contain"
          />

        </View>

      </View>


      {/* =========================
          OPERAÇÕES
      ========================= */}

      <Text style={styles.sectionTitle}>
        Operações
      </Text>


      {/* =========================
          CATÁLOGO
      ========================= */}

      <TouchableOpacity
        style={styles.actionButtonRed}
        onPress={() => navigation.navigate('Produtos')}
        activeOpacity={0.8}
      >

        <View style={styles.buttonContent}>

          <View style={styles.actionIcon}>

            <Ionicons
              name="book-outline"
              size={27}
              color="#FFFFFF"
            />

          </View>

          <View>

            <Text style={styles.buttonTitle}>
              Envios do dia 
            </Text>

            <Text style={styles.buttonSubtitle}>
              Confira os items enviados hoje
            </Text>

          </View>

        </View>

        <Ionicons
          name="chevron-forward"
          size={25}
          color="#FFFFFF"
        />

      </TouchableOpacity>


      {/* =========================
          ENTRADA
      ========================= */}

      <TouchableOpacity
        style={styles.actionButtonGold}
        onPress={() => navigation.navigate('Entrada')}
        activeOpacity={0.8}
      >

        <View style={styles.buttonContent}>

          <View style={styles.actionIcon}>

            <Ionicons
              name="arrow-down-circle-outline"
              size={27}
              color="#FFFFFF"
            />

          </View>

          <View>

            <Text style={styles.buttonTitle}>
              Verificação de Entrada
            </Text>

            <Text style={styles.buttonSubtitle}>
              Veja as Matérias-primas Recebidas  
            </Text>

          </View>

        </View>

        <Ionicons
          name="chevron-forward"
          size={25}
          color="#FFFFFF"
        />

      </TouchableOpacity>


      {/* =========================
          SAÍDA
      ========================= */}

      <TouchableOpacity
        style={styles.actionButtonGreen}
        onPress={() => navigation.navigate('Saída')}
        activeOpacity={0.8}
      >

        <View style={styles.buttonContent}>

          <View style={styles.actionIcon}>

            <Ionicons
              name="arrow-up-circle-outline"
              size={27}
              color="#FFFFFF"
            />

          </View>

          <View>

            <Text style={styles.buttonTitle}>
              Verificação de Envios
            </Text>

            <Text style={styles.buttonSubtitle}>
              Verifique os Livros no Estoque
            </Text>

          </View>

        </View>

        <Ionicons
          name="chevron-forward"
          size={25}
          color="#FFFFFF"
        />

      </TouchableOpacity>


      {/* =========================
          ATIVIDADES RECENTES
      ========================= */}

      <View style={styles.activityHeader}>

        <Text style={styles.sectionTitle}>
          Atividades Recentes
        </Text>

        <TouchableOpacity>

          <Text style={styles.seeAll}>
            Ver todas
          </Text>

        </TouchableOpacity>

      </View>


      {/* =========================
          SEM ATIVIDADES
      ========================= */}

      {dashboardData.recentActivities.length === 0 ? (

        <View style={styles.emptyCard}>

          <View style={styles.emptyIcon}>

            <Ionicons
              name="book-outline"
              size={25}
              color="#A52A2A"
            />

          </View>

          <View>

            <Text style={styles.emptyTitle}>
              Nenhuma atividade recente
            </Text>

            <Text style={styles.emptyText}>
              As movimentações do estoque aparecerão aqui.
            </Text>

          </View>

        </View>

      ) : (

        dashboardData.recentActivities.map((item) => (

          <View
            key={item.id}
            style={styles.activityCard}
          >

            <View
              style={[
                styles.activityIcon,
                item.type === 'Entrada'
                  ? styles.activityEntry
                  : styles.activityExit
              ]}
            >

              <Ionicons
                name={
                  item.type === 'Entrada'
                    ? 'arrow-down-outline'
                    : 'arrow-up-outline'
                }
                size={22}
                color="#FFFFFF"
              />

            </View>

            <View style={styles.activityInfo}>

              <Text style={styles.activityTitle}>

                {item.type === 'Entrada'
                  ? 'Entrada de Livro'
                  : 'Saída de Livro'}

              </Text>

              <Text style={styles.activityText}>
                {item.quantity} unidades • {item.product}
              </Text>

            </View>

          </View>

        ))

      )}

      <View style={{ height: 40 }} />

    </ScrollView>

  );

}


const styles = StyleSheet.create({

  /* =========================
     TELA
  ========================= */

  container: {
    flex: 1,
    backgroundColor: '#4a1313',
    paddingHorizontal: 20,
  },


  /* =========================
     CABEÇALHO
  ========================= */

  header: {
    marginTop: 55,
    marginBottom: 25,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  welcome: {
    color: '#E8C9A0',
    fontSize: 14,
    marginBottom: 4,
  },

  userName: {
    color: '#FFFFFF',
    fontSize: 28,
    fontWeight: 'bold',
  },

  headerSubtitle: {
    color: '#E8D9D2',
    fontSize: 12,
    marginTop: 5,
  },


  /* =========================
     SINO
  ========================= */

  notification: {
    width: 50,
    height: 50,
    backgroundColor: '#A52A2A',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#C94A4A',
  },


  /* =========================
     1º CARD
  ========================= */

  mainCard: {
    backgroundColor: '#FEFDFC',
    borderRadius: 25,
    padding: 20,
    marginBottom: 18,
    borderWidth: 1,
    borderColor: '#E8D8D1',
    elevation: 5,
  },

  mainCardContent: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  mainBookImage: {
    width: 190,
    height: 190,
    marginRight: 12,
    marginLeft: 0,
  },

  mainCardInfo: {
    flex: 1,
  },

  mainCardTitle: {
    color: '#3D3533',
    fontSize: 17,
    fontWeight: 'bold',
  },

  mainNumber: {
    color: '#A52A2A',
    fontSize: 42,
    fontWeight: 'bold',
    marginTop: 8,
  },

  updateContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },

  updateText: {
    color: '#756865',
    fontSize: 12,
    marginLeft: 6,
  },


  /* =========================
     CARDS PEQUENOS
  ========================= */

  cardsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },

  smallCard: {
    width: '48%',
    minHeight: 190,
    borderRadius: 21,
    padding: 15,
    borderWidth: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    overflow: 'hidden',
  },

  smallCardYellow: {
    backgroundColor: '#FFF5D6',
    borderColor: '#E8D79F',
  },

  smallCardRed: {
    backgroundColor: '#F9DCDC',
    borderColor: '#E5B5B5',
  },

  smallCardInfo: {
    flex: 1,
    zIndex: 2,
  },

  smallIconGold: {
    width: 45,
    height: 45,
    backgroundColor: '#C88A18',
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 5,
  },

  smallIconRed: {
    width: 45,
    height: 45,
    backgroundColor: '#A52A2A',
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 5,
  },

  smallCardImage: {
    width: 90,
    height: 90,
    position: 'absolute',
    right: 30,
    top: 18,
    opacity: 0.95,
  },

  cardNumber: {
    color: '#3D2521',
    fontSize: 29,
    fontWeight: 'bold',
    marginTop: 13,
  },

  cardLabel: {
    color: '#4B403D',
    fontSize: 14,
    fontWeight: '600',
    marginTop: 3,
  },

  cardDescription: {
    color: '#8A7B76',
    fontSize: 11,
    marginTop: 5,
    lineHeight: 15,
  },


  /* =========================
     TÍTULOS
  ========================= */

  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 21,
    fontWeight: 'bold',
    marginTop: 25,
    marginBottom: 15,
  },

  activityHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  seeAll: {
    color: '#E8C9A0',
    fontSize: 13,
    fontWeight: '600',
  },


  /* =========================
     BOTÕES DE OPERAÇÃO
  ========================= */

  actionButtonRed: {
    backgroundColor: '#A52A2A',
    borderRadius: 18,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  actionButtonGold: {
    backgroundColor: '#C88A18',
    borderRadius: 18,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  actionButtonGreen: {
    backgroundColor: '#356044',
    borderRadius: 18,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },

  actionIcon: {
    width: 48,
    height: 48,
    borderRadius: 15,
    backgroundColor: 'rgba(255,255,255,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 13,
  },

  buttonTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },

  buttonSubtitle: {
    color: '#F5E9E3',
    marginTop: 4,
    fontSize: 12,
  },


  /* =========================
     ATIVIDADES
  ========================= */

  activityCard: {
    backgroundColor: '#FEFEFE',
    borderRadius: 17,
    padding: 15,
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E8D8D1',
  },

  activityIcon: {
    width: 45,
    height: 45,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },

  activityEntry: {
    backgroundColor: '#3B7048',
  },

  activityExit: {
    backgroundColor: '#A52A2A',
  },

  activityInfo: {
    flex: 1,
  },

  activityTitle: {
    color: '#3D3533',
    fontSize: 14,
    fontWeight: 'bold',
  },

  activityText: {
    color: '#81736E',
    fontSize: 12,
    marginTop: 4,
  },


  /* =========================
     SEM ATIVIDADES
  ========================= */

  emptyCard: {
    backgroundColor: '#FEFEFE',
    borderRadius: 17,
    padding: 17,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E8D8D1',
  },

  emptyIcon: {
    width: 46,
    height: 46,
    borderRadius: 14,
    backgroundColor: '#F4E5DF',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },

  emptyTitle: {
    color: '#3D3533',
    fontSize: 14,
    fontWeight: 'bold',
  },

  emptyText: {
    color: '#8A7B76',
    fontSize: 11,
    marginTop: 3,
    maxWidth: 250,
  },

});