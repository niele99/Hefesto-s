import React, { useState, useEffect } from 'react';

import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Image,
  Alert,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import api from '../src/services/api';

export default function SettingsScreen({ navigation }) {

  const [darkMode, setDarkMode] = useState(true);

  const [notifications, setNotifications] = useState(true);

  const [userData, setUserData] = useState({
    name: 'Carregando...',
    role: 'Operador de Estoque',
    email: 'carregando...',
  });


  // =========================
  // BUSCAR DADOS DO USUÁRIO
  // =========================

  useEffect(() => {

    loadUserProfile();

  }, []);


  const loadUserProfile = async () => {

    try {

      const response = await api.post('/login', {
        email: 'lucas@empresa.com',
        password: '123456',
      });

      if (response.data.success) {

        setUserData(response.data.user);

      }

    } catch (error) {

      console.log(
        'Erro ao carregar dados do usuário:',
        error
      );

    }

  };


  // =========================
  // SAIR DA CONTA
  // =========================

  const handleLogout = () => {

    Alert.alert(
      'Sair da Conta',
      'Deseja realmente sair da aplicação?',
      [

        {
          text: 'Cancelar',
          style: 'cancel',
        },

        {
          text: 'Sair',
          style: 'destructive',

          onPress: () => {

            navigation.reset({
              index: 0,
              routes: [{ name: 'Login' }],
            });

          },

        },

      ]
    );

  };


  return (

    <ScrollView
      style={styles.container}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={styles.contentContainer}
    >

      {/* =========================
          CABEÇALHO
      ========================= */}

      <View style={styles.header}>

        <Text style={styles.title}>
          Configurações
        </Text>

        <Text style={styles.subtitle}>
          Gerencie preferências do sistema
        </Text>

      </View>


      {/* =========================
          PERFIL
      ========================= */}

      <View style={styles.profileCard}>

        <Image
          source={{
            uri: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=1200&auto=format&fit=crop',
          }}
          style={styles.avatar}
        />

        <View style={styles.profileInfo}>

          <Text style={styles.userName}>
            {userData.name}
          </Text>

          <Text style={styles.userRole}>
            {userData.role}
          </Text>

          <Text style={styles.userEmail}>
            {userData.email}
          </Text>

        </View>

        <TouchableOpacity style={styles.editButton}>

          <Ionicons
            name="create-outline"
            size={22}
            color="#F3E8DF"
          />

        </TouchableOpacity>

      </View>


      {/* =========================
          PREFERÊNCIAS
      ========================= */}

      <View style={styles.sectionHeader}>

        <View style={styles.sectionHeaderIcon}>

          <Ionicons
            name="options-outline"
            size={21}
            color="#F3E8DF"
          />

        </View>

        <Text style={styles.sectionTitle}>
          Preferências
        </Text>

      </View>


      {/* MODO ESCURO */}

      <View style={styles.optionCard}>

        <View style={styles.optionLeft}>

          <View style={styles.iconGreen}>

            <Ionicons
              name="moon-outline"
              size={23}
              color="#F3E8DF"
            />

          </View>

          <View style={styles.optionText}>

            <Text style={styles.optionTitle}>
              Modo Escuro
            </Text>

            <Text style={styles.optionSubtitle}>
              Tema visual do aplicativo
            </Text>

          </View>

        </View>

        <Switch
          value={darkMode}
          onValueChange={setDarkMode}
          trackColor={{
            false: '#7A5252',
            true: '#356044',
          }}
          thumbColor="#F3E8DF"
        />

      </View>


      {/* NOTIFICAÇÕES */}

      <View style={styles.optionCard}>

        <View style={styles.optionLeft}>

          <View style={styles.iconGold}>

            <Ionicons
              name="notifications-outline"
              size={23}
              color="#F3E8DF"
            />

          </View>

          <View style={styles.optionText}>

            <Text style={styles.optionTitle}>
              Notificações
            </Text>

            <Text style={styles.optionSubtitle}>
              Alertas do sistema
            </Text>

          </View>

        </View>

        <Switch
          value={notifications}
          onValueChange={setNotifications}
          trackColor={{
            false: '#7A5252',
            true: '#C88A18',
          }}
          thumbColor="#F3E8DF"
        />

      </View>


      {/* =========================
          CONTA E SEGURANÇA
      ========================= */}

      <View style={styles.sectionHeader}>

        <View style={styles.sectionHeaderIcon}>

          <Ionicons
            name="shield-checkmark-outline"
            size={21}
            color="#F3E8DF"
          />

        </View>

        <Text style={styles.sectionTitle}>
          Conta e Segurança
        </Text>

      </View>


      {/* ALTERAR SENHA */}

      <TouchableOpacity style={styles.menuCard}>

        <View style={styles.menuLeft}>

          <View style={styles.iconRed}>

            <Ionicons
              name="lock-closed-outline"
              size={23}
              color="#F3E8DF"
            />

          </View>

          <View style={styles.optionText}>

            <Text style={styles.menuTitle}>
              Alterar Senha
            </Text>

            <Text style={styles.menuSubtitle}>
              Atualizar credenciais
            </Text>

          </View>

        </View>

        <Ionicons
          name="chevron-forward"
          size={22}
          color="#E5CEC6"
        />

      </TouchableOpacity>


      {/* PRIVACIDADE */}

      <TouchableOpacity style={styles.menuCard}>

        <View style={styles.menuLeft}>

          <View style={styles.iconGreenDark}>

            <Ionicons
              name="shield-checkmark-outline"
              size={23}
              color="#F3E8DF"
            />

          </View>

          <View style={styles.optionText}>

            <Text style={styles.menuTitle}>
              Privacidade
            </Text>

            <Text style={styles.menuSubtitle}>
              Configurações de acesso
            </Text>

          </View>

        </View>

        <Ionicons
          name="chevron-forward"
          size={22}
          color="#E5CEC6"
        />

      </TouchableOpacity>


      {/* =========================
          SAIR DA CONTA
      ========================= */}

      <TouchableOpacity
        style={styles.logoutButton}
        onPress={handleLogout}
        activeOpacity={0.85}
      >

        <Ionicons
          name="log-out-outline"
          size={24}
          color="#F3E8DF"
        />

        <Text style={styles.logoutText}>
          Sair da Conta
        </Text>

      </TouchableOpacity>


      <View style={{ height: 35 }} />

    </ScrollView>

  );

}


const styles = StyleSheet.create({

  /* =========================
      TELA
  ========================= */

  container: {
    flex: 1,
    backgroundColor: '#3F0D0D',
  },

  contentContainer: {
    paddingHorizontal: 20,
    paddingTop: 45,
  },


  /* =========================
      CABEÇALHO
  ========================= */

  header: {
    marginBottom: 25,
  },

  title: {
    color: '#F8EEE5',
    fontSize: 30,
    fontWeight: 'bold',
  },

  subtitle: {
    color: '#D8C2B8',
    marginTop: 6,
    fontSize: 14,
  },


  /* =========================
      PERFIL
  ========================= */

  profileCard: {
    backgroundColor: '#F3E8DF',
    borderRadius: 23,
    padding: 18,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E6D4CA',
  },

  avatar: {
    width: 72,
    height: 72,
    borderRadius: 20,
  },

  profileInfo: {
    flex: 1,
    marginLeft: 15,
  },

  userName: {
    color: '#4A201A',
    fontSize: 19,
    fontWeight: 'bold',
  },

  userRole: {
    color: '#842119',
    marginTop: 4,
    fontSize: 13,
    fontWeight: '600',
  },

  userEmail: {
    color: '#806F68',
    marginTop: 5,
    fontSize: 12,
  },

  editButton: {
    width: 46,
    height: 46,
    backgroundColor: '#A52A2A',
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },


  /* =========================
      CABEÇALHO DAS SEÇÕES
  ========================= */

  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30,
    marginBottom: 15,
  },

  sectionHeaderIcon: {
    width: 38,
    height: 38,
    backgroundColor: '#652525',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },

  sectionTitle: {
    color: '#F8EEE5',
    fontSize: 21,
    fontWeight: 'bold',
  },


  /* =========================
      CARDS DE PREFERÊNCIAS
  ========================= */

  optionCard: {
    backgroundColor: '#5A2424',
    borderRadius: 20,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#713131',
  },

  optionLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },

  optionText: {
    flex: 1,
    marginLeft: 13,
  },

  optionTitle: {
    color: '#F8EEE5',
    fontSize: 16,
    fontWeight: 'bold',
  },

  optionSubtitle: {
    color: '#D8C2B8',
    marginTop: 4,
    fontSize: 12,
  },


  /* =========================
      ÍCONES
  ========================= */

  iconGreen: {
    width: 48,
    height: 48,
    backgroundColor: '#222222',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },

  iconGold: {
    width: 48,
    height: 48,
    backgroundColor: '#C88A18',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },

  iconRed: {
    width: 48,
    height: 48,
    backgroundColor: '#A52A2A',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },

  iconGreenDark: {
    width: 48,
    height: 48,
    backgroundColor: '#356044',
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },


  /* =========================
      CONTA E SEGURANÇA
  ========================= */

  menuCard: {
    backgroundColor: '#5A2424',
    borderRadius: 20,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#713131',
  },

  menuLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },

  menuTitle: {
    color: '#F8EEE5',
    fontSize: 16,
    fontWeight: 'bold',
  },

  menuSubtitle: {
    color: '#D8C2B8',
    marginTop: 4,
    fontSize: 12,
  },


  /* =========================
      SAIR DA CONTA
  ========================= */

  logoutButton: {
    height: 64,
    backgroundColor: '#8F2020',
    borderRadius: 20,
    marginTop: 25,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
    borderWidth: 1,
    borderColor: '#B94343',
  },

  logoutText: {
    color: '#F8EEE5',
    fontSize: 18,
    fontWeight: 'bold',
  },

});