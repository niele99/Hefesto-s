import React, { useState } from 'react';

import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

export default function ExitScreen({ navigation }) {

  const [orders, setOrders] = useState([
    {
      id: '0001',
      product: 'Livros Didáticos',
      status: 'Em separação',
      location: 'Depósito A',
      completed: false,
    },
    {
      id: '0002',
      product: 'Romances',
      status: 'Em separação',
      location: 'Depósito B',
      completed: true,
    },
    {
      id: '0003',
      product: 'Técnicos',
      status: 'Em separação',
      location: 'Depósito C',
      completed: false,
    },
    {
      id: '0004',
      product: 'Infantis',
      status: 'Em separação',
      location: 'Depósito A',
      completed: true,
    },
    {
      id: '0005',
      product: 'Cadernos',
      status: 'Em separação',
      location: 'Depósito B',
      completed: false,
    },
    {
      id: '0006',
      product: 'Materiais de Escritório',
      status: 'Em separação',
      location: 'Depósito C',
      completed: true,
    },
  ]);

  const toggleCompleted = (id) => {

    setOrders((currentOrders) =>
      currentOrders.map((order) =>
        order.id === id
          ? {
              ...order,
              completed: !order.completed,
              status: !order.completed
                ? 'Concluído'
                : 'Em separação',
            }
          : order
      )
    );

  };

  return (
    <View style={styles.screen}>

      {/* =========================
          CONTEÚDO
      ========================= */}

      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      >

        {/* TÍTULO */}

        <View style={styles.titleContainer}>

          <Text style={styles.title}>
            Envios do Dia
          </Text>

          <Text style={styles.subtitle}>
            Acompanhe os pedidos que precisam ser enviados
          </Text>

        </View>


        {/* =========================
            PEDIDOS
        ========================= */}

        <View style={styles.ordersGrid}>

          {orders.map((order) => (

            <View
              key={order.id}
              style={styles.orderCard}
            >

              {/* CABEÇALHO DO PEDIDO */}

              <View style={styles.orderHeader}>

                <View style={styles.truckIcon}>

                  <Ionicons
                    name="car-outline"
                    size={24}
                    color="#842119"
                  />

                </View>

                <View style={styles.orderNumberContainer}>

                  <Text style={styles.orderNumber}>
                    Pedido Nº {order.id}
                  </Text>

                </View>

              </View>


              {/* PRODUTO */}

              <View style={styles.infoRow}>

                <Ionicons
                  name="cube-outline"
                  size={22}
                  color="#842119"
                  style={styles.infoIcon}
                />

                <View style={styles.infoContent}>

                  <Text style={styles.infoLabel}>
                    Produto:
                  </Text>

                  <Text style={styles.infoValue}>
                    {order.product}
                  </Text>

                </View>

              </View>


              {/* STATUS */}

              <View style={styles.infoRow}>

                <Ionicons
                  name="time-outline"
                  size={22}
                  color="#842119"
                  style={styles.infoIcon}
                />

                <View style={styles.infoContent}>

                  <Text style={styles.infoLabel}>
                    Status:
                  </Text>

                  <Text
                    style={[
                      styles.infoValue,
                      order.completed && styles.completedText,
                    ]}
                  >
                    {order.status}
                  </Text>

                </View>

              </View>


              {/* LOCALIZAÇÃO */}

              <View style={styles.infoRow}>

                <Ionicons
                  name="location-outline"
                  size={22}
                  color="#842119"
                  style={styles.infoIcon}
                />

                <View style={styles.infoContent}>

                  <Text style={styles.infoLabel}>
                    Localização:
                  </Text>

                  <Text style={styles.infoValue}>
                    {order.location}
                  </Text>

                </View>

              </View>


              {/* BOTÃO CONCLUÍDO */}

              <TouchableOpacity
                style={[
                  styles.completedButton,
                  order.completed &&
                    styles.completedButtonGreen,
                ]}
                onPress={() => toggleCompleted(order.id)}
                activeOpacity={0.8}
              >

                {order.completed && (

                  <Ionicons
                    name="checkmark-circle"
                    size={19}
                    color="#FFFFFF"
                  />

                )}

                <Text
                  style={[
                    styles.completedButtonText,
                    order.completed &&
                      styles.completedButtonTextWhite,
                  ]}
                >
                  CONCLUÍDO
                </Text>

              </TouchableOpacity>

            </View>

          ))}

        </View>

        <View style={{ height: 30 }} />

      </ScrollView>

    </View>
  );
}


const styles = StyleSheet.create({

  /* =========================
      TELA
  ========================= */

  screen: {
    flex: 1,
    backgroundColor: '#4A1313',
  },


  /* =========================
      CONTAINER
  ========================= */

  container: {
    flex: 1,
  },

  listContainer: {
    paddingHorizontal: 20,
    paddingTop: 45,
  },


  /* =========================
      TÍTULO
  ========================= */

  titleContainer: {
    marginBottom: 25,
  },

  title: {
    color: '#FFFFFF',
    fontSize: 30,
    fontWeight: 'bold',
  },

  subtitle: {
    color: '#E8D9D2',
    fontSize: 14,
    marginTop: 6,
  },


  /* =========================
      GRID
  ========================= */

  ordersGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },


  /* =========================
      CARD
  ========================= */

  orderCard: {
    width: '48%',
    backgroundColor: '#F8F1ED',
    borderRadius: 20,
    padding: 15,
    marginBottom: 18,
    borderWidth: 1,
    borderColor: '#E8D8D1',
  },


  /* =========================
      CABEÇALHO DO CARD
  ========================= */

  orderHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 17,
  },

  truckIcon: {
    width: 34,
    height: 34,
    justifyContent: 'center',
    alignItems: 'center',
  },

  orderNumberContainer: {
    flex: 1,
    marginLeft: 5,
    backgroundColor: '#F1DAD4',
    paddingVertical: 8,
    paddingHorizontal: 6,
    borderRadius: 14,
  },

  orderNumber: {
    color: '#842119',
    fontSize: 13,
    fontWeight: 'bold',
    textAlign: 'center',
  },


  /* =========================
      INFORMAÇÕES
  ========================= */

  infoRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 14,
  },

  infoIcon: {
    marginRight: 8,
    marginTop: 1,
  },

  infoContent: {
    flex: 1,
  },

  infoLabel: {
    color: '#75645E',
    fontSize: 10,
    fontWeight: 'bold',
    marginBottom: 2,
  },

  infoValue: {
    color: '#4A201A',
    fontSize: 12,
  },

  completedText: {
    color: '#356044',
    fontWeight: 'bold',
  },


  /* =========================
      BOTÃO
  ========================= */

  completedButton: {
    height: 40,
    borderRadius: 20,
    backgroundColor: '#C8C4C3',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    gap: 6,
    marginTop: 3,
  },

  completedButtonGreen: {
    backgroundColor: '#356044',
  },

  completedButtonText: {
    color: '#5E5855',
    fontSize: 11,
    fontWeight: 'bold',
  },

  completedButtonTextWhite: {
    color: '#FFFFFF',
  },

});