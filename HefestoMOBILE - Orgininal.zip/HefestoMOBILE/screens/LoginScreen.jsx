import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  SafeAreaView,
  ImageBackground,
  Image,
} from 'react-native';

import api from '../src/services/api';

export default function LoginScreen({ navigation }) {
  const [user, setUser] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    if (!user || !password) {
      Alert.alert(
        'Atenção',
        'Preencha todos os campos.'
      );
      return;
    }

    try {
      const response = await api.post('/login', {
        email: user,
        password: password,
      });

      if (response.data.success) {
        navigation.navigate('App');
      }
    } catch (error) {
      Alert.alert(
        'Erro',
        error.response?.data?.message ||
        'Falha ao conectar ao servidor.'
      );
    }
  };

  return (
    <SafeAreaView style={styles.container}>

      {/* IMAGEM DE FUNDO */}
      <ImageBackground
        source={require('../assets/fundoMOBILE.png')}
        style={styles.background}
        resizeMode="cover"
      >

        {/* CAMADA CLARA SOBRE A IMAGEM */}
        <View style={styles.overlay}>

          {/* CONTEÚDO */}
          <View style={styles.content}>

            
            {/* LOGO */}
            <View style={styles.logoArea}>
              <Image
                source={require('../assets/logo-branco.png')}
                style={styles.logoImage}
                resizeMode="contain"
              />
            </View>

            {/* CONTAINER DO LOGIN */}
            <View style={styles.loginArea}>

              <Text style={styles.title}>
                Bem-vindo!
              </Text>

              <Text style={styles.description}>
                Entre com seus dados para acessar o sistema.
              </Text>


              {/* E-MAIL */}
              <View style={styles.inputContainer}>

                <Text style={styles.inputLabel}>
                  E-mail ou usuário
                </Text>

                <TextInput
                  placeholder="Digite seu e-mail ou usuário"

                  style={styles.input}
                  value={user}
                  onChangeText={setUser}
                  autoCapitalize="none"
                />

              </View>


              {/* SENHA */}
              <View style={styles.inputContainer}>

                <Text style={styles.inputLabel}>
                  Senha
                </Text>

                <TextInput
                  placeholder="Digite sua senha"
                  placeholderTextColor="#9B8D89"
                  secureTextEntry={true}
                  style={styles.input}
                  value={password}
                  onChangeText={setPassword}
                />

              </View>


              {/* BOTÃO */}
              <TouchableOpacity
                style={styles.button}
                onPress={handleLogin}
                activeOpacity={0.8}
              >

                <Text style={styles.buttonText}>
                  Entrar
                </Text>

              </TouchableOpacity>

            </View>

          </View>


          {/* RODAPÉ */}
          <Text style={styles.footer}>
            Hefesto's Stock • Sistema de Gestão de Estoque
          </Text>

        </View>

      </ImageBackground>

    </SafeAreaView>
  );
}


const styles = StyleSheet.create({

  /* =========================
     TELA
  ========================= */

  container: {
    flex: 1,
    backgroundColor: '#FAEEED',
  },


  /* =========================
     IMAGEM DE FUNDO
  ========================= */

  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },


  /* =========================
     CAMADA SOBRE A IMAGEM
  ========================= */

  overlay: {
    flex: 1,
    backgroundColor: 'rgba(146, 67, 67, 0.72)',
  },


  /* =========================
     CONTEÚDO
  ========================= */

  content: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 25,
  },


  /* =========================
     LOGO
  ========================= */

  logoArea: {
    alignItems: 'center',
    marginBottom: 32,
  },

  logoImage: {
    width: 365,
    height: 170,
  },

  

  logoSymbol: {
    color: '#8B1E1E',
    fontSize: 30,
    fontWeight: 'bold',
  },

  logo: {
    color: '#8B1E1E',
    fontSize: 23,
    fontWeight: 'bold',
    letterSpacing: 1.4,
  },

  subtitle: {
    color: '#756865',
    fontSize: 13,
    marginTop: 7,
  },


  /* =========================
     CONTAINER DO LOGIN
  ========================= */

  loginArea: {
    width: '100%',

    backgroundColor: '#FEFEFE',

    padding: 24,

    borderRadius: 18,

    borderWidth: 1,
    borderColor: '#E7D5D2',

    shadowColor: '#000',

    shadowOffset: {
      width: 0,
      height: 5,
    },

    shadowOpacity: 0.12,
    shadowRadius: 10,

    elevation: 5,
  },


  /* =========================
     TÍTULO
  ========================= */

  title: {
    fontSize: 25,
    fontWeight: 'bold',
    color: '#3D3533',

    marginBottom: 6,
  },

  description: {
    fontSize: 13,
    color: '#756865',

    marginBottom: 25,

    lineHeight: 19,
  },


  /* =========================
     CAMPOS
  ========================= */

  inputContainer: {
    marginBottom: 17,
  },

  inputLabel: {
    fontSize: 13,
    fontWeight: '600',

    color: '#4B403D',

    marginBottom: 7,
  },

  input: {
    height: 52,

    backgroundColor: '#FFFFFF',

    borderWidth: 1,
    borderColor: '#CDBDB7',

    borderRadius: 8,

    paddingHorizontal: 15,

    color: '#3D3533',

    fontSize: 14,
  },


  /* =========================
     BOTÃO
  ========================= */

  button: {
    height: 52,

    backgroundColor: '#851414',

    borderRadius: 8,

    justifyContent: 'center',
    alignItems: 'center',

    marginTop: 5,

    shadowColor: '#000',

    shadowOffset: {
      width: 0,
      height: 3,
    },

    shadowOpacity: 0.15,
    shadowRadius: 5,

    elevation: 3,
  },

  buttonText: {
    color: '#FFFFFF',

    fontSize: 15,

    fontWeight: 'bold',
  },


  /* =========================
     RODAPÉ
  ========================= */

  footer: {
    position: 'absolute',

    bottom: 22,

    alignSelf: 'center',

    color: '#f3eeed',

    fontSize: 10,
  },

});