import React, { useState, useEffect } from 'react';

import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Alert,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import QRCodeScanner from './QRCodeScanner';

import api from '../src/services/api';


export default function EntryScreen({ navigation }) {

  const [product, setProduct] = useState(null);

  const [quantity, setQuantity] = useState('');

  const [isScannerOpen, setIsScannerOpen] = useState(false);


  // =========================
  // BUSCA PRODUTO INICIAL
  // =========================

  useEffect(() => {

    api
      .get('/products/1')
      .then((res) => {
        setProduct(res.data);
      })
      .catch((error) => {
        console.log('Erro ao carregar produto:', error);
      });

  }, []);


  // =========================
  // QR CODE
  // =========================

  const handleReadQRCode = async (data) => {

    // Fecha a câmera
    setIsScannerOpen(false);

    console.log('QR Code lido:', data);

    try {

      // Busca o produto pelo código lido
      const response = await api.get(
        `/products/code/${encodeURIComponent(data)}`
      );

      setProduct(response.data);

      // Limpa a quantidade anterior
      setQuantity('');

      Alert.alert(
        'Produto encontrado',
        `Produto: ${response.data.name}`
      );

    } catch (error) {

      console.log(
        'Erro ao buscar produto pelo QR Code:',
        error
      );

      Alert.alert(
        'Erro',
        'Produto não encontrado no banco de dados.'
      );

    }

  };


  // =========================
  // CONFIRMAR ENTRADA
  // =========================

  const handleConfirmEntry = async () => {

    if (!product) {

      Alert.alert(
        'Erro',
        'Produto ainda não carregado.'
      );

      return;
    }


    if (
      !quantity ||
      isNaN(quantity) ||
      Number(quantity) <= 0
    ) {

      Alert.alert(
        'Erro',
        'Insira uma quantidade válida.'
      );

      return;
    }


    try {

      await api.post('/stock/move', {

        productId: product.id,

        type: 'Entrada',

        quantity: parseInt(quantity),

      });


      Alert.alert(
        'Sucesso',
        'Entrada registrada com sucesso!',
        [
          {
            text: 'OK',

            onPress: () => {
              navigation.navigate('Home');
            },

          },
        ]
      );

    } catch (error) {

      console.log(
        'Erro ao registrar entrada:',
        error
      );

      Alert.alert(
        'Erro',
        error.response?.data?.message ||
        'Erro ao registrar entrada.'
      );

    }

  };


  return (

    <ScrollView
      style={styles.container}
      showsVerticalScrollIndicator={false}
    >

      {/* =========================
          CABEÇALHO
      ========================= */}

      <View style={styles.header}>

        <Text style={styles.title}>
          Entrada de Matéria-Prima
        </Text>

        <Text style={styles.subtitle}>
          Registre produtos rapidamente
        </Text>

      </View>


      {/* =========================
          QR CODE
      ========================= */}

      <TouchableOpacity
        style={styles.qrButton}
        onPress={() => setIsScannerOpen(true)}
        activeOpacity={0.8}
      >

        <View style={styles.qrContent}>

          <Ionicons
            name="qr-code-outline"
            size={32}
            color="#842119"
          />

          <View>

            <Text style={styles.qrTitle}>
              Ler QR Code
            </Text>

            <Text style={styles.qrSubtitle}>
              Escanear produto
            </Text>

          </View>

        </View>


        <Ionicons
          name="chevron-forward"
          size={22}
          color="#842119"
        />

      </TouchableOpacity>


      {/* =========================
          MODAL DO SCANNER
      ========================= */}

<QRCodeScanner
  visible={isScannerOpen}
  onClose={() => setIsScannerOpen(false)}
  onReadCode={handleReadQRCode}
/>

      {/* =========================
          PRODUTO ENCONTRADO
      ========================= */}

      <Text style={styles.sectionTitle}>
        Produto Encontrado
      </Text>


      <View style={styles.productCard}>

        <View style={styles.productIcon}>

          <Ionicons
            name="cube-outline"
            size={28}
            color="#842119"
          />

        </View>


        <View style={styles.productInfo}>

          <Text style={styles.productName}>

            {product?.name ||
              'Nenhum produto selecionado'}

          </Text>


          <Text style={styles.productCode}>

            {product
              ? `Código: ${product.code}`
              : 'Leia o QR Code para selecionar um produto'}

          </Text>


          <Text style={styles.productStock}>

            {product
              ? `Estoque Atual: ${product.stock}`
              : 'Aguardando leitura'}

          </Text>

        </View>

      </View>


      {/* =========================
          QUANTIDADE
      ========================= */}

      <Text style={styles.sectionTitle}>
        Quantidade
      </Text>


      <TextInput
        style={styles.input}
        placeholder="Digite a quantidade"
        placeholderTextColor="#8A7770"
        keyboardType="numeric"
        value={quantity}
        onChangeText={setQuantity}
      />


      {/* =========================
          RESUMO DA ENTRADA
      ========================= */}

      <View style={styles.summaryCard}>

        <View style={styles.summaryHeader}>

          <View style={styles.summaryIcon}>

            <Ionicons
              name="folder-open-outline"
              size={25}
              color="#FFFFFF"
            />

          </View>


          <Text style={styles.summaryTitle}>
            Resumo da Entrada
          </Text>

        </View>


        {/* PRODUTO */}

        <View style={styles.summaryRow}>

          <Text style={styles.summaryLabel}>
            Produto
          </Text>

          <Text style={styles.summaryValue}>
            {product?.name || '-'}
          </Text>

        </View>


        {/* QUANTIDADE */}

        <View style={styles.summaryRow}>

          <Text style={styles.summaryLabel}>
            Quantidade
          </Text>

          <Text style={styles.summaryValue}>
            {quantity || 0}
          </Text>

        </View>


        {/* ESTOQUE FINAL */}

        <View style={styles.summaryRow}>

          <Text style={styles.summaryLabel}>
            Estoque Final
          </Text>

          <Text style={styles.summaryValueGreen}>
            {(product?.stock || 0) +
              Number(quantity || 0)}
          </Text>

        </View>

      </View>


      {/* =========================
          CONFIRMAR ENTRADA
      ========================= */}

      <TouchableOpacity
        style={styles.confirmButton}
        onPress={handleConfirmEntry}
        activeOpacity={0.8}
      >

        <Ionicons
          name="checkmark-circle"
          size={24}
          color="#FFFFFF"
        />

        <Text style={styles.confirmText}>
          Confirmar Entrada
        </Text>

      </TouchableOpacity>


      <View style={{ height: 40 }} />

    </ScrollView>

  );

}


const styles = StyleSheet.create({

  /* =========================
      FUNDO
  ========================= */

  container: {
    flex: 1,
    backgroundColor: '#4A1313',
    paddingHorizontal: 20,
  },


  /* =========================
      CABEÇALHO
  ========================= */

  header: {
    marginTop: 50,
  },

  title: {
    color: '#FFFFFF',
    fontSize: 30,
    fontWeight: 'bold',
  },

  subtitle: {
    color: '#E8D9D2',
    marginTop: 5,
    fontSize: 15,
  },


  /* =========================
      QR CODE
  ========================= */

  qrButton: {
    backgroundColor: '#F8F1ED',
    borderRadius: 25,
    padding: 22,
    marginTop: 30,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  qrContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },

  qrTitle: {
    color: '#4A201A',
    fontSize: 18,
    fontWeight: 'bold',
  },

  qrSubtitle: {
    color: '#806F68',
    marginTop: 3,
  },


  /* =========================
      TÍTULOS
  ========================= */

  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 35,
    marginBottom: 15,
  },


  /* =========================
      PRODUTO
  ========================= */

  productCard: {
    backgroundColor: '#F8F1ED',
    borderRadius: 22,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E8D8D1',
  },

  productIcon: {
    width: 65,
    height: 65,
    backgroundColor: '#F0D8D2',
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },

  productInfo: {
    flex: 1,
  },

  productName: {
    color: '#4A201A',
    fontSize: 18,
    fontWeight: 'bold',
  },

  productCode: {
    color: '#806F68',
    marginTop: 5,
  },

  productStock: {
    color: '#356044',
    marginTop: 8,
    fontWeight: 'bold',
  },


  /* =========================
      INPUT
  ========================= */

  input: {
    backgroundColor: '#F3E5DF',
    height: 65,
    borderRadius: 18,
    paddingHorizontal: 20,
    color: '#4A201A',
    fontSize: 18,
  },


  /* =========================
      RESUMO
  ========================= */

  summaryCard: {
    backgroundColor: '#F3E6E0',
    borderRadius: 22,
    padding: 22,
    marginTop: 35,
  },

  summaryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },

  summaryIcon: {
    width: 48,
    height: 48,
    backgroundColor: '#A52A2A',
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },

  summaryTitle: {
    color: '#4A201A',
    fontSize: 18,
    fontWeight: 'bold',
  },

  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },

  summaryLabel: {
    color: '#75645E',
    fontSize: 15,
  },

  summaryValue: {
    color: '#4A201A',
    fontWeight: 'bold',
    maxWidth: 200,
    textAlign: 'right',
  },

  summaryValueGreen: {
    color: '#22C55E',
    fontWeight: 'bold',
  },


  /* =========================
      CONFIRMAR
  ========================= */

  confirmButton: {
    backgroundColor: '#356044',
    height: 65,
    borderRadius: 22,
    marginTop: 35,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },

  confirmText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },

});