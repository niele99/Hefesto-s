import React, { useState } from 'react';

import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

export default function HistoryScreen({ navigation }) {

  const [trackingData] = useState({
    order: 'HEF1024',
    product: 'Livro - Modelagem 3D',
    status: 'Em transporte',
    deliveryDate: '18/09/2026',
    address: 'Rua das Flores, 123 - Centro',
    city: 'São Paulo - SP',
    carrier: 'Logística Hefesto',
  });


  const trackingSteps = [
    {
      title: 'Pedido confirmado',
      description: 'Seu pedido foi recebido e está sendo processado.',
      date: '15/09/2026',
      time: '10:24',
      icon: 'checkmark',
      completed: true,
    },
    {
      title: 'Em separação',
      description: 'O produto está sendo separado no estoque.',
      date: '15/09/2026',
      time: '14:37',
      icon: 'cube-outline',
      completed: true,
    },
    {
      title: 'Em transporte',
      description: 'Seu pedido saiu para entrega.',
      date: '16/09/2026',
      time: '09:12',
      icon: 'car-outline',
      completed: true,
    },
    {
      title: 'Saiu para entrega',
      description: 'Seu pedido está a caminho do destino.',
      date: '17/09/2026',
      time: '08:45',
      icon: 'location-outline',
      completed: true,
      current: true,
    },
    {
      title: 'Entregue',
      description: 'Aguardando confirmação de recebimento.',
      date: '--',
      time: '--',
      icon: 'checkmark-circle-outline',
      completed: false,
    },
  ];


  return (

    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.contentContainer}
      showsVerticalScrollIndicator={false}
    >

      {/* =========================
          CABEÇALHO
      ========================= */}

      <View style={styles.header}>

        <View style={styles.headerText}>

          <Text style={styles.title}>
            Rastreio
          </Text>

          <Text style={styles.subtitle}>
            Acompanhe o status da sua entrega
          </Text>

        </View>

        <View style={styles.headerIcon}>

          <Ionicons
            name="car-outline"
            size={34}
            color="#E8C9A0"
          />

        </View>

      </View>


      {/* =========================
          CARD DO PEDIDO
      ========================= */}

      <View style={styles.orderCard}>

        <View style={styles.orderTop}>

          <View style={styles.orderIcon}>

            <Ionicons
              name="cube-outline"
              size={32}
              color="#FFFFFF"
            />

          </View>

          <View style={styles.orderInfo}>

            <Text style={styles.orderLabel}>
              PEDIDO
            </Text>

            <Text style={styles.orderNumber}>
              #{trackingData.order}
            </Text>

            <Text style={styles.productName}>
              {trackingData.product}
            </Text>

          </View>

          <View style={styles.statusBadge}>

            <Ionicons
              name="car-outline"
              size={16}
              color="#842119"
            />

            <Text style={styles.statusText}>
              {trackingData.status}
            </Text>

          </View>

        </View>


        <View style={styles.orderDivider} />


        <View style={styles.deliveryInfo}>

          <View style={styles.deliveryItem}>

            <Ionicons
              name="calendar-outline"
              size={21}
              color="#842119"
            />

            <View>

              <Text style={styles.deliveryLabel}>
                Previsão de entrega
              </Text>

              <Text style={styles.deliveryValue}>
                {trackingData.deliveryDate}
              </Text>

            </View>

          </View>

        </View>

      </View>


      {/* =========================
          TÍTULO
      ========================= */}

      <View style={styles.sectionHeader}>

        <Text style={styles.sectionTitle}>
          Acompanhamento
        </Text>

        <View style={styles.progressBadge}>

          <Text style={styles.progressText}>
            Em andamento
          </Text>

        </View>

      </View>


      {/* =========================
          LINHA DO TEMPO
      ========================= */}

      <View style={styles.timelineCard}>

        {trackingSteps.map((step, index) => (

          <View
            key={index}
            style={styles.timelineItem}
          >

            {/* LINHA */}

            <View style={styles.timelineLeft}>

              <View
                style={[
                  styles.timelineIcon,
                  step.completed
                    ? styles.timelineIconCompleted
                    : styles.timelineIconPending,
                  step.current &&
                    styles.timelineIconCurrent,
                ]}
              >

                <Ionicons
                  name={step.icon}
                  size={21}
                  color={
                    step.completed
                      ? '#FFFFFF'
                      : '#A59A94'
                  }
                />

              </View>

              {index < trackingSteps.length - 1 && (

                <View
                  style={[
                    styles.timelineLine,
                    step.completed
                      ? styles.timelineLineCompleted
                      : styles.timelineLinePending,
                  ]}
                />

              )}

            </View>


            {/* INFORMAÇÕES */}

            <View style={styles.timelineContent}>

              <View style={styles.timelineTitleRow}>

                <Text
                  style={[
                    styles.timelineTitle,
                    step.current &&
                      styles.timelineTitleCurrent,
                    !step.completed &&
                      styles.timelineTitlePending,
                  ]}
                >
                  {step.title}
                </Text>

                <View style={styles.dateContainer}>

                  <Text style={styles.timelineDate}>
                    {step.date}
                  </Text>

                  <Text style={styles.timelineTime}>
                    {step.time}
                  </Text>

                </View>

              </View>

              <Text
                style={[
                  styles.timelineDescription,
                  !step.completed &&
                    styles.timelineDescriptionPending,
                ]}
              >
                {step.description}
              </Text>

            </View>

          </View>

        ))}

      </View>


      {/* =========================
          ENDEREÇO
      ========================= */}

      <View style={styles.infoCard}>

        <View style={styles.infoIcon}>

          <Ionicons
            name="location-outline"
            size={28}
            color="#FFFFFF"
          />

        </View>

        <View style={styles.infoContent}>

          <Text style={styles.infoTitle}>
            Endereço de entrega
          </Text>

          <Text style={styles.infoText}>
            {trackingData.address}
          </Text>

          <Text style={styles.infoText}>
            {trackingData.city}
          </Text>

        </View>

      </View>


      {/* =========================
          TRANSPORTADORA
      ========================= */}

      <View style={styles.infoCard}>

        <View style={styles.infoIconGreen}>

          <Ionicons
            name="car-outline"
            size={28}
            color="#FFFFFF"
          />

        </View>

        <View style={styles.infoContent}>

          <Text style={styles.infoTitle}>
            Transportadora
          </Text>

          <Text style={styles.infoText}>
            {trackingData.carrier}
          </Text>

        </View>

        <TouchableOpacity style={styles.contactButton}>

          <Ionicons
            name="call-outline"
            size={19}
            color="#FFFFFF"
          />

          <Text style={styles.contactText}>
            Contato
          </Text>

        </TouchableOpacity>

      </View>


      <View style={{ height: 35 }} />

    </ScrollView>

  );
}


const styles = StyleSheet.create({

  /* =========================
      TELA
  ========================= */

  container: {
    flex: 1,
    backgroundColor: '#4A1313',
  },

  contentContainer: {
    paddingHorizontal: 20,
    paddingTop: 45,
  },


  /* =========================
      CABEÇALHO
  ========================= */

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 25,
  },

  headerText: {
    flex: 1,
  },

  title: {
    color: '#F8EEE5',
    fontSize: 30,
    fontWeight: 'bold',
  },

  subtitle: {
    color: '#D8C2B8',
    fontSize: 14,
    marginTop: 6,
  },

  headerIcon: {
    width: 58,
    height: 58,
    backgroundColor: '#651818',
    borderRadius: 17,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
  },


  /* =========================
      PEDIDO
  ========================= */

  orderCard: {
    backgroundColor: '#F8F1ED',
    borderRadius: 23,
    padding: 19,
    borderWidth: 1,
    borderColor: '#E8D8D1',
  },

  orderTop: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  orderIcon: {
    width: 58,
    height: 58,
    backgroundColor: '#A52A2A',
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 13,
  },

  orderInfo: {
    flex: 1,
  },

  orderLabel: {
    color: '#806F68',
    fontSize: 10,
    fontWeight: 'bold',
  },

  orderNumber: {
    color: '#842119',
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 1,
  },

  productName: {
    color: '#4A201A',
    fontSize: 13,
    marginTop: 4,
  },

  statusBadge: {
    backgroundColor: '#F1DAD4',
    borderRadius: 16,
    paddingVertical: 8,
    paddingHorizontal: 9,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },

  statusText: {
    color: '#842119',
    fontSize: 10,
    fontWeight: 'bold',
  },

  orderDivider: {
    height: 1,
    backgroundColor: '#E0CDC4',
    marginVertical: 17,
  },

  deliveryInfo: {
    flexDirection: 'row',
  },

  deliveryItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
  },

  deliveryLabel: {
    color: '#806F68',
    fontSize: 11,
  },

  deliveryValue: {
    color: '#4A201A',
    fontSize: 13,
    fontWeight: 'bold',
    marginTop: 2,
  },


  /* =========================
      SEÇÃO
  ========================= */

  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 28,
    marginBottom: 15,
  },

  sectionTitle: {
    color: '#F8EEE5',
    fontSize: 22,
    fontWeight: 'bold',
  },

  progressBadge: {
    backgroundColor: '#C88A18',
    paddingVertical: 8,
    paddingHorizontal: 11,
    borderRadius: 16,
  },

  progressText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: 'bold',
  },


  /* =========================
      TIMELINE
  ========================= */

  timelineCard: {
    backgroundColor: '#F8F1ED',
    borderRadius: 23,
    padding: 17,
    borderWidth: 1,
    borderColor: '#E8D8D1',
  },

  timelineItem: {
    flexDirection: 'row',
  },

  timelineLeft: {
    width: 42,
    alignItems: 'center',
  },

  timelineIcon: {
    width: 42,
    height: 42,
    borderRadius: 21,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 2,
  },

  timelineIconCompleted: {
    backgroundColor: '#356044',
  },

  timelineIconPending: {
    backgroundColor: '#D5CDCA',
  },

  timelineIconCurrent: {
    backgroundColor: '#A52A2A',
  },

  timelineLine: {
    width: 3,
    flex: 1,
    minHeight: 52,
  },

  timelineLineCompleted: {
    backgroundColor: '#356044',
  },

  timelineLinePending: {
    backgroundColor: '#D5CDCA',
  },

  timelineContent: {
    flex: 1,
    paddingLeft: 13,
    paddingBottom: 20,
  },

  timelineTitleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },

  timelineTitle: {
    color: '#4A201A',
    fontSize: 15,
    fontWeight: 'bold',
    flex: 1,
    paddingRight: 8,
  },

  timelineTitleCurrent: {
    color: '#A52A2A',
  },

  timelineTitlePending: {
    color: '#9B8F89',
  },

  dateContainer: {
    alignItems: 'flex-end',
  },

  timelineDate: {
    color: '#806F68',
    fontSize: 10,
    fontWeight: '600',
  },

  timelineTime: {
    color: '#9B8F89',
    fontSize: 10,
    marginTop: 2,
  },

  timelineDescription: {
    color: '#806F68',
    fontSize: 12,
    lineHeight: 17,
    marginTop: 5,
    paddingRight: 5,
  },

  timelineDescriptionPending: {
    color: '#A59A94',
  },


  /* =========================
      CARDS INFORMATIVOS
  ========================= */

  infoCard: {
    backgroundColor: '#F3E6E0',
    borderRadius: 21,
    padding: 17,
    marginTop: 15,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E4D0C7',
  },

  infoIcon: {
    width: 52,
    height: 52,
    backgroundColor: '#A52A2A',
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 13,
  },

  infoIconGreen: {
    width: 52,
    height: 52,
    backgroundColor: '#356044',
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 13,
  },

  infoContent: {
    flex: 1,
  },

  infoTitle: {
    color: '#4A201A',
    fontSize: 15,
    fontWeight: 'bold',
  },

  infoText: {
    color: '#806F68',
    fontSize: 12,
    marginTop: 3,
  },


  /* =========================
      CONTATO
  ========================= */

  contactButton: {
    backgroundColor: '#842119',
    borderRadius: 17,
    paddingVertical: 9,
    paddingHorizontal: 11,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    marginLeft: 8,
  },

  contactText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: 'bold',
  },

});