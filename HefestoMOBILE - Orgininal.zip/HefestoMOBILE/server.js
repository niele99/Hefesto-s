const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');



const app = express();

app.use(cors());
app.use(express.json());


// ========================================
// CONEXÃO COM MYSQL
// ========================================

const db = mysql.createPool({

  host: 'localhost',

  user: 'root',

  password: '123456',

  database: 'hefesto',

  waitForConnections: true,

  connectionLimit: 10,

  queueLimit: 0

});


// ========================================
// 1. LOGIN
// ========================================

app.post('/api/login', async (req, res) => {

  const { email, password } = req.body;

  try {

    const [rows] = await db.query(

      `
      SELECT
        id,
        nome_funcionario,
        email_funcionario,
        senha_funcionario,
        classificacao_funcionario,
        ativado_funcionario,
        foto_nome,
        foto_localizacao,
        foto_blob

      FROM funcionario

      WHERE email_funcionario = ?
      AND senha_funcionario = ?
      AND ativado_funcionario = 1
      `,

      [email, password]

    );


    if (rows.length > 0) {

      res.json({

        success: true,

        user: rows[0]

      });

    } else {

      res.status(401).json({

        success: false,

        message: 'Credenciais inválidas ou funcionário inativo.'

      });

    }

  } catch (error) {

    console.log('Erro no login:', error);

    res.status(500).json({
      error: error.message
    });

  }

});


// ========================================
// 2. DASHBOARD
// ========================================

app.get('/api/dashboard', async (req, res) => {

  try {

    // TOTAL DE PRODUTOS

    const [[{ totalProducts }]] = await db.query(`
      SELECT COUNT(*) AS totalProducts
      FROM produto
    `);


    // PRODUTOS ATIVOS

    const [[{ activeProducts }]] = await db.query(`
      SELECT COUNT(*) AS activeProducts
      FROM produto
      WHERE ativado_produto = 1
    `);


    // PRODUTOS INATIVOS

    const [[{ inactiveProducts }]] = await db.query(`
      SELECT COUNT(*) AS inactiveProducts
      FROM produto
      WHERE ativado_produto = 0
    `);


    // ÚLTIMOS PRODUTOS

    const [recentProducts] = await db.query(`
      SELECT
        id,
        nome_produto,
        dimensoes_produto,
        minimo_produto,
        ativado_produto,
        foto_nome,
        foto_localizacao,
        foto_blob

      FROM produto

      ORDER BY id DESC

      LIMIT 5
    `);


    res.json({

      totalProducts: totalProducts || 0,

      activeProducts: activeProducts || 0,

      inactiveProducts: inactiveProducts || 0,

      recentProducts

    });

  } catch (error) {

    console.log('Erro no dashboard:', error);

    res.status(500).json({
      error: error.message
    });

  }

});


// ========================================
// 3. LISTAR TODOS OS PRODUTOS
// ========================================

app.get('/api/produto', async (req, res) => {

  try {

    const [produto] = await db.query(`
      SELECT
        id,
        nome_produto,
        dimensoes_produto,
        minimo_produto,
        ativado_produto,
        foto_nome,
        foto_localizacao,
        foto_blob

      FROM produto

      ORDER BY nome_produto ASC
    `);

    res.json(produto);

  } catch (error) {

    console.log('Erro ao listar produtos:', error);

    res.status(500).json({
      error: error.message
    });

  }

});

// ========================================
// 4. BUSCAR PRODUTO POR ID
// ========================================

app.get('/api/produto/:id', async (req, res) => {

  const { id } = req.params;

  try {

    const [rows] = await db.query(`

      SELECT
        id,
        nome_produto,
        dimensoes_produto,
        minimo_produto,
        ativado_produto,
        foto_nome,
        foto_localizacao,
        foto_blob

      FROM produto

      WHERE id = ?

    `, [id]);


    if (rows.length > 0) {

      res.json(rows[0]);

    } else {

      res.status(404).json({
        message: 'Produto não encontrado'
      });

    }

  } catch (error) {

    console.log('Erro ao buscar produto:', error);

    res.status(500).json({
      error: error.message
    });

  }

});


// ========================================
// 5. LISTAR ESTOQUE FINAL
// ========================================

app.get('/api/stock', async (req, res) => {

  try {

    const [rows] = await db.query(`

      SELECT

        e.id,

        e.barracao_rua_estoque_final,

        e.barracao_andar_estoque_final,

        e.barracao_num_estoque_final,

        e.status_estoque_final,

        e.produto_id,

        p.nome_produto,

        p.dimensoes_produto,

        p.minimo_produto

      FROM estoque_final e

      INNER JOIN produto p
      ON e.produto_id = p.id

      ORDER BY e.id DESC

    `);


    res.json(rows);

  } catch (error) {

    console.log('Erro ao buscar estoque:', error);

    res.status(500).json({
      error: error.message
    });

  }

});


// ========================================
// 6. BUSCAR ESTOQUE POR PRODUTO
// ========================================

app.get('/api/stock/:produtoId', async (req, res) => {

  const { produtoId } = req.params;

  try {

    const [rows] = await db.query(`

      SELECT

        e.id,

        e.barracao_rua_estoque_final,

        e.barracao_andar_estoque_final,

        e.barracao_num_estoque_final,

        e.status_estoque_final,

        p.nome_produto,

        p.minimo_produto

      FROM estoque_final e

      INNER JOIN produto p
      ON e.produto_id = p.id

      WHERE e.produto_id = ?

    `, [produtoId]);


    res.json(rows);

  } catch (error) {

    console.log('Erro ao buscar estoque:', error);

    res.status(500).json({
      error: error.message
    });

  }

});


// ========================================
// 7. HISTÓRICO DE COMPRAS
// ========================================

app.get('/api/history/purchases', async (req, res) => {

  try {

    const [rows] = await db.query(`

      SELECT

        id,

        entrega_fornecedor_id,

        d_entrega_historico_compra,

        d_realizacao_historico_compra

      FROM historico_compra

      ORDER BY id DESC

    `);


    res.json(rows);

  } catch (error) {

    console.log('Erro ao buscar histórico de compras:', error);

    res.status(500).json({
      error: error.message
    });

  }

});


// ========================================
// 8. HISTÓRICO DE VENDAS
// ========================================

app.get('/api/history/sales', async (req, res) => {

  try {

    const [rows] = await db.query(`

      SELECT

        hv.id,

        hv.d_entrega_historico_vendas,

        hv.quantidade_historico_vendas,

        hv.valor_total_historico_vendas,

        hv.valor_unt_historico_vendas,

        hv.prazo_final_historico_vendas,

        hv.pedido_cliente_id,

        hv.estoque_final_id,

        hv.d_realizacao_historico_vendas,

        hv.d_termino_historico_vendas

      FROM historico_vendas hv

      ORDER BY hv.id DESC

    `);


    res.json(rows);

  } catch (error) {

    console.log('Erro ao buscar histórico de vendas:', error);

    res.status(500).json({
      error: error.message
    });

  }

});


// ========================================
// 9. BUSCAR UMA VENDA ESPECÍFICA
// ========================================

app.get('/api/history/sales/:id', async (req, res) => {

  const { id } = req.params;

  try {

    const [rows] = await db.query(`

      SELECT *

      FROM historico_vendas

      WHERE id = ?

    `, [id]);


    if (rows.length > 0) {

      res.json(rows[0]);

    } else {

      res.status(404).json({
        message: 'Venda não encontrada'
      });

    }

  } catch (error) {

    console.log('Erro ao buscar venda:', error);

    res.status(500).json({
      error: error.message
    });

  }

});


// ========================================
// INICIAR SERVIDOR
// ========================================

const PORT = 3000;

app.listen(PORT, () => {

  console.log(`Servidor rodando em http://localhost:${PORT}`);

});