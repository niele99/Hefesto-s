from functools import wraps
from flask import session, redirect, url_for, flash
import bcrypt


def gerar_hash_senha(senha_funcionario):
    """
    Recebe uma senha em texto puro e retorna a senha criptografada.
    """
    senha_hash = bcrypt.hashpw(
        senha_funcionario.encode("utf-8"),
        bcrypt.gensalt()
    )

    return senha_hash.decode("utf-8")



    
    """
    Compara a senha digitada com a senha criptografada salva no banco.
     senha_hash_f = bcrypt.hashpw( #criptografa
        senha_funcionario.encode("utf-8"), #tipo de criptografia
        bcrypt.gensalt() #fim da funcao de criptografia
    )
    """
   #######TESTE##########

def verificar_senha(senha_funcionario, senha_hash_banco):

    if not senha_hash_banco:
        return False

    if not senha_hash_banco.startswith(("$2a$", "$2b$", "$2y$")):
        return False

    return bcrypt.checkpw(
        senha_funcionario.encode("utf-8"),
        senha_hash_banco.encode("utf-8")
    )
    
    print("senha d->",senha_hash_f)
    print("senha B->",senha_hash_banco)
    return bcrypt.checkpw(
        senha_funcionario.encode("utf-8"),
        senha_hash_banco.encode("utf-8")
    )


def login_obrigatorio(funcao):
    """
    Decorador para proteger rotas que exigem login.
    """
    @wraps(funcao)
    def wrapper(*args, **kwargs):
        if "id" not in session:
            flash("Faça login para acessar o sistema.", "warning")
            return redirect(url_for("login"))

        return funcao(*args, **kwargs)

    return wrapper