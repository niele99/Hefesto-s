//NÃO TENHO CTZ SE TA CERTO


async function fazerLogin() { // função assíncrona 

    const email = document.getElementById("email").value;  // pega o valor digitado no input de email

    const senha = document.getElementById("senha").value;  // pega o valo digitado no input de senha

    const response = await fetch("http://localhost:3000/login", { // envia uma requisição para o backend

        method: "POST", // metodo HTTP usado

        headers: { // informa o tipo dos dados enviados
            "Content-Type": "application/json"
        },

        body: JSON.stringify({  // dados enviados para a API

            email: email, //dados que o osuário digita
            senha: senha
        })
    });

    const dados = await response.json(); // transforma a resposta da API em objeto JavaScript

    if(response.ok){ //verifica se o login ta certo

        localStorage.setItem( // salva o nome do usuário no localStorage
            "nomeUsuario",
            dados.usuario.nome
        );

        localStorage.setItem( // salva o token no localStorage
            "token",
            dados.token
        );

        alert(`Bem-vindo ${dados.usuario.nome}`);

        window.location.href = "home.html"; // redireciona para outra página
    }

    else{ // se der erro no login

        alert("Email ou senha inválidos"); // mensagem de erro
    }
}